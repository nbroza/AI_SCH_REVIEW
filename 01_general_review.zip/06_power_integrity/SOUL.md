# Power Integrity Review — Schematic Review Context

## Purpose

This review evaluates the **power distribution network (PDN) at the schematic level** — verifying that every voltage rail is properly generated, regulated, filtered, decoupled, and distributed. Power integrity issues cause noise, instability, reduced performance, and intermittent failures that are extremely difficult to debug on a fabricated board.

## Prerequisites

- Exported netlist
- Power architecture diagram or power tree (if available)
- Load current estimates for each voltage rail
- Input power source specifications (voltage range, impedance, current capability)
- Datasheets for all power management ICs in `../datasheets/`
- Application notes for power management ICs (if available)

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`06_power_integrity/`). These may contain power budget spreadsheets, rail current measurements from prior revisions, known power integrity issues, or supplemental design guidelines.

Reference datasheets in `../datasheets/` for all voltage regulators, power switches, and power management ICs.

## When to Ask the User for Clarification

Ask the user when:

- Load current requirements for a rail are not specified or unclear
- The input power source characteristics are unknown (voltage range, current limit, impedance)
- You cannot determine whether a sleep/standby mode exists that changes the power profile
- The efficiency requirements are not specified (affects topology selection)
- Thermal constraints are unknown (affects regulator selection — LDO vs switching)
- You need to know if specific rails have noise sensitivity requirements (analog, RF, PLL)
- Dynamic load profiles are needed to evaluate transient response

**Power design cannot be properly reviewed without knowing the load. Ask for current budgets.**

---

## Review Checklist

### 1. Power Tree & Rail Inventory

- [ ] Every voltage rail in the design is documented: source, nominal voltage, tolerance, max current
- [ ] Power conversion chain is logical (no circular dependencies)
- [ ] Input voltage range is compatible with the first-stage regulator's input range
- [ ] All rails have their source identified:
  - External input (connector)
  - Switching regulator output
  - LDO output
  - Charge pump output
  - Reference voltage
- [ ] No rail is powered from a rail that cannot supply sufficient current
- [ ] Standby/always-on rails are identified and properly isolated from switched rails

### 2. Voltage Regulator Design Verification

For each voltage regulator in the design:

#### Input Stage
- [ ] Input voltage range is within the regulator's recommended operating input range
- [ ] Input capacitor value meets or exceeds datasheet minimum
- [ ] Input capacitor voltage rating is sufficient (recommend ≥1.5× max input voltage)
- [ ] Input capacitor type matches datasheet requirement (ceramic, tantalum, electrolytic)
- [ ] For ceramic input caps: account for DC bias derating (a 10µF 6.3V X5R cap may only provide 4µF at 5V)
- [ ] Bulk input capacitance is sufficient for load transient demand
- [ ] Input protection (reverse polarity, overvoltage, inrush) is appropriate

#### Output Stage
- [ ] Output voltage is correctly set (verify feedback divider or fixed-output variant)
- [ ] Output capacitor value meets datasheet minimum (accounting for DC bias derating)
- [ ] Output capacitor ESR is within the stable range for the regulator
- [ ] Output capacitor voltage rating is sufficient (recommend ≥1.5× output voltage)
- [ ] Output capacitor type matches datasheet requirement
- [ ] Total output capacitance provides acceptable transient response for the load

#### Control & Compensation
- [ ] Enable pin is properly driven (not floating)
- [ ] Soft-start timing is appropriate for the application
- [ ] UVLO thresholds match the intended operating range
- [ ] Power-good / PGOOD output is connected and used (if available)
- [ ] Compensation network matches datasheet recommendation (if external compensation)
- [ ] Switching frequency is set within the recommended range (if adjustable)
- [ ] Current limit is set appropriately (if adjustable)

#### Inductor Selection (Switching Regulators)
- [ ] Inductance value matches datasheet recommendation for the operating conditions
- [ ] Inductor saturation current rating exceeds the peak inductor current
- [ ] Inductor DC resistance (DCR) is acceptable (affects efficiency)
- [ ] Inductor type is appropriate (shielded vs unshielded, ferrite vs powdered iron)

#### Thermal
- [ ] Power dissipation is calculated and within the component's thermal limits
- [ ] For LDOs: P_DISS = (VIN - VOUT) × ILOAD — verify this is acceptable
- [ ] For switching regulators: estimate efficiency at expected load and verify thermal limits

### 3. Decoupling Strategy

- [ ] Every IC has local decoupling capacitors (typically 100nF ceramic per power pin)
- [ ] Bulk decoupling is present for each voltage rail (typically 10µF-100µF)
- [ ] Decoupling capacitor values and quantities match IC datasheet recommendations
- [ ] High-speed ICs have appropriate high-frequency decoupling (10nF or 1nF in parallel with 100nF)
- [ ] Capacitor types are appropriate:
  - C0G/NP0 for precision and high-frequency applications
  - X7R for general decoupling
  - X5R acceptable for bulk decoupling
  - Y5V/Z5U should generally be avoided (excessive variation with temperature and voltage)
- [ ] Total decoupling capacitance on each rail provides adequate charge reservoir

### 4. Load Budget Analysis

- [ ] Total load current on each rail is calculated and documented
- [ ] Each regulator can supply its total load with margin (recommend ≥20% margin)
- [ ] Peak current demands (motor start, transmitter burst, processor wake) are within regulator capability
- [ ] Worst-case simultaneous load conditions are evaluated
- [ ] Minimum load requirements are met (some regulators need minimum load for stability)
- [ ] Inrush current at power-on is managed (soft-start, hot-swap controllers, NTC thermistors)

### 5. Ground Architecture

- [ ] Analog ground (AGND) and digital ground (DGND) are separate nets where required by IC datasheets
- [ ] AGND and DGND connections on mixed-signal ICs follow the datasheet recommendation
- [ ] Power ground (PGND) for switching regulators is a separate net where appropriate
- [ ] Chassis/earth ground net exists if the design has external connectors requiring it
- [ ] Ground net assignments on each IC pin match the datasheet's ground pin designations

### 6. Power Rail Protection

- [ ] Reverse polarity protection is present on external power inputs
  - P-MOSFET, ideal diode controller, or Schottky diode
- [ ] Overvoltage protection is present where needed (TVS, Zener, crowbar)
- [ ] Overcurrent protection is present (fuses, PTC resettable fuses, electronic current limiting)
- [ ] Inrush current limiting is present for high-capacitance rails
- [ ] Short-circuit protection behavior is defined (hiccup mode, latchoff, auto-retry)

### 7. Power Supply Noise & Filtering

- [ ] Noise-sensitive rails (analog, PLL, RF) have additional LC or ferrite bead filtering
- [ ] Ferrite beads used for filtering are rated for the DC current of the rail
- [ ] Ferrite bead impedance is appropriate at the noise frequency of interest
- [ ] Post-regulation LDOs are used where switching noise must be below a specific threshold
- [ ] PSRR requirements of downstream ICs are met by the chosen regulator at relevant frequencies

---

## Common Power Integrity Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| Regulator output exceeds load IC's max VIN | Critical | Downstream component damage |
| Missing input/output capacitor | Critical | Regulator oscillation or instability |
| LDO thermal overload | Critical | Excessive dropout × current = overheating |
| Insufficient output current capability | Major | Rail sags under load |
| Wrong capacitor ESR for LDO | Major | LDO oscillation with wrong cap type |
| DC bias derated cap below minimum | Major | Effective capacitance too low for stability |
| Missing decoupling on IC power pin | Major | Noise coupling, potential malfunction |
| No reverse polarity protection | Major | Board damage from user error |
| Incorrect feedback divider | Critical | Wrong output voltage |
| Switching noise on analog supply | Major | Degraded ADC/DAC performance |

## Severity Classification

- **Critical**: Power integrity issue will cause component damage, regulator failure, or board non-function.
- **Major**: Issue will cause degraded performance, excessive noise, or reliability concern.
- **Minor**: Non-optimal power design but functional.
- **Info**: Optimization opportunity.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet name/number, regulator designator, rail name]
- **Description**: [What was found]
- **Calculation**: [Show the math if applicable — voltage divider, power dissipation, etc.]
- **Recommendation**: [What should be changed]
- **Reference**: [Datasheet page, application note]
```
