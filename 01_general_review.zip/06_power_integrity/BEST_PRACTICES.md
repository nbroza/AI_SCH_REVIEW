# Power Integrity Best Practices

## Power Distribution Network (PDN) Design

### Fundamental PDN Design Goal

**Target Impedance:**
Choose appropriate decoupling capacitors and geometry of the PCB conductors and vias in the PDN to ensure that **ZPDN ≤ ZT-PDN** for each voltage rail over the entire frequency spectrum of interest.

**Performance Target:**
A well-designed decoupling strategy ensures that the PDN impedance remains **below a target value—often less than 1 mΩ at critical frequencies**—to maintain signal integrity.

### Target Impedance Calculation

Target impedance is typically calculated as:

```
ZT-PDN = Vripple / Itransient
```

Where:
- Vripple = allowable voltage ripple (e.g., 5% of rail voltage)
- Itransient = maximum transient current draw

## Decoupling Capacitor Selection

### Capacitor Selection Criteria

When selecting decoupling capacitors, consider:

1. **Frequency Bands**: Select capacitors to suppress specific frequency ranges
2. **Resonance Points**: Understand self-resonant frequency (SRF) of each capacitor
3. **ESL and ESR**: Lower equivalent series inductance (ESL) and equivalent series resistance (ESR) provide better performance
4. **Capacitor Technology**: Ceramic capacitors (X7R, X5R, C0G) offer the lowest ESR and ESL values

### Multi-Value Decoupling Strategy

**Best Practice:**
Use a **combination of capacitor values**—such as 0.01 μF, 0.1 μF, and 10 μF—to cover a frequency range from 100 kHz to 100 MHz. This ensures comprehensive noise suppression across the spectrum.

**Typical Decoupling Hierarchy:**
- **Bulk capacitors** (10 µF – 100 µF): Low-frequency decoupling, hold-up time
- **Mid-range capacitors** (1 µF – 10 µF): Medium-frequency decoupling
- **High-frequency capacitors** (0.01 µF – 0.1 µF): High-frequency noise suppression
- **Very high-frequency** (pF range): For ultra-high-speed circuits

### Capacitor Placement

**Critical Rule:**
The closer a decoupling capacitor is to the power pin of an IC, the more effective it will be. **Ideally, place capacitors within 1-2 mm of the power pin.**

**Why Proximity Matters:**
- Minimizes inductance of the connection loop
- Reduces the impedance seen by the IC
- Provides faster response to transient currents

## Power Plane Design

### Layer Stacking Strategy

**Best Practice:**
Place power and ground planes on **adjacent layers** to maximize interplane capacitance, which helps with high-frequency decoupling.

**Common 4-Layer Stackup:**
```
Layer 1: Signal (Top)
Layer 2: Ground
Layer 3: Power
Layer 4: Signal (Bottom)
```

This ensures tight coupling between power and ground, creating distributed capacitance.

**Interplane Capacitance:**
Capacitance between power and ground planes is approximately:

```
C = ε₀ × εr × A / d
```

Where:
- ε₀ = permittivity of free space
- εr = relative permittivity of dielectric (typically 4.2 for FR-4)
- A = overlapping area of planes
- d = distance between planes

**Target**: Keep d < 0.1 mm (4 mils) for maximum capacitance and low PDN impedance.

## Analysis and Simulation

### Pre-Layout Verification

**Best Practice:**
Before finalizing your PCB layout, **simulate the power delivery network** to identify potential issues with impedance or resonance.

**Simulation Tools:**
- SPICE or dedicated PDN analysis software
- Target impedance vs. frequency plots
- Identify resonances and gaps in decoupling coverage

**What to Verify:**
- PDN impedance is below target across all frequencies
- No resonant peaks exceed the target impedance
- Adequate decoupling for all transient events

## Common PDN Design Challenges (2024)

### Challenge 1: Excessive PDN Impedance
**Cause**: Insufficient decoupling capacitance or poor capacitor placement
**Solution**: Add more capacitors, move capacitors closer to power pins, reduce via inductance

### Challenge 2: Resonance Peaks
**Cause**: Self-resonance of decoupling capacitors or anti-resonance between multiple capacitors
**Solution**: Stagger capacitor values to avoid overlapping resonances, add damping resistors if necessary

### Challenge 3: DC Drop
**Cause**: Insufficient copper cross-section in power distribution
**Solution**: Widen power traces, use power planes, reduce trace length

### Challenge 4: High-Frequency Noise
**Cause**: Inadequate high-frequency decoupling
**Solution**: Add more small-value capacitors (0.01 µF, 0.001 µF) close to IC power pins

## Ground Architecture for Mixed-Signal Designs

### Low-Current Mixed-Signal Systems

**Best Practice:**
For mixed-signal systems with a single ADC or DAC with low digital current, a **solid single ground plane** is the best approach.

Mixed-signal ICs with low digital currents are generally best treated as analog devices and grounded and decoupled to the analog ground plane.

### Split Ground Plane Approach

**When to Use:**
For systems with high digital currents and sensitive analog circuits

**Critical Implementation Rule:**
If you split analog and digital ground planes, then you **MUST connect the analog and digital grounds together at the ADC/DAC**, not elsewhere on the PCB. This creates the system "star" ground at the mixed-signal device.

**Important Caveat:**
The best approach in most mixed-signal systems and with most ADCs is to use a **uniform ground plane, not physically separated grounds**.

### What to Avoid

**Never overlap ground planes**, especially analog and digital grounds. This will cause capacitive coupling of noise from digital ground into analog ground.

## Sources

- [What is Power Integrity and PDN | Sierra Circuits](https://www.protoexpress.com/blog/power-integrity-pdn-and-decoupling-capacitors/)
- [Power Integrity, PDN, and Decoupling Capacitors | by Sierra Circuits | Medium](https://medium.com/@Sierra_circuits/power-integrity-pdn-and-decoupling-capacitors-d91ec80cf7e3)
- [4 Common PDN Design Challenges | Sierra Circuits](https://www.protoexpress.com/blog/common-pdn-design-challenges-and-how-to-resolve/)
- [Decoupling Capacitor Optimization and Resources for Power Integrity | Blog | Altium Designer](https://resources.altium.com/p/decoupling-capacitor-optimization-power-integrity)
- [The Ultimate Guide to Power Plane Decoupling: Capacitors, Placement, and Strategies](https://www.allpcb.com/blog/pcb-knowledge/the-ultimate-guide-to-power-plane-decoupling-capacitors-placement-and-strategies.html)
- [What Are the Basic Guidelines for Layout Design of Mixed-Signal PCBs? | Analog Devices](https://www.analog.com/en/resources/analog-dialogue/articles/what-are-the-basic-guidelines-for-layout-design-of-mixed-signal-pcbs.html)
- [Staying Well Grounded | Analog Devices](https://www.analog.com/en/resources/analog-dialogue/articles/staying-well-grounded.html)
