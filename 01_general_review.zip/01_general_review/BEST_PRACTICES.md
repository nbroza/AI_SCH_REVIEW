# General Schematic Review Best Practices

## IPC Standards for PCB/Schematic Design

### Key Standards

**IPC-2221**: Establishes standards for PCB design aspects including schematic, material selection, thermal management, DFM, DFA, DFT, and quality assurance. **Best practice is to start every PCB design with IPC-2221**, then apply the correct IPC-222x sectional standard based on board type (rigid, flex, HDI, PC card, or MCM-L).

**IPC-7351**: Optimizes footprints for automated assembly.

**IPC-A-600**: Defines what a "good" PCB looks like in terms of copper thickness, hole wall integrity, and solder mask adhesion.

**IPC-J-STD-001**: Soldering requirements standard.

**IPC-A-610**: Acceptability criteria for assembly quality.

### Design Philosophy

A brilliant schematic means nothing if it can't be produced efficiently. Without proper design rules, designers risk creating boards that function in a simulation but fail in reality. IPC standards ensure quality, reliability, and consistency in PCB design, manufacturing, and assembly.

## Component Selection and BOM Management

### Component Lifecycle Management

- **Software Integration and PLM**: PCB designers often lack the supply chain visibility essential for effective obsolescence management. Product lifecycle management software integrated into PCB design software can immediately identify soon-to-be-obsolete components.

- **Obsolescence Statistics**: 37% of parts become obsolete without notice. Obsolescence is no longer an exception—it's the norm.

- **Multi-Sourcing Strategy**: Incorporate dual or multi-sourcing of components during the initial design phase to avoid sole-source dependencies.

- **Proactive Monitoring**: Set up feeds for Product Discontinuance Notices (PDNs), use lifecycle forecasting tools, and run monthly BOM scans to catch potential issues before they become blockers.

- **Design Flexibility**: Select components with longer projected lifespans while ensuring that the design accommodates future changes in part availability.

### Reference Designators and Design Coordination

The reference designator is the most immediate and reliable method of aligning the BOM, schematic, and netlist. Any alterations must be present in all three locations to ensure the board's documentation remains in lockstep.

Cross-probing between schematic and board layout allows designers to quickly group components proximally according to the reference designators used in the schematic pages.

## Design Review Process

### Risk Assessment Approach

Quickly analyzing PCB design risks requires a systematic approach that combines automated tools with engineering expertise. Key methodologies include:

- Schematic analysis
- Layout review
- Advanced simulations
- Risk prioritization
- Documentation

Design teams can significantly reduce the likelihood of costly design flaws through systematic review.

### Early Detection Benefits

PCB design review before simulation and prototyping stages provides rapid detection and correction for manufacturing and EMC faults to reduce costs.

### Review Checklist

Irrespective of the complexity or size of the board, maintain a PCB layout review checklist so that the review process can be streamlined. The checklist should cover:

- Component placement
- Routing
- Dimensions
- Silkscreens
- Manufacturability

## Sources

- [A Full Guide of the IPC Standards for Printed Circuit Boards](https://www.mclpcb.com/blog/ipc-standards-for-pcbs/)
- [IPC-2221 Standards in PCB Design | Sierra Circuits](https://www.protoexpress.com/blog/ipc-2221-circuit-board-design/)
- [IPC Classes and Complying with IPC Standards for PCB Design](https://resources.altium.com/p/complying-with-ipc-standards-for-pcb-design)
- [IPC Standards: The Definitive Guide for Electronics Engineers and PCB Designers](https://www.wevolver.com/article/mastering-ipc-standards-the-definitive-guide-for-electronics-engineers-and-pcb-designers)
- [Component Obsolescence Management for Electronics Design](https://resources.altium.com/p/managing-component-obsolescence)
- [Managing Electronic Component Obsolescence: Practical Insights for Engineering Managers](https://resources.altium.com/p/managing-electronic-component-obsolescence-practical-insights-engineering-managers)
- [How to Quickly Analyze PCB Design Risk Issues - Andwin Circuits](https://www.andwinpcb.com/how-to-quickly-analyze-pcb-design-risk-issues/)
- [PCB Layout Review Checklist | Advanced PCB Design Blog | Cadence](https://resources.pcb.cadence.com/blog/2023-pcb-design-and-risk-benefit-analysis-in-component-placement)
