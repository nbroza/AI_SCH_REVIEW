# General Review — Schematic Review Context

## Purpose

This is the **first-pass review** of a schematic design. The goal is to understand the overall design intent, verify the block-level architecture is sound, and identify any high-level issues before diving into specialized reviews. This review establishes the baseline understanding that all subsequent reviews depend on.

## Prerequisites

Before beginning this review, ensure the following are available:

- Exported netlist (component pins, net connections, net names)
- Bill of Materials (BOM) with manufacturer part numbers and values
- Design requirements or specification document (if available)
- All relevant datasheets collected in the `../datasheets/` folder

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`01_general_review/`). These files may contain project-specific context, prior review notes, known design constraints, or supplemental best-practice checklists that must be considered during this review.

Additionally, reference datasheets in `../datasheets/` as needed when verifying component usage and design intent.

## When to Ask the User for Clarification

You are expected to **ask the user for clarification** whenever:

- The design intent for a circuit block is unclear
- You cannot determine whether a component choice is intentional or an error
- The operating environment or use case is ambiguous (consumer, industrial, automotive, aerospace, medical)
- You encounter design patterns that could be intentional tradeoffs or mistakes
- Requirements or specifications are not provided and you need them to evaluate correctness

**Do not guess. Ask.**

---

## Review Checklist

### 1. Net & Component Inventory

- [ ] Power rail net names are identifiable and consistent (e.g., `VCC_3V3`, `VDD_1V8`, `VIN_12V`)
- [ ] Ground nets are identifiable (e.g., `GND`, `AGND`, `PGND`, `CHASSIS_GND`)
- [ ] Net names are consistent — no unintentional near-duplicates (e.g., `SPI_CLK` vs `SPI_SCLK`)

### 2. Power Architecture Overview

- [ ] All voltage rails in the design are identified and documented
- [ ] Input power source(s) are clearly defined (DC jack, USB, battery, backplane, etc.)
- [ ] Power conversion topology is identifiable (LDO, buck, boost, SEPIC, charge pump, etc.)
- [ ] Voltage rail relationships are logical (higher voltage rails feed lower ones, not vice versa)
- [ ] Each IC and active component has its power pins connected to appropriate rails
- [ ] Bulk and local decoupling capacitors are present (detailed review in dedicated check)
### 3. Component Completeness

- [ ] Every IC has all power pins connected (VCC, VDD, AVDD, DVDD, etc.)
- [ ] Every IC has all ground pins connected (GND, AGND, DGND, PGND, etc.)
- [ ] No-connect (NC) pins are explicitly marked with no-connect symbols, not left floating
- [ ] All passive components have values specified (resistance, capacitance, inductance)
- [ ] All passive components have voltage/current ratings where relevant
- [ ] BOM part numbers are populated for all components (or flagged as TBD)

### 4. Connector & Interface Inventory

- [ ] All external connectors are identified and their purpose is clear
- [ ] Connector pinouts match their mating connectors or cable assemblies
- [ ] Keying or polarity protection is present where needed (power connectors especially)
- [ ] All board-to-board connections are accounted for on both sides
- [ ] Debug and programming connectors are present

---

## Common Issues Found in General Review

| Issue | Severity | Description |
|-------|----------|-------------|
| Missing power pins | Critical | IC power or ground pins not connected |
| Inconsistent net names | Major | Same signal with different names causing disconnection |
| BOM gaps | Major | Components without part numbers or specifications |

## Severity Classification

Use the following severity levels for all findings:

- **Critical**: Will cause board failure, damage, or safety hazard. Must be fixed before fabrication.
- **Major**: Will likely cause functional issues. Should be fixed before fabrication.
- **Minor**: Will not prevent function but represents poor practice or risk. Should be addressed.
- **Info**: Observation or suggestion for improvement. No functional impact.

## Output Format

Report findings as a structured list:

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet name/number, reference designator, net name]
- **Description**: [What was found]
- **Recommendation**: [What should be changed]
- **Reference**: [Datasheet page, standard, or best practice source]
```
