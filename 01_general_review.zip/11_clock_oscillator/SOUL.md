# Clock & Oscillator Review — Schematic Review Context

## Purpose

This review validates **crystal oscillator circuits, clock generation, and clock distribution networks** against datasheet specifications and best practices. Clock circuits are deceptively simple in appearance but are one of the most common sources of field failures — an oscillator that marginally works on the bench may fail across temperature, voltage, or production variation.

Getting the crystal load capacitance wrong is the single most common clock circuit error.

## Prerequisites

- Exported netlist
- Crystal/oscillator datasheets in `../datasheets/`
- IC datasheets (oscillator section) in `../datasheets/`
- Clock frequency requirements for all subsystems
- Temperature range and stability requirements

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`11_clock_oscillator/`). These may contain clock tree diagrams, jitter budgets, crystal vendor application notes, or frequency planning documents.

Reference datasheets in `../datasheets/` for both the crystal/oscillator specifications and the IC's oscillator interface requirements.

## When to Ask the User for Clarification

Ask the user when:

- The PCB stray capacitance is unknown (affects load capacitor calculation — typically 2-5pF)
- Frequency accuracy requirements are not specified (determines crystal tolerance and stability)
- The operating temperature range affects crystal selection and you don't know the range
- You cannot find the oscillator design recommendations in the IC datasheet
- The clock distribution topology is not clear from the schematic
- Jitter or phase noise requirements exist but are not documented
- An external clock source is used but its specifications are not available

**Crystal circuit calculations require knowing the stray capacitance. If not specified, state your assumption and flag it.**

---

## Review Checklist

### 1. Crystal Load Capacitance Calculation

This is the **most critical check** for any crystal oscillator circuit.

- [ ] Identify the crystal's specified load capacitance (CL) from its datasheet
- [ ] Calculate the circuit's effective load capacitance:

  **For two external capacitors (most common Pierce oscillator):**
  ```
  CL_effective = (C1 × C2) / (C1 + C2) + C_stray
  ```
  Where:
  - C1 = capacitor on XIN pin
  - C2 = capacitor on XOUT pin
  - C_stray = PCB stray capacitance (typically 2-5pF per pin, total both sides)

- [ ] Verify CL_effective matches the crystal's specified CL within ±10%
- [ ] If CL is wrong:
  - **Too low**: frequency runs high, may fail to oscillate at temperature extremes
  - **Too high**: frequency runs low, increased drive power, potential crystal damage

- [ ] For ICs with internal load capacitors:
  - Check the datasheet for internal capacitance values
  - Calculate if external capacitors are needed: CL_external = CL_crystal - CL_internal - C_stray
  - If CL_external ≤ 0, no external capacitors needed (but verify this is intentional)

- [ ] Calculate actual frequency offset from nominal:
  ```
  Δf/f = (CL_actual - CL_specified) / (2 × (CL_specified + C_motional))
  ```
  Where C_motional is the crystal's motional capacitance (C1 in the equivalent circuit, from crystal datasheet)

### 2. Crystal Selection Verification

- [ ] Crystal frequency matches the IC's required input frequency
- [ ] Crystal frequency tolerance (at 25°C) meets the application requirement:
  - USB: ±50ppm or better (2.0), ±500ppm with SOF correction
  - UART: ±0.5% (5000ppm) at the baud rate
  - Ethernet: ±50ppm (100BASE-TX), ±100ppm (10BASE-T)
  - Bluetooth: ±20ppm
  - General timing: application-dependent
- [ ] Crystal frequency stability over temperature meets the operating range requirement
- [ ] Crystal's rated drive level is not exceeded by the oscillator circuit
- [ ] Crystal's maximum ESR (Equivalent Series Resistance) is within the IC oscillator's specifications
- [ ] Fundamental mode vs. overtone mode matches the IC's oscillator design

### 3. Oscillator Circuit Topology

#### Pierce Oscillator (most common for MCU/FPGA)
- [ ] Two load capacitors present (C1 on XIN, C2 on XOUT)
- [ ] Feedback resistor across the crystal (if required by IC — typically 1MΩ to 10MΩ)
- [ ] Series resistor on XOUT (if specified by IC datasheet — limits drive level)

#### Colpitts / Other Topologies
- [ ] Topology matches the IC's oscillator design requirements
- [ ] All required external components are present
- [ ] Biasing is correct

#### External Oscillator / Clock Source
- [ ] Oscillator module output level matches the IC's clock input threshold
- [ ] Oscillator module supply voltage is correct
- [ ] Decoupling capacitor is present on the oscillator module supply pin
- [ ] If CMOS output: verify LVCMOS levels match the receiver
- [ ] If differential output (LVDS, LVPECL, HCSL): proper termination at receiver
- [ ] Standby/enable pin is properly managed

### 4. Drive Level Analysis

- [ ] Calculate the crystal drive level to ensure it does not exceed the crystal's maximum:
  ```
  P_drive = ESR × I_motional²
  ```
  Or approximate from the IC's oscillator specification

- [ ] If the IC datasheet does not specify drive level:
  - Check for a series resistor recommendation on XOUT (limits drive)
  - High drive levels cause:
    - Crystal aging (frequency drift over time)
    - Crystal fracture (extreme cases)
    - Activity dips at certain temperatures
  - Low drive levels cause:
    - Failure to start oscillation
    - Long startup time
    - Increased jitter

### 5. Startup & Reliability

- [ ] Crystal startup time is acceptable for the application:
  - Typical startup: 2-10ms for AT-cut crystals
  - IC reset must be held long enough for the oscillator to stabilize
  - If the IC has an internal startup timer, verify it is long enough
- [ ] Negative resistance margin ensures reliable oscillation:
  - Oscillator circuit negative resistance > 5× crystal ESR (recommended minimum)
  - This ensures startup across temperature, voltage, and manufacturing variation
- [ ] Crystal aging specification is acceptable for the product lifetime
- [ ] Crystal is specified for the correct temperature range

### 6. Clock Distribution

- [ ] Clock fanout is within the driver's capability:
  - Total load capacitance from all clock inputs + trace capacitance
  - AC current drive capability at the clock frequency
- [ ] Clock buffers/fanout ICs are used where needed
- [ ] Clock buffer output type (LVCMOS, LVDS, LVPECL, HCSL) matches receivers
- [ ] Clock skew between receivers is acceptable for the application
- [ ] Unused clock buffer outputs are terminated (not left floating)
- [ ] Clock distribution topology is appropriate:
  - Point-to-point: adequate for single receiver
  - Star: equal-length traces to each receiver
  - Daisy-chain: last receiver terminated
  - Tree: balanced loading

### 7. PLL / Clock Synthesizer

If the design uses PLLs or clock synthesizers:

- [ ] PLL loop filter matches the datasheet recommendation
- [ ] PLL input reference frequency is within the PLL's specified range
- [ ] PLL VCO frequency range covers the required output frequency
- [ ] PLL lock time is acceptable for the application
- [ ] PLL loop bandwidth is appropriate (affects jitter filtering)
- [ ] PLL supply filtering is adequate (sensitive to power supply noise)
- [ ] PLL output divider settings produce the correct output frequency
- [ ] Spread-spectrum clocking (if used) is configured correctly:
  - Spread percentage is within the interface specification's tolerance
  - Spread profile (triangle, Hershey kiss) is correct

### 8. Special Frequency Considerations

- [ ] USB: 48MHz or 12MHz crystal/oscillator meets USB specification
- [ ] Ethernet: 25MHz or 50MHz matches the PHY's requirements
- [ ] CAN: clock accuracy meets CAN specification requirements (typically ±0.5% including all error sources)
- [ ] RF applications: crystal/TCXO/OCXO meets the required stability
- [ ] RTC (Real-Time Clock): 32.768kHz crystal with appropriate load caps
  - 32.768kHz crystals are particularly sensitive to load cap mismatch
  - Typical CL: 6-12.5pF
  - PCB stray capacitance has a larger relative impact at these low frequencies

---

## Common Clock & Oscillator Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| Wrong load capacitors | Major | Frequency offset, possible failure to oscillate |
| Missing feedback resistor | Major | IC-dependent — some require it for bias |
| Excessive drive level | Major | Crystal aging, potential fracture |
| Crystal ESR too high for oscillator | Critical | Failure to start oscillation |
| No series resistor limiting drive | Minor | May over-drive crystal, reducing lifetime |
| Clock buffer output floating | Minor | Unnecessary EMI from oscillating output |
| PLL loop filter wrong | Major | PLL instability, jitter, failure to lock |
| 32.768kHz crystal load caps wrong | Major | RTC time drift |

## Severity Classification

- **Critical**: Clock circuit will fail to oscillate or produce incorrect frequency causing system failure.
- **Major**: Clock will function marginally but may fail over temperature, voltage, or production variation.
- **Minor**: Non-optimal but functional.
- **Info**: Improvement for robustness or performance.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, crystal/oscillator designator, IC designator]
- **Frequency**: [Nominal frequency]
- **Description**: [What the issue is]
- **Calculation**: [Load cap calculation, drive level calculation, etc.]
- **Recommendation**: [Correct capacitor values, component change, etc.]
- **Reference**: [Crystal datasheet, IC datasheet oscillator section, application note]
```
