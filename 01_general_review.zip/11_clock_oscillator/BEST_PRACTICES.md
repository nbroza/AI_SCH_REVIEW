# Clock & Oscillator Design Best Practices

## Crystal Oscillator PCB Design Guidelines (2024)

### Component Placement

**Critical Rule:**
Place the oscillator footprint on the PCB **as close as possible** to the input pins of the load or chip. The length of traces should be as short as possible and **must not cross other signal lines**.

**Rationale:**
- Minimizes parasitic capacitance and inductance
- Reduces susceptibility to noise
- Improves frequency stability

### Trace Routing

**Avoid Right Angle Bends:**
Capacitance increases in the 45° corner region changing the characteristic impedance of the trace, leading to reflections.

**Mitigation:**
- Use 45° or curved bends instead of 90° bends
- Round right angles to reduce capacitance discontinuity

**Avoid Vias:**
Do **not use vias in the crystal traces** where possible. Vias add parasitic inductance and capacitance.

**If vias are necessary:**
- Use minimum number of vias
- Keep via stubs as short as possible
- Place vias as close to crystal as possible

### Ground Plane Considerations

**Keep-Out Area:**
Do **not run digital / RF signal lines or power under crystal unit** for multi-layered PCB. Treat crystal component area as a **keep-out area** for signal routing on other layers.

**Rationale:**
- Prevents coupling of noise into crystal oscillator
- Avoids parasitic capacitance from underlying traces
- Maintains frequency stability

**Ground Plane Under Crystal:**
- Acceptable to have solid ground plane under crystal
- Ground plane provides shielding from noise on other layers

### Impedance Matching

**Series Termination:**
Use series termination to reduce standing waves between source and termination. Insert a resistor in series **as close to the output pin of the oscillator** as possible.

**Resistor Value:**
```
Rseries + Zout(oscillator) = Z0(trace)
```

**Example:**
- Trace impedance Z0 = 50Ω
- Oscillator output impedance Zout = 15Ω
- Series resistor Rseries = 35Ω

### Load Capacitance

**Critical Concept:**
The output frequency of the crystal resonator in the circuit is affected by the **equivalent load capacitance** of the circuit. The optimal output frequency is derived when the effective load capacitance on the PCB **equals the load capacitance specified in the crystal datasheet**.

**Load Capacitance Calculation:**
```
CL = (C1 × C2) / (C1 + C2) + Cstray
```

Where:
- CL = load capacitance specified in crystal datasheet (typically 12pF, 15pF, 18pF, or 20pF)
- C1, C2 = external load capacitors
- Cstray = stray capacitance (typically 2-5pF)

**Solving for External Capacitors (if C1 = C2):**
```
C1 = C2 = 2 × (CL - Cstray)
```

**Example:**
- Crystal specifies CL = 18pF
- Estimated Cstray = 3pF
- C1 = C2 = 2 × (18pF - 3pF) = 30pF

### Crystal Selection

**Frequency Accuracy:**
- ±20 ppm: Consumer applications
- ±10 ppm: Communication devices
- ±1 ppm or better: Precision timing applications

**Temperature Stability:**
- Check frequency drift over operating temperature range
- AT-cut crystals provide good temperature stability

**Load Capacitance:**
- Match crystal load capacitance to available capacitor values
- Common values: 12pF, 15pF, 18pF, 20pF

**ESR (Equivalent Series Resistance):**
- Lower ESR = easier to start oscillation
- Verify MCU/oscillator can drive the crystal ESR

### Oscillator vs. Crystal

**Crystal:**
- Requires external load capacitors
- MCU provides oscillator circuit
- Lower cost
- More sensitive to layout

**Crystal Oscillator (XTAL OSC):**
- Complete oscillator in package
- No external components required
- Higher cost
- Less sensitive to layout
- Better frequency accuracy and stability

**Best Practice:**
Use crystal oscillator for critical timing applications, use crystal + MCU oscillator for cost-sensitive designs.

### Clock Distribution

**Buffering:**
For clocks driving multiple loads, use a **clock buffer** (fan-out buffer) rather than driving multiple loads directly from oscillator.

**Benefits:**
- Reduces load on oscillator
- Provides controlled impedance outputs
- Enables skew control

**Clock Buffer Selection:**
- Low jitter (<100ps for high-speed applications)
- Appropriate output drive strength
- Enable/disable control for power management

### Spread-Spectrum Clocking (SSC)

**Purpose:**
Spread-spectrum clocking **reduces EMI** by dithering the clock frequency over a small range (typically ±0.5% to ±1%).

**Applications:**
- USB (supports SSC)
- PCIe (requires SSC for EMI compliance)
- SATA (supports SSC)

**Compatibility:**
- Verify that downstream devices tolerate SSC
- Some high-precision ADCs may not tolerate SSC jitter

### Common Oscillator Issues

**Oscillator Won't Start:**
- Load capacitance too high or too low
- ESR of crystal too high for oscillator circuit
- Insufficient drive level from MCU
- PCB layout issues (too much stray capacitance)

**Frequency Inaccuracy:**
- Load capacitance mismatch
- Temperature drift
- Aging of crystal

**Jitter / Phase Noise:**
- Noisy power supply to oscillator
- Crosstalk from adjacent signals
- Poor ground plane

### Oscillator Circuit Types

**Pierce Oscillator:**
- Most common for MCU crystal oscillators
- Requires two load capacitors

**Colpitts Oscillator:**
- RF applications
- Uses inductors and capacitors

**CMOS Oscillator:**
- Simple inverter-based circuit
- Used in most MCU crystal oscillators

## Sources

- [Crystal & Oscillator PCB Design Considerations | ECS Inc.](https://ecsxtal.com/crystal-and-oscillator-printed-circuit-board-design-considerations/)
- [Best Practices for Crystal Oscillator Layout (2/3) - Byte Lab](https://www.byte-lab.com/best-practices-for-crystal-oscillator-layout-2-3/)
- [Crystal Oscillator: PCB Design Rules & Manufacturing Guide](https://www.elepcb.com/blog/crystal-oscillator-guide/)
- [Crystal Oscillators in Your PCB Layout Keep Frequencies Steady | PCB Design Blog | Altium Designer](https://resources.altium.com/p/crystal-oscillators-your-pcb-layout-keep-frequencies-steady)
- [Crystal Oscillator PCB Layout Guidelines - VSE](https://www.vse.com/blog/crystal-oscillator-pcb-layout-guidelines/)
- [AVR 8-bit Microcontrollers - Best Practices for the PCB Layout of Oscillators - Microchip](https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-8128-Best-Practices-for-the-PCB-Layout-of-Oscillators_ApplicationNote_AVR186.pdf)
