# Thermal & Derating Review — Schematic Review Context

## Purpose

This review performs a **component-level stress analysis**, verifying that every component operates within safe margins of its rated voltage, current, power, and temperature limits. It checks actual operating conditions against datasheet absolute maximum ratings and recommended operating conditions, applying appropriate derating factors for reliability.

The goal is to ensure the design has adequate margin for long-term reliability — not just "does it work on the bench at room temperature."

## Prerequisites

- Exported netlist
- BOM with specific part numbers and package types
- Operating environment specification (ambient temperature range, airflow, altitude)
- Load current data for all power paths
- Power dissipation estimates (or the ability to calculate them)
- All datasheets in `../datasheets/`

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`09_thermal_derating/`). These may contain corporate derating standards, industry-specific derating requirements (military, automotive, aerospace), thermal simulation data, or prior thermal analysis results.

Reference datasheets in `../datasheets/` for absolute maximum ratings, recommended operating conditions, and thermal resistance specifications.

## When to Ask the User for Clarification

Ask the user when:

- The operating ambient temperature range is not specified
- Airflow conditions are unknown (natural convection vs. forced air vs. sealed enclosure)
- Board layer stackup is unknown (affects thermal spreading)
- Component power dissipation values cannot be determined from available information
- The reliability class is not specified (consumer, industrial, automotive, military, aerospace)
- Altitude or reduced air pressure environments apply (affects convection cooling)
- Thermal management features (heat sinks, thermal pads, thermal vias) are planned but not on the schematic

**Derating requirements vary dramatically between consumer electronics and aerospace. Ask about the reliability class.**

---

## Review Checklist

### 1. Standard Derating Factors

Apply these minimum derating factors unless the project specifies different requirements:

| Parameter | Consumer | Industrial | Military/Aerospace |
|-----------|----------|------------|-------------------|
| Voltage (capacitors) | 80% of rated | 60% of rated | 50% of rated |
| Voltage (semiconductors) | 80% of rated | 75% of rated | 70% of rated |
| Current (continuous) | 80% of rated | 70% of rated | 60% of rated |
| Power dissipation | 80% of rated | 70% of rated | 50% of rated |
| Junction temperature | TJ_MAX - 20°C | TJ_MAX - 25°C | TJ_MAX - 25°C |
| Capacitor temperature | 85% of rated | 80% of rated | 70% of rated |
| Inductor current | 80% of rated | 70% of rated | 60% of rated |

### 2. Resistor Derating

For every resistor (focus on power-dissipating resistors — not signal-level pull-ups):

- [ ] Calculate actual power dissipation: P = I²R or P = V²/R
- [ ] Verify power dissipation is within the derated power rating at the operating temperature
- [ ] Check resistor power rating derating curve:
  - Most resistors are rated at 70°C and derate linearly to 0W at 155°C (or similar)
  - At 85°C ambient, a "1/4W" resistor may only be rated for 0.15W
- [ ] Resistors dissipating >50% of rated power should be flagged for review
- [ ] Current-sense resistors: verify pulse power rating in addition to continuous rating
- [ ] High-value resistors (>1MΩ): verify voltage rating is not exceeded (voltage coefficient issues)

### 3. Capacitor Derating

- [ ] **Voltage derating**:
  - Ceramic capacitors: maximum applied voltage ≤ 80% of rated voltage (consumer) or 50% (military)
  - Electrolytic capacitors: maximum applied voltage ≤ 80% of rated voltage
  - Tantalum capacitors: maximum applied voltage ≤ 50% of rated voltage (tantalum are failure-prone under voltage stress)
  - Film capacitors: maximum applied voltage ≤ 80% of rated voltage
- [ ] **DC bias derating for MLCCs**:
  - X7R/X5R ceramics lose significant capacitance under DC bias
  - A 10µF 6.3V X5R cap may only provide 4µF at 5V bias
  - Verify effective capacitance at the operating voltage meets minimum requirements
  - C0G/NP0 caps do not have significant DC bias derating
- [ ] **Temperature derating for MLCCs**:
  - X7R: ±15% over -55 to +125°C
  - X5R: ±22% over -55 to +85°C
  - Y5V: +22/-82% — effectively unusable at temperature extremes
- [ ] **Ripple current rating** (for caps in switching power supplies):
  - Verify RMS ripple current is within the cap's rated ripple current
  - Check self-heating from ripple current
- [ ] **Surge voltage rating** for tantalum and aluminum electrolytic capacitors

### 4. Semiconductor Derating (ICs, Transistors, Diodes)

#### Junction Temperature Analysis
For all power-dissipating semiconductors:

- [ ] Calculate power dissipation at worst-case operating conditions
- [ ] Calculate junction temperature:
  - TJ = TA + (PD × θJA) — for simple analysis
  - TJ = TA + (PD × θJC) + (PD × θCA) — if heat sinking is involved
- [ ] Verify TJ is below the derated maximum junction temperature
- [ ] Account for thermal resistance of the PCB (θJA values assume a specific test board)

#### Voltage Derating
- [ ] Maximum applied voltage ≤ 80% of absolute maximum rating (consumer)
- [ ] Drain-source voltage on MOSFETs includes transient spikes (inductive loads, ringing)
- [ ] Collector-emitter voltage on BJTs includes inductive flyback
- [ ] Reverse voltage on diodes includes ringing above steady-state value

#### Current Derating
- [ ] Continuous current ≤ 80% of maximum rated current at operating temperature
- [ ] Peak/pulse current within SOA (Safe Operating Area) for transistors
- [ ] Diode forward current derated for temperature (check derating curve)
- [ ] MOSFET RDS(on) increases with temperature — verify current capability at TJ, not at 25°C

### 5. Inductor Derating

- [ ] DC bias current is below the derated saturation current at operating temperature
  - Inductor saturation current decreases with temperature (typically 10-30% reduction at 85°C vs 25°C)
- [ ] RMS current is within the rated temperature rise limit
- [ ] Core losses at the switching frequency are accounted for
- [ ] For coupled inductors: verify mutual heating effects

### 6. Connector Derating

- [ ] Contact current ≤ 80% of rated current per pin
- [ ] If multiple pins carry power: account for thermal coupling between adjacent pins
- [ ] Contact voltage rating is sufficient for the application
- [ ] Temperature rating of connector housing is compatible with the operating environment
- [ ] Mating cycle rating is sufficient for the product lifetime

### 7. Fuse & Protection Device Derating

- [ ] Fuse current rating is selected to:
  - Not blow under maximum normal operating current (with temperature derating)
  - Blow reliably under fault conditions
  - Account for ambient temperature (fuse ratings are typically at 25°C)
- [ ] Fuse voltage rating exceeds the maximum system voltage
- [ ] Fuse breaking capacity is sufficient for the available fault current
- [ ] TVS diode clamping voltage is within the protected IC's absolute maximum rating
- [ ] TVS diode peak pulse power rating is sufficient for the expected transient energy

### 8. Worst-Case Analysis

- [ ] Perform worst-case analysis at the maximum operating temperature
- [ ] Account for component tolerance stacking:
  - Resistor divider with ±1% resistors: output voltage varies by ±2%
  - Filter with ±10% capacitor and ±5% resistor: cutoff frequency varies significantly
- [ ] Verify critical circuits function at worst-case component tolerances
- [ ] Check for conditions that worsen with aging:
  - Electrolytic capacitor ESR increases with age
  - LED brightness decreases with age
  - Battery internal resistance increases with age

---

## Common Thermal & Derating Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| LDO junction temp exceeds TJ_MAX | Critical | Thermal runaway or shutdown |
| Capacitor voltage exceeds derated limit | Major | Reduced reliability, potential failure |
| Tantalum cap at >50% rated voltage | Major | High risk of short-circuit failure |
| MLCC effective capacitance too low | Major | Regulator instability due to DC bias derating |
| MOSFET RDS(on) not derated for temperature | Major | Higher losses than calculated, thermal runaway risk |
| Resistor power exceeds derated limit | Major | Overheating, value shift, potential fire |
| Fuse not derated for temperature | Major | Nuisance blowing or failure to protect |

## Severity Classification

- **Critical**: Component will exceed absolute maximum rating under specified operating conditions.
- **Major**: Component operating outside derated limits — reliability concern.
- **Minor**: Component within absolute maximum but outside recommended operating conditions.
- **Info**: Derating suggestion for improved reliability.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Component**: [Reference designator, MPN, package]
- **Parameter**: [Voltage / Current / Power / Temperature]
- **Rated Value**: [Datasheet maximum]
- **Derated Limit**: [After applying derating factor]
- **Actual Operating Value**: [Calculated or measured]
- **Margin**: [Percentage margin remaining, or amount exceeded]
- **Recommendation**: [Upsize component, improve thermal path, etc.]
- **Reference**: [Datasheet page for rating, derating standard used]
```
