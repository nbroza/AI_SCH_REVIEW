# Thermal Management & Derating Best Practices

## Thermal Management Fundamentals

### Temperature and Component Reliability

**Critical Principle:**
Temperature is the first element affecting component performance and failure rate. The highest allowable working temperature and power consumption should be determined according to required level of reliability and the distributed failure rate of each component.

### Derating Strategy

**Purpose:**
Derating design makes components work in below-rated parameter conditions, such as power, voltage, or current, which will dramatically **reduce temperature rise and failure rate**.

**Application:**
Derating is specifically used to decrease temperature rising in components.

## Industry Standards

### IPC-2152

**Focus**: Current-carrying capacity and temperature rise in PCB traces

**Key Specifications:**
- Trace width vs. current capacity tables
- Temperature rise vs. ambient temperature
- Internal vs. external layer derating

### IPC-2221

**Focus**: General guidelines for PCB design including thermal management

**Coverage:**
- Thermal vias and heat spreading
- Component placement for heat dissipation
- Thermal relief connections

### JEDEC Standards

**Focus**: Component-level thermal management guidelines for semiconductors and ICs

**Key Documents:**
- JESD51 series: Thermal measurement methodologies
- JESD15 series: Package thermal characteristics

## Component-Specific Thermal Considerations

### Power Semiconductors

**Typical Requirements:**
- Significant derating above 25°C ambient
- Derating curve typically shows linear reduction in power handling vs. temperature
- May require external heatsink above certain power levels

**Example**: MOSFETs, IGBTs, voltage regulators

### Ceramic Capacitors

**Temperature Effects:**
- Capacitance shifts with temperature (especially X7R, X5R dielectrics)
- May experience -30% to -50% capacitance at maximum rated temperature
- Affects filtering performance in power supplies

**Mitigation:**
- Use C0G/NP0 dielectrics where capacitance stability is critical
- Oversize capacitors to account for temperature-induced capacitance loss

### Resistors

**Power Derating:**
- Rated power applies at 25°C or 70°C (check datasheet)
- Derating typically required above rated temperature
- Power handling decreases linearly with temperature

**Example**: 1/4W resistor at 25°C may only handle 1/8W at 125°C

### Electrolytic Capacitors

**Lifetime Relationship:**
For every 10°C increase in operating temperature, electrolytic capacitor lifetime is **cut in half** (Arrhenius equation).

**Design Guideline:**
Keep electrolytic capacitors as cool as possible. Place away from heat sources.

## Thermal Via Design

### Via Thermal Resistance

**Key Parameters:**
- **Larger diameter vias** provide lower thermal resistance
- **0.2-0.3mm diameter** is common for thermal applications
- **Via spacing**: 0.5-1.0mm center-to-center for effective heat spreading

### Via Array Design

**Best Practice:**
Use an array of thermal vias under heat-generating components to conduct heat to internal or bottom copper layers.

**Pattern:**
- Grid pattern provides uniform heat spreading
- Typical array: 5×5 to 10×10 vias under large components
- Fill vias with thermal epoxy or conductive paste for improved performance

## Component Spacing and Thermal Isolation

### Component Spacing

**Guideline:**
Space out high-power components to prevent localized heat buildup. Maintain **at least 2-3 mm clearance** between heat sources to allow better airflow or heat dissipation.

**Heat Source Identification:**
- Voltage regulators (especially linear regulators)
- Power MOSFETs and drivers
- High-current inductors
- Power resistors
- Processors and FPGAs

### Thermal Grouping

**Avoid:**
- Clustering multiple heat sources in one area
- Placing temperature-sensitive components (oscillators, references) near heat sources

**Prefer:**
- Distribute heat sources across the board
- Place sensitive components away from heat sources
- Use thermal barriers if heat sources must be nearby

## Temperature Measurement and Monitoring

### On-Board Temperature Sensing

**Applications:**
- Environmental testing and qualification
- Thermal management during operation
- Over-temperature protection

**Sensor Types:**
- Thermistor (NTC): Simple, inexpensive
- IC temperature sensor (TMP36, LM75): Digital interface, calibrated
- Thermocouple: Wide range, requires cold junction compensation

### Thermal Imaging

**Use Case:**
Verify thermal design during prototyping using thermal camera (FLIR, Seek Thermal).

**What to Check:**
- Hot spots exceeding component ratings
- Uneven heat distribution
- Inadequate heat sinking

## Derating Guidelines by Component Type

### Semiconductors (ICs, Transistors, Diodes)

**Voltage Derating**: 80-90% of absolute maximum rating
**Current Derating**: 70-80% of absolute maximum rating
**Temperature**: Operate at ≤70% of maximum junction temperature (in °C)

### Passive Components (Resistors, Capacitors, Inductors)

**Voltage Derating**: 50-70% of rated voltage (higher derating for harsh environments)
**Power Derating**: 50-75% of rated power at operating temperature
**Temperature**: Keep ≤20°C below maximum rated temperature

### Power Supply Components

**Output Current**: 70-80% of maximum rated current
**Input Voltage**: Within ±10% of nominal input voltage
**Ambient Temperature**: Design for worst-case ambient + self-heating

## Thermal Design Process

### Step 1: Power Budget

Calculate total power dissipation:
```
Ptotal = Σ(Pcomponent)
```

Identify top contributors (typically 80% of heat from 20% of components).

### Step 2: Thermal Modeling

Estimate component temperatures:
```
Tjunction = Tambient + (θJA × Pdissipation)
```

Where:
- Tjunction = junction temperature (°C)
- Tambient = ambient temperature (°C)
- θJA = junction-to-ambient thermal resistance (°C/W)
- Pdissipation = power dissipation (W)

### Step 3: Thermal Mitigation

If Tjunction > Tmax:
- Add heatsink (reduces θJA)
- Increase airflow (reduces Tambient at component)
- Reduce power dissipation (use more efficient topology)
- Use larger package with lower θJA

### Step 4: Verification

- Build prototype
- Measure component temperatures under worst-case load
- Verify all components within thermal limits
- Add margin for production variation

## Sources

- [The Most Comprehensive Principles of Thermal Design for PCBs | PCBCart](https://www.pcbcart.com/article/content/principles-of-thermal-design-for-PCB.html)
- [PCB Thermal Design Guide: Tips For PCB Analysis and Performance](https://resources.pcb.cadence.com/blog/2024-pcb-thermal-design-guide-tips-for-pcb-analysis-and-performance)
- [PCB Layout Thermal Design Guide - ROHM](https://fscdn.rohm.com/en/products/databook/applinote/common/pcb_layout_thermal_design_guide_an-e.pdf)
- [Thermal Management in PCB Design: Meeting Standards for Heat Dissipation](https://www.allpcb.com/blog/pcb-design/thermal-management-in-pcb-design-meeting-standards-for-heat-dissipation.html)
- [MT-093 TUTORIAL Thermal Design Basics - Analog Devices](https://www.analog.com/media/en/training-seminars/tutorials/mt-093.pdf)
