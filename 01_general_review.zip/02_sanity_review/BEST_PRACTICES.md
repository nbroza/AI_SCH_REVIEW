# Sanity Review Best Practices

## Netlist Verification and Connectivity Checking

### What is a Netlist?

A PCB netlist is an ASCII text file that defines a circuit's electrical connectivity by listing all connections (nets) between component pins.

### Netlist Verification Process

A netlist check, also known as a connectivity check or netlist verification, is a crucial step in the PCB design process to ensure that the netlist accurately reflects the intended circuit connectivity.

**Key verification steps include:**

1. **Component Verification**: Verify that all components listed in the netlist are present and correctly placed. Ensure that the component footprints match the ones specified in the netlist.

2. **Connectivity Verification**: Verify the connectivity between components matches the connections specified in the netlist using the PCB layout software's connectivity features to visually inspect the traces, pads, and vias.

3. **Manufacturing Verification**: CAM software can use a netlist output to verify that logical connections defined in a netlist match the actual connections in the fabrication data (Gerbers, ODB++) that will be used to produce a PCB.

### Modern Tools (2024)

Recent PCB design tools offer advanced connectivity management. OrCAD X verifies and ensures that all intended electrical connections are correctly established according to design specifications and identifies and highlights errors such as:

- Open circuits
- Short circuits
- Missing connections

## Datasheet Cross-Reference Verification

### Verification Practices

- **Pin Assignment Verification**: Cross-check component pin assignments and labels against the datasheet for accuracy. Confirm that transistor base, collector, and emitter pins match the datasheet.

- **Proper Notation**: Ensure proper notation with MPN (Manufacturer Part Number), supplier name, and part number for all schematic elements.

- **Complete Review**: When using cross-reference information, completely review all datasheets to confirm the device functionality, pinout, and performance for your application.

### Cross-Reference Resources

Several platforms provide datasheet cross-reference services (Datasheet4U, ChipFind, etc.), focusing on original manufacturer documents and cross-reference equivalents across global semiconductor brands. Always verify with manufacturer datasheets.

## Common Sanity Issues

### Power and Ground Connections

- **Swapped Rails**: Verify VCC and GND connections are correct and not reversed.
- **Missing Power Pins**: Ensure all IC power pins are connected.
- **Floating Ground Pins**: All ground pins must be connected to the appropriate ground net.

### Pin Assignment Errors

- **Incorrect Pin Mapping**: Verify critical signals (TX/RX, D+/D-, MISO/MOSI) are not swapped.
- **Package Mismatches**: Ensure the schematic symbol pin numbering matches the actual component package.

### Basic Circuit Errors

- **Pull-up/Pull-down Direction**: Verify resistors connect to the correct rail.
- **Diode Polarity**: Confirm cathode/anode orientation matches the application.
- **LED Series Resistor**: Verify current-limiting resistors are present and correctly valued.

## Sources

- [Understanding PCB Connectivity Management With OrCAD X | Cadence](https://resources.pcb.cadence.com/blog/2024-understanding-pcb-connectivity-management-with-orcad-x)
- [Schematic and Netlist Checks for Error-Free PCBs | Sierra Circuits](https://www.protoexpress.com/blog/schematic-and-netlist-checks-ensure-error-free-designs/)
- [What is a PCB Netlist | Cadence](https://resources.pcb.cadence.com/blog/what-is-a-pcb-netlist-2)
- [Component Reference Designators: Design Coordination | Cadence](https://resources.pcb.cadence.com/blog/2024-component-reference-designators-design-coordination)
- [What is a PCB Netlist and Why do You Need It?](https://blog.epectec.com/what-is-a-pcb-netlist-and-why-do-you-need-it)
