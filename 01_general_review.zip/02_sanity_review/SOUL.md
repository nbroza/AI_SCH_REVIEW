# Sanity Review — Schematic Review Context

## Purpose

The sanity review is a **fast, high-confidence check for obvious errors** that would unambiguously cause board failure. This review is not about subtlety or optimization — it is about catching the mistakes that are clearly wrong and would result in a non-functional board, damaged components, or safety hazards.

Think of this as the "would this board smoke on first power-up?" check.

## Prerequisites

- Exported netlist
- BOM with component values, ratings, and manufacturer part numbers
- Relevant datasheets in `../datasheets/`

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`02_sanity_review/`). These may contain project-specific known issues, past sanity-check failures for similar designs, or supplemental checklists.

Reference datasheets in `../datasheets/` to verify absolute maximum ratings, pin configurations, and basic operating requirements.

## When to Ask the User for Clarification

Ask the user when:

- A pin connection looks wrong but could be an intentional non-standard usage
- Component values seem unusual but might be correct for a specific application
- You cannot determine the expected voltage on a particular net
- A net connection appears to be a short but may be intentional (e.g., current sensing)
- Multiple ground net names exist and you cannot determine intent

**When in doubt about whether something is an error or intentional, ask. Do not assume.**

---

## Review Checklist

### 1. Power and Ground Shorts

- [ ] No direct shorts between any power rail and ground
- [ ] No direct shorts between different voltage rails (e.g., 3.3V shorted to 5V)
- [ ] No power rail connected to a signal that would short it to ground through an active device
- [ ] Verify no reversed polarity connections on polarized components (electrolytic caps, diodes, ICs)

### 2. Absolute Maximum Violations

- [ ] No component has a voltage across it that exceeds its absolute maximum rating
- [ ] Input voltages to ICs do not exceed VCC + 0.3V (or datasheet-specified max) on any pin
- [ ] No resistors/capacitors/inductors are operated beyond their rated voltage
- [ ] Current through any component does not exceed its rated maximum
- [ ] No reverse voltage applied to non-bidirectional components without protection

### 3. Pin-Level Correctness

- [ ] IC pin numbers match the datasheet for the specific package variant being used
- [ ] No outputs driving directly into other outputs (bus contention) without tri-state control
- [ ] No input pins left floating on CMOS devices (will oscillate and cause excess current draw)
- [ ] Active-low signals are properly driven (not left floating or assumed high)
- [ ] Analog inputs are not connected to digital outputs without appropriate conditioning
- [ ] Multi-function pins are configured for the correct function via strap resistors or configuration

### 4. Passive Component Sanity

- [ ] Resistor values are reasonable for their application:
  - Pull-ups/pull-downs: typically 1k-100k range
  - Current-limiting resistors: verify LED current, base drive current
  - Feedback resistors: verify output voltage calculation
- [ ] Capacitor values are reasonable for their application:
  - Decoupling caps: typically 100nF local, 10uF-47uF bulk
  - Filter caps: verify cutoff frequency
  - No absurdly large or small values that suggest a units error (e.g., 100F instead of 100uF)
- [ ] Diode orientation is correct (anode/cathode) for all diodes in the design
- [ ] Polarized capacitor orientation is correct (positive terminal to higher voltage)

### 5. Power Supply Basic Checks

- [ ] Voltage regulator input voltage is within its specified input range
- [ ] Voltage regulator output is set to the correct voltage (verify feedback divider calculation)
- [ ] Enable pins on regulators are properly driven (not floating)
- [ ] Input capacitors are present on regulator inputs
- [ ] Output capacitors are present on regulator outputs
- [ ] Regulator can supply the total current demanded by its load (basic load budget)
- [ ] Linear regulators have acceptable dropout margin (VIN - VOUT > dropout voltage)
- [ ] No regulator output feeds back into its own input path (circular dependency)

### 6. Connector Wiring

- [ ] Power connector polarity matches the expected source
- [ ] Connector pin assignments match the mating connector or cable specification
- [ ] No signal pins on connectors shorted to power or ground unintentionally

### 7. Basic Circuit Topology

- [ ] Voltage dividers produce the expected output voltage (calculate and verify)
- [ ] RC/LC filter cutoff frequencies are in the expected range
- [ ] Transistor circuits have base/gate resistors where needed
- [ ] Op-amp circuits have feedback (no open-loop configurations unless intentional)
- [ ] Comparator outputs have pull-up resistors (if open-collector/open-drain)
- [ ] Crystal oscillator circuits have load capacitors (if required)

### 8. Obvious Omissions

- [ ] Reset pins are properly managed (not floating)
- [ ] Watchdog timer pins are managed (if present)
- [ ] Chip select / enable pins are properly driven
- [ ] Address pins on I2C/SPI devices are configured (not floating)
- [ ] Boot/configuration pins are strapped to the intended state

---

## Common Sanity Failures

| Issue | Severity | Typical Cause |
|-------|----------|---------------|
| Swapped VCC/GND on IC | Critical | Symbol created with wrong pin assignment |
| Output-to-output short | Critical | Two ICs driving the same net without tri-state |
| Floating CMOS input | Critical | Unconnected input on digital IC |
| Wrong regulator output voltage | Critical | Feedback divider resistor values wrong |
| Reversed diode | Critical | Anode/cathode swapped in symbol or placement |
| Capacitor voltage exceeded | Critical | 6.3V cap on a 12V rail |
| Missing decoupling cap on IC | Major | Omitted during schematic capture |
| Floating enable/reset pin | Major | Pin left unconnected, behavior undefined |

## Severity Classification

- **Critical**: Will cause immediate board failure, component damage, or safety hazard on first power-up.
- **Major**: Will cause functional failure or unreliable operation.
- **Minor**: May cause degraded performance or intermittent issues.
- **Info**: Observation only.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet name/number, reference designator, net name]
- **Description**: [What was found]
- **Recommendation**: [What should be changed]
- **Reference**: [Datasheet page, standard, or best practice source]
```
