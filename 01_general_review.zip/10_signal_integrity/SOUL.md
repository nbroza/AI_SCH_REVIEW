# Signal Integrity Review — Schematic Review Context

## Purpose

This review evaluates the **signal integrity aspects visible at the schematic level** — termination strategies, impedance matching, driver/receiver compatibility, crosstalk risk identification, and signal quality provisions. While many signal integrity concerns are layout-dependent, the schematic must provide the correct foundation: proper termination components, appropriate driver selection, and correct topology.

A layout cannot fix what the schematic gets wrong.

## Prerequisites

- Exported netlist
- Signal speed / data rate information for all high-speed interfaces
- Target impedance specifications (if defined)
- PCB stackup information (if available — affects impedance calculations)
- Datasheets for high-speed ICs, connectors, and transceivers in `../datasheets/`

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`10_signal_integrity/`). These may contain impedance budgets, signal integrity simulation results, interface-specific routing guidelines, or stackup specifications.

Reference datasheets in `../datasheets/` for driver output impedance, receiver input impedance, rise/fall time specifications, and recommended termination schemes.

## When to Ask the User for Clarification

Ask the user when:

- Signal frequencies or data rates are not specified for an interface
- The PCB stackup is unknown (impacts impedance and crosstalk)
- The trace length is unknown (determines whether termination is needed)
- The intended termination strategy is not clear from the schematic
- You need to know whether differential pairs are routed as such in layout
- The design environment (consumer vs. automotive vs. high-reliability) affects margins
- Cable lengths for off-board signals are unknown

**Signal integrity analysis requires knowing the signal speed and trace length. Ask if not provided.**

---

## Review Checklist

### 1. Termination Strategy Assessment

Identify every signal that may require termination. A signal generally requires termination when:
- The trace length exceeds 1/6 of the signal's rise-time-equivalent wavelength
- Rule of thumb: if `trace_length_mm > rise_time_ns × 25`, consider termination

For each signal requiring termination:

- [ ] **Series termination** (source termination):
  - Resistor value = Z0 - R_OUT (characteristic impedance minus driver output impedance)
  - Placed at the driver, near the output pin
  - Suitable for point-to-point connections
  - Not suitable for multi-drop buses
  - Verify the resistor value is present and correct

- [ ] **Parallel termination** (end termination):
  - Resistor value = Z0 (characteristic impedance, typically 50Ω or 100Ω differential)
  - Placed at the receiver end
  - Dissipates DC power — acceptable for the application?
  - Used for clock signals, high-speed buses with multiple receivers
  - Verify resistor to correct voltage (GND, VTT, or Thevenin)

- [ ] **Thevenin termination**:
  - Two resistors to VCC and GND at the receiver
  - Effective impedance = R1 ∥ R2 should equal Z0
  - Bias point = VCC × R2 / (R1 + R2)
  - Higher power consumption than single resistor termination

- [ ] **AC termination** (RC termination):
  - Series RC at the receiver end
  - R = Z0, C chosen to absorb reflections without DC power dissipation
  - Suitable for buses with low duty cycle

- [ ] **Differential termination**:
  - 100Ω between differential pair at the receiver (for 50Ω single-ended, 100Ω differential)
  - May include common-mode termination to ground

### 2. High-Speed Interface Verification

For each high-speed interface, verify the schematic provides the necessary signal integrity components:

#### General High-Speed Signals (>50 MHz or rise time < 2ns)
- [ ] Series termination resistors are present at source (if point-to-point)
- [ ] AC coupling capacitors are present (if required by the interface)
- [ ] DC blocking capacitors value is appropriate (does not attenuate lowest frequency of interest)
- [ ] Common-mode chokes are present where needed (USB, Ethernet, HDMI)

#### Differential Pairs
- [ ] Differential pairs are identified and documented in the schematic
- [ ] AC coupling capacitors (if required) are matched in value between P and N lines
- [ ] Termination is present and correct for the interface standard
- [ ] Common-mode components (chokes, capacitors) are appropriate

#### Clock Signals
- [ ] Clock signals have appropriate termination for the frequency and topology
- [ ] Clock distribution uses appropriate topology (star, daisy-chain with termination, or buffered)
- [ ] Clock buffers have adequate drive strength for the load

### 3. Driver/Receiver Compatibility

- [ ] Driver output impedance is compatible with the transmission line impedance
- [ ] Driver output current capability is sufficient to drive the load:
  - Number of receivers × receiver input capacitance + trace capacitance
  - AC drive current for fast edge rates
- [ ] Driver slew rate is appropriate:
  - Too fast: causes EMI and reflections
  - Too slow: causes timing violations
  - Configurable slew rate should be set correctly
- [ ] Receiver input impedance is appropriate for the source
- [ ] Receiver input capacitance is specified and accounted for
- [ ] Driver push-pull vs. open-drain is correct for the bus topology

### 4. Bus Topology

- [ ] Point-to-point signals: source termination is appropriate
- [ ] Multi-drop buses: parallel termination at the ends, with documented maximum stub lengths
- [ ] Daisy-chain topology: last device in chain has termination
- [ ] Star topology: each branch is impedance-matched or short enough to not need termination
- [ ] Bus loading (total capacitance from all receivers) is within driver capability
- [ ] Bus contention protection (tri-state control, arbitration) is implemented

### 5. Impedance Control Identification

- [ ] Identify all signals that will require impedance-controlled routing based on interface type:
- [ ] Typical signals requiring impedance control:
  - USB 2.0/3.0: 90Ω differential
  - Ethernet: 100Ω differential
  - PCIe: 85Ω differential
  - HDMI/DisplayPort: 100Ω differential
  - DDR: varies by generation (typically 50Ω single-ended, 100Ω differential for clock)
  - LVDS: 100Ω differential
  - RF/antenna: 50Ω single-ended

### 6. Crosstalk Risk Identification

At the schematic level, identify and flag high-crosstalk-risk signal pairs for layout attention:

- [ ] High-speed clocks near sensitive analog inputs
- [ ] Switching power supply signals near sensitive signals
- [ ] Reset lines near noisy digital buses
- [ ] Parallel signals running at different frequencies
- [ ] High-swing signals (12V, RS-232) near low-swing signals (LVCMOS)

### 7. Signal Quality Provisions

- [ ] ESD protection devices on signal lines do not add excessive capacitance at the operating frequency
- [ ] Filter capacitors on signal lines are appropriate for the bandwidth (do not attenuate the signal)
- [ ] Test points on high-speed signals include series resistors or low-capacitance probing provisions
- [ ] Unused inputs on high-speed buffers/transceivers are properly terminated

### 8. Return Path Considerations

- [ ] High-speed ICs have adequate ground pin connections
- [ ] Separate analog and digital ground nets are used where required
- [ ] Connectors have sufficient ground pins for the number of high-speed signals

---

## Common Signal Integrity Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| Missing termination on high-speed clock | Major | Reflections cause double-clocking, EMI |
| Wrong termination value | Major | Impedance mismatch, ringing |
| Missing AC coupling cap | Major | DC offset prevents signal detection |
| Excessive capacitive loading on bus | Major | Slow edges, reduced noise margin |
| No series resistor on source-terminated line | Major | Full-amplitude reflections |
| Differential pair without termination | Major | Signal quality degradation |
| High-speed signal without impedance note | Minor | Layout engineer may route at wrong impedance |
| ESD device capacitance too high for signal speed | Major | Signal attenuation, edge degradation |

## Severity Classification

- **Critical**: Signal integrity issue will prevent the interface from functioning.
- **Major**: Issue will cause degraded performance, elevated BER, or marginal operation.
- **Minor**: Non-optimal but likely functional.
- **Info**: Optimization suggestion.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, signal name, interface type]
- **Signal Speed**: [Frequency or data rate]
- **Description**: [What the signal integrity concern is]
- **Analysis**: [Impedance calculations, timing analysis if applicable]
- **Recommendation**: [Termination type and value, component addition, etc.]
- **Reference**: [Interface specification, datasheet, or SI guideline]
```
