# Signal Integrity Best Practices

## Signal Integrity Fundamentals (2024)

### When Signal Integrity Matters

**Critical Rule:**
If the signal travel time along a trace exceeds **one-quarter of the signal's rise time**, the trace may behave as a transmission line, which can lead to impedance mismatches and signal reflections.

**Formula:**
```
If: tpropagation > trise / 4
Then: Treat as transmission line
```

### Impedance Mismatch and Reflection

**Problem:**
An impedance mismatch occurs when the electrical resistance along a trace varies, causing **signal reflections** that lead to signal distortion.

**Causes:**
- Discontinuities in trace width
- Via stubs
- Connector impedance mismatch
- Termination mismatch at load

## Termination Techniques

### Series Termination

**Description:**
Place a resistor in series with the signal **near the source**.

**Resistor Value:**
```
Rseries = Z0 - Zout
```

Where:
- Z0 = transmission line impedance (typically 50Ω or 90Ω)
- Zout = output impedance of the driver

**Advantages:**
- Simple and cost-effective
- Only one resistor required
- Works well for point-to-point connections

**Best For:**
- Short to medium trace lengths
- Single load at end of trace
- Clock signals

### Parallel Termination

**Description:**
Use a resistor at the **end of the trace** to match impedance.

**Resistor Value:**
```
Rparallel = Z0
```

**Applications:**
- Longer traces
- Differential pairs (use 100Ω for 100Ω differential impedance)
- Multiple loads (bus topology)

**Power Consideration:**
Parallel termination draws continuous current, increasing power consumption.

### AC Termination

**Description:**
Combines resistive and capacitive elements to match impedance over various frequencies.

**Typical Configuration:**
- RC network (series R + shunt C)
- Provides DC isolation while maintaining AC impedance match

**Best For:**
- Clocks with DC component
- Signals requiring DC isolation

## Impedance-Controlled Routing

### Target Impedances

**Single-Ended Signals:**
- Standard: 50Ω (RF, general-purpose)
- High-speed digital: 40-60Ω

**Differential Pairs:**
- USB 2.0: 90Ω differential
- USB 3.x SuperSpeed: 85-90Ω differential
- Ethernet: 100Ω differential
- HDMI: 100Ω differential
- PCIe: 85Ω differential
- DDR memory: 90-100Ω differential (data), 50-60Ω single-ended (clock)

### PCB Stackup for Impedance Control

**Best Practice:**
For high-speed boards, using a **multilayer PCB with buried ground and power supply planes is mandatory**. Solid copper planes allow designers to keep connections short and provide low inductance return paths for high-speed signals.

**4-Layer Stackup:**
```
Layer 1: Signal (Top)
Layer 2: Ground (reference plane)
Layer 3: Power
Layer 4: Signal (Bottom)
```

**6-Layer Stackup (Better):**
```
Layer 1: Signal
Layer 2: Ground
Layer 3: Signal (stripline)
Layer 4: Signal (stripline)
Layer 5: Ground
Layer 6: Signal
```

### Impedance Calculation

Use simulation tools (impedance calculators, field solvers) to determine trace geometry for target impedance:

**Variables:**
- Trace width (W)
- Trace thickness (T)
- Dielectric height (H)
- Dielectric constant (εr)

**Microstrip vs. Stripline:**
- **Microstrip**: Trace on outer layer, one reference plane
- **Stripline**: Trace buried between two reference planes (better shielding)

## Length Matching

### Why Length Matching Matters

For parallel data buses or differential pairs, **timing skew** caused by mismatched trace lengths can cause setup/hold time violations.

### Length Matching Tolerance

**Differential Pairs:**
- **Intra-pair matching**: ±5 mils (0.127 mm) for USB, PCIe
- **±1 mil (0.025 mm)** for ultra-high-speed (10+ Gbps)

**Parallel Buses (DDR Memory):**
- **Data lines (DQ)**: Typically ±25 mils within byte lane
- **Clock to data (DQS)**: ±5 mils
- **Address/Command**: Matched to each other ±50 mils

### Length Matching Techniques

- **Serpentine traces**: Add meanders to lengthen shorter traces
- **Keep meanders away from signal**: Maintain spacing to avoid crosstalk
- **Uniform meander geometry**: Use consistent amplitude and period

## Differential Signaling

### Advantages

- **Common-mode noise rejection**: Noise affects both signals equally, cancelled at receiver
- **Lower EMI**: Opposing currents cancel electromagnetic fields
- **Better signal integrity**: Less susceptible to ground bounce

### Design Guidelines

**Trace Coupling:**
- Keep differential pair traces close together (tight coupling)
- Typical spacing: 1× trace width (edge-to-edge)
- Maintain uniform spacing along entire route

**Routing:**
- Route differential pairs together, same layer
- Avoid splitting pairs across layers (use vias in pairs)
- Match lengths within pair (±5 mils)

**Return Path:**
- Ensure continuous reference plane under differential pair
- Avoid routing over plane splits or gaps

## Discontinuities and Vias

### Via Stub Mitigation

**Problem:**
Via stubs act as resonant stubs, causing reflections at high frequencies.

**Solution:**
- **Back-drilling**: Remove unused via barrel below breakout layer
- **Blind/buried vias**: Eliminate through-hole vias
- **Via-in-pad**: Place via directly in BGA pad (requires plugging/filling)

### Connector Selection

**Impedance-Matched Connectors:**
- Select connectors with specified impedance (50Ω, 100Ω differential)
- Verify connector impedance matches trace impedance
- Minimize stub length from trace to connector pin

## High-Speed Design Best Practices (2024)

### Design Checklist

1. **Stackup Optimization**: Use simulations for microstrip and stripline geometries to achieve target impedance
2. **Routing with Length Matching**: Match lengths for pairs and buses, avoid discontinuities
3. **Termination Network Design**: Implement appropriate termination for impedance matching
4. **Specify Tolerances**: Define impedance tolerances and test via coupons
5. **Reference Plane Management**: Maintain solid reference planes, avoid splits under high-speed signals

### Common Signal Integrity Issues

**Ringing / Overshoot:**
- Cause: Impedance mismatch, insufficient termination
- Solution: Add series damping resistor, improve termination

**Crosstalk:**
- Cause: Traces too close together, return path issues
- Solution: Increase spacing, route on different layers, use ground guard traces

**Ground Bounce:**
- Cause: Insufficient bypass capacitors, poor PDN
- Solution: Add decoupling capacitors close to IC, improve ground plane

**Reflection:**
- Cause: Impedance discontinuity, unterminated transmission line
- Solution: Maintain uniform impedance, add proper termination

## Sources

- [Signal Integrity Basics and Fundamentals in PCB Layout](https://resources.pcb.cadence.com/blog/2024-signal-integrity-basic)
- [High Speed Signal Analysis Design Tips | Cadence](https://resources.pcb.cadence.com/blog/2024-high-speed-signal-analysis-design-tips-cadence)
- [Unlocking Signal Integrity: A Deep Dive into PCB Impedance Control](https://www.aivon.com/blog/pcb-manufacturing/unlocking-signal-integrity-a-deep-dive-into-pcb-impedance-control/)
- [Signal Integrity in PCB: Issues and Proven Design Solutions](https://www.elepcb.com/blog/signal-integrity-in-pcb/)
- [The Ultimate Introduction to High-Speed Signal Integrity for PCB Designers | Altium](https://resources.altium.com/p/introduction-to-high-speed-signal-integrity-for-pcb-designers)
- [Impedance Matching for USB Interfaces in PCBs](https://resources.pcb.cadence.com/blog/2024-impedance-matching-for-usb-interfaces-in-pcbs)
