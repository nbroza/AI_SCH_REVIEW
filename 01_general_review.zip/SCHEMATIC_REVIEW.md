# Schematic Review — Master Orchestration Context

## Overview

This document defines the **complete schematic review process** — the order in which specialized reviews should be executed, how to use the supporting context files, and how to manage findings across all review phases.

Each review phase has a dedicated folder containing a `SOUL.md` file with the detailed review context, checklists, and output format. Additional files in each folder provide supplemental context, best practices, and project-specific notes.

## How to Use This System

### Before Starting Any Review

1. **Collect all datasheets** into the `datasheets/` folder. This is a mandatory upstream step. Every active component (ICs, voltage regulators, transistors, specialized passives) must have its datasheet available. Without datasheets, the Datasheet Mismatch, Power Integrity, Clock, and other reviews cannot be performed properly.

2. **Prepare the primary review inputs**:
   - **Exported netlist** (mandatory — the reviews operate on netlist + BOM, not visual schematics)
   - **BOM with manufacturer part numbers, packages, and quantities** (mandatory)

3. **Gather supplemental project documentation** — if available:
   - Design requirements / specification
   - Block diagram / system architecture
   - Power budget / current estimates
   - Interface specifications
   - Operating environment specification (temperature, compliance targets)

4. **Determine applicable reviews** — not all 19 reviews apply to every design. A simple sensor board with an MCU and no DDR memory does not need the Memory Interface review. Skip reviews that are clearly inapplicable, but err on the side of inclusion.

### For Each Review Phase

1. **Read the `SOUL.md` file** in the review's folder to load the review context
2. **Read all other files** in the same folder — these contain supplemental context, project-specific notes, or additional best practices
3. **Reference datasheets** in `../datasheets/` as directed by the review context
4. **Execute the checklist** systematically — do not skip items
5. **Ask the user for clarification** whenever information is missing or ambiguous — do not guess
6. **Report findings** using the output format specified in the review's SOUL.md
7. **Move to the next phase** once the current review is complete

### If You Are Unsure

**Ask the user.** Every SOUL.md file explicitly authorizes and encourages you to prompt the user for additional information. A review that correctly identifies what it cannot determine (and asks for help) is more valuable than a review that silently guesses and misses a real issue.

---

## Review Execution Order

The reviews are ordered in six phases. Earlier phases establish context and catch showstopper issues before investing time in detailed specialized analysis.

### Phase 1: Foundation & Input Validation

These reviews establish overall understanding and catch fundamental errors.

| Order | Review | Folder | Purpose |
|-------|--------|--------|---------|
| 1 | **General Review** | `01_general_review/` | First pass — understand design intent, verify structure, correlate with block diagram |
| 2 | **Sanity Review** | `02_sanity_review/` | Catch obvious errors that would cause immediate board failure |
| 3 | **Net Connectivity & Completeness** | `03_net_connectivity/` | Verify all nets are intentionally connected, no floating pins or dangling nets |

**Why this order:** The General Review provides the context needed for all subsequent reviews. The Sanity Review catches show-stoppers early. Net Connectivity catches missing connections that would invalidate later detailed analysis.

### Phase 2: Component-Level Verification

These reviews verify individual components are correctly used and sourceable.

| Order | Review | Folder | Purpose |
|-------|--------|--------|---------|
| 4 | **Datasheet Recommendation Mismatch** | `04_datasheet_mismatch/` | Verify every component's circuit matches its datasheet |
| 5 | **Component Lifecycle & Sourcing** | `05_component_lifecycle/` | Verify all parts are available and production-worthy |
| 6 | **Thermal & Derating** | `09_thermal_derating/` | Verify component stress levels have adequate margin |

**Why this order:** Datasheet verification is the most impactful single review — it catches the most real errors. Lifecycle checks ensure the design can actually be built. Thermal/derating ensures long-term reliability.

### Phase 3: Power Architecture

These reviews validate the complete power delivery system.

| Order | Review | Folder | Purpose |
|-------|--------|--------|---------|
| 7 | **Power Integrity** | `06_power_integrity/` | Verify rail generation, regulation, decoupling, load budgets |
| 8 | **Power Sequencing** | `07_power_sequencing/` | Verify rail bring-up/shutdown order and timing |
| 9 | **Voltage Domain & Level Shifting** | `08_voltage_domain/` | Verify signals crossing voltage domains are properly managed |

**Why this order:** Power must be correct before evaluating anything powered by it. Sequencing depends on understanding the power tree. Voltage domains bridge power and signal domains.

### Phase 4: Signal Quality

These reviews validate signal integrity for high-speed and precision circuits.

| Order | Review | Folder | Purpose |
|-------|--------|--------|---------|
| 10 | **Signal Integrity** | `10_signal_integrity/` | Verify termination, impedance matching, driver/receiver compatibility |
| 11 | **Clock & Oscillator** | `11_clock_oscillator/` | Verify crystal circuits, clock distribution, PLL configuration |
| 12 | **Memory Interface** | `12_memory_interface/` | Verify DDR, flash, SRAM interface circuits |
| 13 | **Analog & Mixed-Signal** | `13_analog_mixed_signal/` | Verify ADC/DAC, references, signal conditioning, filtering |

**Why this order:** General signal integrity principles establish the foundation. Clock circuits are a specific high-risk area. Memory interfaces are the most complex signal integrity challenge. Analog is evaluated last because it is often the most application-specific.

### Phase 5: Interface & Protection

These reviews validate external interfaces and protection circuits.

| Order | Review | Folder | Purpose |
|-------|--------|--------|---------|
| 14 | **Connector & Interface Protocol Compliance** | `14_connector_interface/` | Verify USB, Ethernet, CAN, I2C, SPI, etc. meet specifications |
| 15 | **ESD & Transient Protection** | `15_esd_transient/` | Verify external interfaces are protected against ESD and surges |
| 16 | **EMC** | `16_emc/` | Verify emissions and immunity provisions |

**Why this order:** Interface compliance first (is the circuit correct?), then protection (is it robust?), then EMC (will it pass compliance testing?).

### Phase 6: Design Quality

These reviews assess overall design quality, producibility, and testability.

| Order | Review | Folder | Purpose |
|-------|--------|--------|---------|
| 17 | **Complexity** | `17_complexity/` | Identify high-risk areas, assess design complexity |
| 18 | **Design for Manufacturability** | `18_design_manufacturability/` | Verify the design can be produced at the target volume and quality |
| 19 | **Design for Test** | `19_design_test/` | Verify adequate provisions for testing, debug, and diagnostics |

**Why this order:** Complexity assessment informs manufacturing and test risk. DFM before DFT because manufacturing issues are generally harder to fix in the design.

---

## Folder Structure

```
Schematic Audit/
├── SCHEMATIC_REVIEW.md                  ← This file (master orchestration)
├── datasheets/                          ← All component datasheets (upstream collection)
│
├── 01_general_review/
│   ├── SOUL.md                          ← Review context and checklist
│   └── [additional context files]       ← Project-specific notes, supplements
│
├── 02_sanity_review/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 03_net_connectivity/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 04_datasheet_mismatch/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 05_component_lifecycle/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 06_power_integrity/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 07_power_sequencing/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 08_voltage_domain/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 09_thermal_derating/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 10_signal_integrity/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 11_clock_oscillator/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 12_memory_interface/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 13_analog_mixed_signal/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 14_connector_interface/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 15_esd_transient/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 16_emc/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 17_complexity/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 18_design_manufacturability/
│   ├── SOUL.md
│   └── [additional context files]
│
├── 19_design_test/
│   ├── SOUL.md
│   └── [additional context files]
```

---

## Findings Severity Levels (Consistent Across All Reviews)

All reviews use the same severity classification:

| Severity | Definition | Action |
|----------|-----------|--------|
| **Critical** | Will cause board failure, component damage, safety hazard, or complete subsystem non-function. | **Must fix before fabrication.** |
| **Major** | Will likely cause functional issues, compliance failure, or significant reliability risk. | **Should fix before fabrication.** |
| **Minor** | Will not prevent function but represents poor practice, cost inefficiency, or marginal design. | **Should address; acceptable to defer with justification.** |
| **Info** | Observation, optimization suggestion, or best-practice recommendation. | **Consider for implementation.** |

---

## Review Summary Template

After completing all applicable review phases, compile a final summary:

```markdown
# Schematic Review Summary

## Design: [Project Name]
## Revision: [Schematic Revision]
## Date: [Review Date]
## Reviewer: [Name/System]

### Findings Summary

| Severity | Count |
|----------|-------|
| Critical | [N]   |
| Major    | [N]   |
| Minor    | [N]   |
| Info     | [N]   |
| **Total** | **[N]** |

### Findings by Review Phase

| Phase | Review | Critical | Major | Minor | Info |
|-------|--------|----------|-------|-------|------|
| 1 | General Review | - | - | - | - |
| 1 | Sanity Review | - | - | - | - |
| 1 | Net Connectivity | - | - | - | - |
| 2 | Datasheet Mismatch | - | - | - | - |
| 2 | Component Lifecycle | - | - | - | - |
| 2 | Thermal & Derating | - | - | - | - |
| 3 | Power Integrity | - | - | - | - |
| 3 | Power Sequencing | - | - | - | - |
| 3 | Voltage Domain | - | - | - | - |
| 4 | Signal Integrity | - | - | - | - |
| 4 | Clock & Oscillator | - | - | - | - |
| 4 | Memory Interface | - | - | - | - |
| 4 | Analog & Mixed-Signal | - | - | - | - |
| 5 | Connector/Interface | - | - | - | - |
| 5 | ESD & Transient | - | - | - | - |
| 5 | EMC | - | - | - | - |
| 6 | Complexity | - | - | - | - |
| 6 | DFM | - | - | - | - |
| 6 | DFT | - | - | - | - |

### Critical Findings (Must Fix)

[List all critical findings here with cross-references to their detailed reports]

### Overall Assessment

[Pass / Pass with Conditions / Fail]

[Summary narrative of design quality and readiness for fabrication]
```

---

## Notes for the Reviewing LLM

1. **You are a reviewer, not the designer.** Your job is to find issues and ask questions, not to redesign the circuit. When you find an issue, report it and recommend a fix — do not assume you know the full context of every design decision.

2. **Datasheets are your primary reference.** When evaluating a circuit, always check the datasheet for the specific part number and package being used. Do not rely on general knowledge about a component family.

3. **Ask when unsure.** Every review context file explicitly encourages you to ask the user for clarification. A question is always better than a wrong assumption.

4. **Be systematic.** Go through each checklist item. Do not skip items because they "probably" don't apply. Explicitly state when an item is not applicable and why.

5. **Show your work.** When calculations are involved (voltage dividers, power dissipation, load capacitance, filter frequencies), show the calculation. A number without the math behind it is unverifiable.

6. **Context from this folder matters.** Each review folder can contain additional files beyond SOUL.md. These files may contain project-specific constraints, prior review findings, or supplemental best practices. Read all files in a review's folder before starting that review.

7. **Not all reviews apply to all designs.** A simple MCU-based sensor node does not need a Memory Interface review or a complex Analog & Mixed-Signal review. State which reviews you are skipping and why.

8. **Report what you cannot review.** If information is missing and the user cannot provide it, document what you could not review and why. An incomplete review with documented gaps is better than a falsely complete review.
