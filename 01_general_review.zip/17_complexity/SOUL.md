# Complexity Review — Schematic Review Context

## Purpose

This review assesses the **overall design complexity and identifies areas of elevated risk** that warrant additional scrutiny, testing, or design margin. Complex designs are more likely to contain subtle errors, are harder to test, and are more expensive to manufacture and debug. This review identifies complexity hotspots and recommends simplification or risk mitigation.

This is not about finding specific errors — it's about identifying where errors are most likely to hide.

## Prerequisites

- Exported netlist
- BOM with component count and variety
- Design requirements / specification document (if available)

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`17_complexity/`). These may contain design history, known risk areas from prior revisions, technology readiness assessments, or complexity metrics from similar designs.

## When to Ask the User for Clarification

Ask the user when:

- You need to understand if a complex circuit block is reused from a proven design or is new
- The design team's experience with specific technologies (DDR, FPGA, RF, etc.) is unknown
- You cannot determine if a complex implementation is required by constraints or is over-engineered
- Schedule and cost constraints are unknown (affects whether simplification is worthwhile)
- Prototyping vs. production status is unclear (affects acceptable risk level)
- The availability of test equipment and expertise for complex subsystems is unknown

**Complexity is relative to the team's capability. A DDR4 interface is routine for one team and a first-time challenge for another. Ask about experience.**

---

## Review Checklist

### 1. Component Complexity Inventory

- [ ] Total unique part numbers in BOM (indicator of procurement and assembly complexity)
- [ ] Number of active ICs (indicator of design and debug complexity)
- [ ] Number of power rails (indicator of power architecture complexity)
- [ ] Number of high-pin-count devices (BGA, QFN > 100 pins)
- [ ] Number of voltage domains
- [ ] Number of clock frequencies
- [ ] Number of communication interfaces (each is a potential failure point)
- [ ] Total component count (indicator of assembly cost and reliability)

Flag designs that significantly exceed comparable industry benchmarks.

### 2. Technology Risk Assessment

For each technology used in the design, assess the risk level:

| Technology | Low Risk | Medium Risk | High Risk |
|------------|----------|-------------|-----------|
| Digital logic | Standard CMOS logic, simple MCU | FPGA, multi-core processor | Custom ASIC, first-use IP |
| Memory | SPI flash, I2C EEPROM | DDR3 | DDR4/DDR5, LPDDR, HBM |
| Power | Single-output LDO, basic buck | Multi-output PMIC, hot-swap | GaN/SiC power stages, digital power |
| Analog | Basic op-amp, simple ADC | High-resolution ADC (>16-bit), PGA | RF front-end, mixed-signal ASIC |
| Communication | UART, SPI, I2C | USB 2.0, Ethernet 100M, CAN | USB 3.x, PCIe, Gigabit Ethernet, HDMI 2.x |
| Mechanical | Standard through-hole connectors | Fine-pitch SMD, flex circuits | Rigid-flex, RF connectors, micro-BGA |

- [ ] Flag all high-risk technologies and verify adequate design review and test planning
- [ ] Flag first-time-use components or technologies for the design team
- [ ] Assess whether reference designs are being followed (lower risk) or custom circuits are being developed (higher risk)

### 3. Architectural Complexity

- [ ] **Power architecture complexity**:
  - Number of cascaded regulation stages (more stages = more risk)
  - Number of independently sequenced rails
  - Sleep/standby mode complexity
  - Dynamic voltage scaling (if present)
- [ ] **Clock architecture complexity**:
  - Number of independent clock domains
  - Number of clock domain crossings
  - PLL/DLL usage and configuration
  - Jitter budget tightness
- [ ] **Communication architecture**:
  - Number of protocol types used
  - Number of external interfaces
  - Protocol conversion or bridging required
  - Bus arbitration complexity
- [ ] **Signal integrity challenge level**:
  - Number of high-speed differential pairs
  - DDR memory interface complexity (ranks, width, speed)
  - Impedance-controlled routing requirements
  - Length matching requirements

### 4. Design-for-Debug Assessment

- [ ] Test point components exist on critical signals in the netlist
- [ ] Diagnostic LEDs exist on power rails and key status signals
- [ ] JTAG/SWD debug connector is present and connected
- [ ] Subsystem isolation provisions exist (0Ω resistors, jumpers between major blocks)
- [ ] Enable pins on regulators/subsystems are controllable (not hard-wired)
- [ ] Serial console / UART debug output available via a connector

### 5. Configuration & Option Complexity

- [ ] Number of configuration variants (different BOMs for the same PCB)
- [ ] Number of DNP (do not populate) options and their interactions
- [ ] Number of solder-bridge or 0Ω-resistor options
- [ ] Are configuration options documented and their interactions defined?
- [ ] Risk of incorrect population in manufacturing (wrong variant built)
- [ ] Recommendation: reduce options to the minimum necessary, or use separate PCBs for significantly different configurations

### 6. Failure Mode Identification

- [ ] Single points of failure identified:
  - One component whose failure disables the entire system
  - No redundancy in critical paths (if required by the application)
- [ ] Cascade failure scenarios identified:
  - One regulator failure causing overvoltage on a downstream rail
  - One shorted component causing upstream fuse to blow, taking down multiple subsystems
- [ ] Common-cause failure modes:
  - Multiple circuits sharing a component that, if out of tolerance, causes correlated failures
  - Environmental conditions (temperature, humidity) that affect multiple subsystems simultaneously
- [ ] Graceful degradation assessment:
  - Does the system fail safely?
  - Are critical functions maintained when non-critical subsystems fail?

### 7. Manufacturing & Assembly Complexity

- [ ] BGA packages present (requiring X-ray inspection — identifiable from BOM)
- [ ] Fine-pitch components present (< 0.4mm pitch — identifiable from BOM)
- [ ] Mixed-technology assembly (SMD + through-hole — identifiable from BOM)
- [ ] Multi-board assembly with board-to-board connectors

### 8. Simplification Opportunities

- [ ] Can any circuit blocks be replaced with more integrated solutions?
  - Discrete MOSFET driver → integrated load switch
  - Discrete voltage divider + comparator → voltage supervisor IC
  - Multiple single-output regulators → PMIC
  - Discrete USB circuit → integrated USB-C controller
- [ ] Can any unused IC features be used to replace external circuitry?
  - MCU internal voltage reference instead of external
  - MCU internal oscillator instead of external crystal (if accuracy allows)
  - MCU internal pull-ups instead of external resistors
- [ ] Can any interface be simplified?
  - Parallel bus → SPI/I2C (fewer traces, simpler routing)
  - Custom protocol → standard protocol with existing driver support
- [ ] Can the BOM be consolidated?
  - Multiple resistor values that could be unified
  - Multiple capacitor types that could be standardized
  - Multiple connector families that could be rationalized

---

## Complexity Rating System

Rate the overall design and individual subsystems:

| Rating | Description | Action |
|--------|-------------|--------|
| **Low** | Standard design using well-understood technologies | Normal review and testing |
| **Medium** | Some challenging technologies or tight specifications | Enhanced review, targeted simulation |
| **High** | Multiple high-risk technologies, tight margins, or novel circuits | Expert review, simulation, prototype testing plan |
| **Very High** | Bleeding-edge technology, extreme specifications, or safety-critical | Independent design review, extensive simulation, qualification testing |

## Output Format

```
### Finding [number]
- **Area**: [Power, Clock, Signal Integrity, Manufacturing, etc.]
- **Complexity Rating**: [Low | Medium | High | Very High]
- **Description**: [What makes this area complex or risky]
- **Risk**: [What could go wrong]
- **Mitigation**: [Design simplification, additional testing, expert review, etc.]
```

### Summary Table

Provide a summary table at the end:

```
| Subsystem | Complexity | Risk Level | Key Concern | Recommended Action |
|-----------|-----------|------------|-------------|-------------------|
| Power     | High      | Medium     | 7 rails, PMIC | Verify sequencing |
| DDR4      | Very High | High       | First DDR4 design | Expert review |
| USB 2.0   | Low       | Low        | Standard circuit | Normal review |
| ...       | ...       | ...        | ...         | ...               |
```
