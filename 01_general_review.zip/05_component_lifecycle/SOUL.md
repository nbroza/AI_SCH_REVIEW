# Component Lifecycle & Sourcing Review — Schematic Review Context

## Purpose

This review evaluates the **procurement health of the BOM** — checking whether parts are actively manufactured, available from multiple sources, and free of known supply chain risks. Designing in an obsolete or single-source component can be as damaging to a project as a circuit error, because a board that cannot be built is as useless as one that doesn't work.

## Prerequisites

- Complete BOM with specific manufacturer part numbers (MPN)
- Quantity estimates (prototype, production volume, product lifetime)
- Target product lifetime (how many years must this design be producible?)
- Distributor data access (Octopart, Mouser, Digi-Key, or equivalent)
- Datasheets in `../datasheets/`

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`05_component_lifecycle/`). These may contain preferred vendor lists, approved component databases, known problematic parts, second-source qualification data, or procurement constraints specific to the project.

## When to Ask the User for Clarification

Ask the user when:

- You cannot determine a component's lifecycle status from available data
- A part appears obsolete but a direct replacement is not obvious
- You need to know the production volume and lifetime to assess sourcing risk
- The design uses custom or application-specific parts whose sourcing you cannot evaluate
- You need access to distributor APIs or databases to complete the review
- Export control or compliance requirements (ITAR, EAR, RoHS, REACH) are unknown
- The user's organization has a preferred/approved parts list you should check against

**Supply chain assessment requires current market data. If you do not have access to current distributor information, tell the user and ask them to provide it.**

---

## Review Checklist

### 1. Lifecycle Status Assessment

For every unique part number in the BOM:

- [ ] Determine lifecycle status:
  - **Active**: Currently in production, recommended for new designs
  - **NRND (Not Recommended for New Designs)**: Still available but manufacturer has signaled intent to discontinue
  - **Last Time Buy (LTB)**: Final opportunity to purchase before discontinuation
  - **Obsolete/EOL**: No longer manufactured
  - **Pre-production/Sampling**: Not yet in full production — risk of specification changes
- [ ] Flag all NRND, LTB, and Obsolete parts with recommended alternatives
- [ ] For NRND parts: determine estimated remaining availability window
- [ ] For Active parts with long product lifecycles (automotive, industrial): verify manufacturer's longevity commitment

### 2. Single-Source Risk Assessment

- [ ] Identify components available from only one manufacturer (single-source)
- [ ] For single-source parts, assess:
  - Is there a pin-compatible, functionally equivalent alternative from another manufacturer?
  - Is the manufacturer financially stable and reliable?
  - Does the manufacturer have multiple fabrication facilities?
  - Is the part available through multiple authorized distributors?
- [ ] Flag custom, proprietary, or manufacturer-specific parts (e.g., parts only available from one vendor's ecosystem)
- [ ] Assess risk level:
  - **High Risk**: Single-source, no alternatives, critical to design function
  - **Medium Risk**: Single-source but alternatives exist with minor redesign
  - **Low Risk**: Multiple sources or non-critical to function

### 3. Availability & Lead Time

- [ ] Check current distributor stock levels against anticipated build quantities
- [ ] Identify parts with lead times exceeding the project timeline
- [ ] Flag parts with historically volatile availability (check for past allocation events)
- [ ] Identify minimum order quantities (MOQ) that may be problematic for prototype builds
- [ ] Check for parts with unusual packaging requirements (tape-and-reel only, tray only, etc.)
- [ ] Verify parts are available in the needed package variant (same part in SOIC-8 may be available, DFN-8 may not be)

### 4. Second-Source & Cross-Reference

- [ ] For critical components (processors, power ICs, connectors), identify qualified second sources
- [ ] Verify second-source parts are truly pin-compatible and functionally equivalent:
  - Same pinout
  - Same or better electrical specifications
  - Same or compatible package dimensions
  - Same or compatible programming/configuration interface
- [ ] Document second-source part numbers in the BOM or a cross-reference table
- [ ] For connectors: verify mating connector availability from same or compatible manufacturer

### 5. Compliance & Regulatory

- [ ] All parts are RoHS compliant (if required by product regulations)
- [ ] All parts are REACH compliant (if selling in EU)
- [ ] Conflict minerals reporting requirements are met (Dodd-Frank Section 1502)
- [ ] Export control classification (EAR/ECCN) is known for controlled components
- [ ] ITAR restrictions are identified (if applicable)
- [ ] Country-of-origin restrictions are identified (if applicable)
- [ ] UL/safety agency recognized components used where required (fuses, connectors, isolation components)

### 6. Passive Component Sourcing

- [ ] Standard resistor/capacitor values are used where possible (E96 series for 1%, E24 for 5%)
- [ ] Non-standard passive values are flagged (e.g., 4.87kΩ instead of 4.7kΩ or 5.1kΩ)
- [ ] Specialty passive components are identified:
  - Tight-tolerance resistors (0.1% or better)
  - High-voltage capacitors
  - High-current inductors
  - Precision capacitors (C0G/NP0 vs X7R vs X5R)
- [ ] Passive component package sizes are currently available (beware of 0201 and smaller for some values)

### 7. Connector & Mechanical Component Sourcing

- [ ] Connector families are actively produced
- [ ] Mating connectors and cable assemblies are available
- [ ] Connector contact finishes are appropriate and available (gold, tin, etc.)
- [ ] Mechanical components (standoffs, heat sinks, enclosures) are available
- [ ] Custom mechanical parts are identified and sourcing plan is defined

### 8. BOM Hygiene

- [ ] Every line item has a valid, unambiguous manufacturer part number
- [ ] No generic descriptions without MPNs (e.g., "10k resistor" without a specific part number)
- [ ] Part numbers are current (not referencing old/renamed part numbers)
- [ ] Package/footprint in BOM matches what is in the netlist
- [ ] Quantities are correct (accounting for all instances in the schematic)
- [ ] DNP (do not populate) components are clearly marked

---

## Risk Classification

| Risk Level | Criteria | Action Required |
|------------|----------|-----------------|
| **Critical** | Part is obsolete with no drop-in replacement | Immediate redesign required |
| **High** | Single-source, NRND, or chronic supply issues | Identify alternative, begin qualification |
| **Medium** | Single-source but currently available, or long lead time | Document second source, monitor availability |
| **Low** | Multi-source, active lifecycle, readily available | No action, monitor periodically |

## Common Sourcing Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| Obsolete IC with no replacement | Critical | Design cannot be built |
| Single-source connector family | High | Sole supplier disruption stops production |
| NRND regulator | High | Will become unavailable within 1-3 years |
| Non-standard passive value | Medium | Limited sources, longer lead times |
| Missing MPN in BOM | Major | Cannot procure without specific part number |
| Automotive-grade part used in commercial design | Info | Over-specified, may increase cost unnecessarily |

## Output Format

```
### Finding [number]
- **Severity**: [Critical | High | Medium | Low | Info]
- **Component**: [Reference designator(s), MPN, description]
- **Lifecycle Status**: [Active | NRND | LTB | Obsolete | Unknown]
- **Issue**: [What was found]
- **Suggested Alternative**: [Alternative MPN if applicable]
- **Recommendation**: [What should be done]
- **Source**: [Where lifecycle/availability data was obtained]
```
