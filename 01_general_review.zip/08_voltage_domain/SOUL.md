# Voltage Domain & Level Shifting Review — Schematic Review Context

## Purpose

This review verifies that **every signal crossing between different voltage domains is properly managed**. Mixed-voltage designs are ubiquitous — 1.8V cores talking to 3.3V I/O, 3.3V logic talking to 5V sensors, etc. Failure to properly translate voltage levels causes silent data corruption, excessive current draw through ESD clamp diodes, long-term reliability degradation, or immediate latch-up damage.

This is one of the most commonly overlooked failure modes in schematic review.

## Prerequisites

- Exported netlist
- Complete list of all voltage domains in the design (derivable from netlist power rail names)
- IC datasheets (specifically I/O voltage specifications) in `../datasheets/`
- Level translator datasheets in `../datasheets/`

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`08_voltage_domain/`). These may contain voltage domain maps, interface voltage specifications, or known level-shifting constraints for the design.

Reference datasheets in `../datasheets/` — specifically the "Electrical Characteristics" and "Absolute Maximum Ratings" sections for I/O pin voltage specifications.

## When to Ask the User for Clarification

Ask the user when:

- You cannot determine an IC's I/O voltage tolerance from the datasheet (some datasheets are ambiguous about 5V tolerance)
- A signal crosses voltage domains without a level shifter and you cannot determine if the IC is tolerant
- The design uses "5V-tolerant" claims that you cannot verify in the datasheet
- Internal pull-ups exist on an IC that might pull a shared bus to a voltage incompatible with other devices
- You encounter open-drain buses where the pull-up voltage selection is ambiguous
- The logic family or I/O standard for a specific interface is not clear

**Voltage domain violations can cause silent long-term damage. Do not assume compatibility — verify from datasheets.**

---

## Review Checklist

### 1. Voltage Domain Mapping

- [ ] Create or verify a complete list of all voltage domains in the design:
  - Core voltages (1.0V, 1.2V, 1.8V, etc.)
  - I/O voltages (1.8V, 2.5V, 3.3V, 5.0V, etc.)
  - Analog supply voltages
  - Special-purpose voltages (USB VBUS 5V, RS-232 ±12V, CAN 5V, etc.)
- [ ] For every IC, identify which voltage domain its I/O pins operate in
- [ ] Map every signal that crosses between two different voltage domains
- [ ] Identify the voltage levels (VOH, VOL, VIH, VIL) of every signal at every crossing point

### 2. Input Voltage Tolerance Verification

For every signal received by an IC from a different voltage domain:

- [ ] Verify the receiving pin's maximum input voltage (VIN_MAX) from the datasheet
- [ ] Common specifications to check:
  - `VIN ≤ VCC + 0.3V` — most common, means NOT tolerant of higher voltages
  - `VIN ≤ 5.5V` — explicitly 5V tolerant
  - `VIN ≤ VCC` — not tolerant of any voltage above its own supply
  - `VIN ≤ 6.0V` — tolerant regardless of VCC state
- [ ] Verify that the driving output's VOH does not exceed the receiving input's VIN_MAX
- [ ] Check tolerance **during power sequencing** — if the driving domain is powered before the receiving domain, the receiving pin sees voltage with VCC = 0V
- [ ] Verify ESD protection diode configuration:
  - Diode to VCC: current will flow into VCC if input exceeds VCC → problem if VCC is unpowered
  - Diode to GND only: may be more tolerant of overvoltage

### 3. Logic Level Compatibility

- [ ] Verify that the driving output's voltage levels meet the receiving input's threshold requirements:

  | Parameter | Requirement |
  |-----------|-------------|
  | VOH (driver) | Must exceed VIH (receiver) with margin |
  | VOL (driver) | Must be below VIL (receiver) with margin |
  | Noise margin HIGH | VOH - VIH > 0 (preferably > 0.3V) |
  | Noise margin LOW | VIL - VOL > 0 (preferably > 0.3V) |

- [ ] Common incompatibilities to flag:
  - **3.3V driving 5V CMOS input**: 3.3V VOH may not reach 5V VIH (typically 3.5V = 0.7×VCC)
  - **3.3V LVCMOS driving 5V TTL input**: Usually works (TTL VIH = 2.0V) — but verify
  - **1.8V driving 3.3V input**: Almost certainly needs a level shifter
  - **5V driving 3.3V input**: Needs level shifting or series resistor + clamp
- [ ] Check for adequate noise margins in noisy environments or with long signal traces

### 4. Level Shifter / Translator Verification

Where level shifters are used:

- [ ] Level shifter voltage references (VCCA, VCCB) are connected to the correct domains
- [ ] Direction control (if applicable) is correctly configured for each channel
- [ ] Bidirectional level shifters (e.g., BSS138-based, TXB-series) are used where needed (I2C, bidirectional buses)
- [ ] Level shifter speed rating is sufficient for the signal frequency
- [ ] Level shifter propagation delay is acceptable for the interface timing
- [ ] Level shifter output drive strength is sufficient for the load
- [ ] Level shifter is powered from both voltage domains — verify behavior if one domain is unpowered:
  - Does it present high-impedance on the unpowered side? (desirable)
  - Does it back-power through internal circuitry? (undesirable)
- [ ] Level shifter I/O count matches the number of signals requiring translation

### 5. Common Level-Shifting Techniques Verification

#### Resistor Divider (High to Low)
- [ ] Divider ratio produces the correct output voltage
- [ ] Divider impedance is appropriate for the signal speed (high impedance + capacitance = slow edges)
- [ ] Only suitable for unidirectional, low-frequency signals
- [ ] Wastes DC current — acceptable for the application?

#### Series Resistor + Clamp Diode
- [ ] Resistor limits current through the clamp diode
- [ ] Clamp voltage is correct (to receiving VCC)
- [ ] Current through clamp does not exceed diode rating or receiving VCC sourcing capability
- [ ] Signal speed is adequate with the RC time constant introduced

#### MOSFET-Based Bidirectional Shifter (BSS138 style)
- [ ] MOSFET threshold voltage is appropriate (VGS_TH below the lower voltage domain)
- [ ] Pull-up resistors on both sides are correctly valued for the bus speed and capacitance
- [ ] Suitable for open-drain protocols (I2C) — not suitable for push-pull signals
- [ ] Rise time is acceptable at the required data rate

#### Dedicated Level Shifter IC
- [ ] Correct part for the application (unidirectional vs bidirectional)
- [ ] Auto-direction sensing works correctly (if used)
- [ ] OE (output enable) pin is properly managed
- [ ] Partial power-down behavior is acceptable (what happens if VCCA or VCCB is removed?)

### 6. Open-Drain / Open-Collector Bus Voltage

- [ ] Pull-up voltage on open-drain buses is compatible with ALL devices on the bus
- [ ] If bus has devices from different voltage domains:
  - Pull-up to the lower voltage if all devices are tolerant of that voltage (common for I2C)
  - Or use a level-shifting buffer if voltages are incompatible
- [ ] No device on the bus has internal pull-ups enabled that would pull the bus to an incompatible voltage
- [ ] Bus voltage does not exceed any device's VIN_MAX specification

### 7. Mixed Logic Family Considerations

- [ ] CMOS-to-TTL transitions: CMOS output drives TTL input (usually works — verify)
- [ ] TTL-to-CMOS transitions: TTL VOH may not meet CMOS VIH — may need pull-up
- [ ] LVDS, PECL, CML, SSTL interfaces use appropriate receivers for the logic standard
- [ ] Differential interfaces have correct common-mode voltage range at the receiver
- [ ] Impedance matching is correct for the logic standard used

### 8. Analog Signal Domain Crossing

- [ ] Analog signals crossing voltage domains have appropriate signal conditioning
- [ ] Op-amp supply rails are compatible with the signal voltage range (input and output)
- [ ] Analog multiplexer/switch on-resistance variation with signal voltage is acceptable
- [ ] Instrumentation amplifier common-mode range is compatible with the signal source
- [ ] ADC input range matches the signal conditioning output range

---

## Common Voltage Domain Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| 5V signal into 3.3V-only input | Critical | Exceeds absolute maximum, causes current injection or damage |
| 3.3V output driving 5V CMOS input | Major | Signal may not reach VIH threshold — unreliable |
| I2C bus with mixed-voltage devices and pull-up to wrong voltage | Major | One device sees overvoltage |
| Level shifter VCCA/VCCB swapped | Critical | Shifts in wrong direction or damages devices |
| Back-powering through ESD diode during sequencing | Major | Unpowered IC draws current through signal pins |
| Missing level shifter on SPI between domains | Critical | Clock/data levels incompatible |
| Internal pull-up on IC overriding external bus voltage | Major | Unintended voltage on shared bus |

## Severity Classification

- **Critical**: Voltage domain violation will cause component damage or latch-up.
- **Major**: Violation causes unreliable logic levels or excessive current draw.
- **Minor**: Non-optimal voltage management but within IC tolerance.
- **Info**: Improvement suggestion for voltage domain handling.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, signal name, driving IC/pin → receiving IC/pin]
- **Driving Domain**: [Voltage and logic standard]
- **Receiving Domain**: [Voltage and logic standard]
- **Description**: [What the voltage mismatch is]
- **Analysis**: [VOH/VOL/VIH/VIL values from datasheets]
- **Recommendation**: [Level shifter, resistor divider, etc.]
- **Reference**: [Datasheet pages for both driver and receiver]
```
