# Voltage Domain & Level Shifting Best Practices

## High Voltage PCB Design Standards

### IPC Standards for Voltage Spacing

**IPC-2221 Revision C** (released December 14, 2023) is the most referenced standard for PCB spacing in high-voltage applications. The IPC-2220 series establishes generic requirements for printed circuit board design.

## Critical Spacing Parameters

### Clearance

**Definition**: The shortest distance **through air** between two conductive parts.

**Importance**: Insufficient clearance can lead to arcing or flashover, especially as voltage increases or environmental conditions decrease the breakdown voltage of air.

**Design Rule**: Clearance must be calculated based on:
- Operating voltage
- Altitude (reduced air density at altitude)
- Pollution degree (industrial environments require more clearance)
- Material group (PCB material properties)

### Creepage

**Definition**: The shortest path **along the surface** of the PCB material between two conductive elements.

**Importance**: Prevents tracking where contaminants like dust or moisture create a conductive path along the surface.

**Design Rule**: Creepage distance is typically **greater than or equal to clearance** and depends on:
- Operating voltage
- Pollution degree
- Material CTI (Comparative Tracking Index)

## Voltage Domain Separation

### Multi-Domain Layout Strategy

**High-Voltage Isolation:**
- Place high-voltage components away from low-voltage areas to minimize interference and arcing risks
- Group similar voltage domains together
- Use ground planes as shields between high and low-voltage sections

**Domain Boundaries:**
- Clearly define voltage domain boundaries
- Use physical barriers (slots in PCB, isolation barriers) for high-voltage domains
- Provide adequate spacing at domain crossings

## Material Selection for High Voltage

### Dielectric Strength

Materials used in high voltage PCBs must offer:
- **High dielectric strength**: Resistance to breakdown under high electric field
- **High resistivity**: Low leakage current
- **Low power factor**: Minimize heating and thermal breakdown

### Comparative Tracking Index (CTI)

**Definition**: The CTI indicates the voltage at which a material begins to break down in a standardized test.

**CTI Classes:**
- **CTI ≥ 600V**: Material Group I (Best)
- **400V ≤ CTI < 600V**: Material Group II
- **175V ≤ CTI < 400V**: Material Group IIIa
- **100V ≤ CTI < 175V**: Material Group IIIb (Worst)

**Best Practice**: For high-voltage designs, use materials with CTI ≥ 400V (Material Group I or II).

## Level Shifting Between Voltage Domains

### When Level Shifting is Required

Level shifting is necessary when:
- A signal crosses from one voltage domain to another
- The output voltage swing of a driver doesn't match the input voltage range of a receiver
- Bidirectional communication occurs between domains with different logic levels

### Level Shifting Methods

#### 1. Resistor Divider (High to Low Only)
**Use Case**: Simple unidirectional high-to-low level shift
**Limitations**:
- Unidirectional only
- Slow rise time (RC time constant)
- Not suitable for high-speed signals

#### 2. MOSFET-Based Level Shifter
**Use Case**: Bidirectional, moderate speed (I2C, 1-Wire)
**Advantages**:
- Simple, low cost
- Bidirectional
- Open-drain compatible

#### 3. Dedicated Level Shifter IC
**Use Case**: High-speed signals, multiple channels
**Examples**:
- TI TXB0108 (8-channel bidirectional)
- TI SN74LVC8T245 (8-channel direction-controlled)
- NXP GTL2002 (I2C/SMBus level shifter)

**Advantages**:
- Fast switching
- Multiple channels
- Predictable performance

#### 4. Isolated Level Shifters
**Use Case**: Galvanic isolation required
**Examples**:
- Digital isolators (Si86xx, ADuM series)
- Optocouplers (traditional approach)

**Advantages**:
- Complete electrical isolation
- High common-mode noise rejection
- Safety compliance (UL, CE)

## Environmental Considerations

### Altitude

Air breakdown voltage decreases with altitude. Increase clearance when operating above sea level.

### Pollution Degree

**Pollution Degree 1**: No pollution or only dry, non-conductive pollution (sealed enclosures)
**Pollution Degree 2**: Normal indoor environment, non-conductive pollution with occasional condensation
**Pollution Degree 3**: Industrial environment, conductive pollution or frequent condensation

Higher pollution degrees require increased creepage distances.

### Temperature and Humidity

High humidity can reduce effective creepage distance by creating conductive paths on PCB surface. Consider:
- Conformal coating for high-humidity environments
- Increased creepage margins
- Sealed enclosures

## Common Voltage Domain Issues

### Issue 1: Insufficient Clearance
**Symptom**: Arcing or flashover between high-voltage traces
**Solution**: Increase clearance per IPC-2221, use slots/cutouts for extreme voltages

### Issue 2: Creepage Path Too Short
**Symptom**: Tracking or surface breakdown over time
**Solution**: Reroute traces to increase surface path length, add conformal coating

### Issue 3: Level Shifter Speed Mismatch
**Symptom**: Signal integrity issues, slow rise times
**Solution**: Use faster level shifter IC, check propagation delay specifications

### Issue 4: Level Shifter Direction Control Error
**Symptom**: Bus contention, communication errors
**Solution**: Verify direction control logic, use auto-direction level shifters for bidirectional buses

## Sources

- [High Voltage PCB Design Guidelines | Cadence](https://resources.pcb.cadence.com/blog/2024-high-voltage-pcb-design-guidelines-and-materials)
- [High‑Voltage PCB Design Guidelines | PICA Manufacturing](https://picamfg.com/designing-high-voltage-pcbs/)
- [High Voltage PCB Design: Mastering Pad to Pad Spacing for Safety and Reliability](https://www.allpcb.com/allelectrohub/high-voltage-pcb-design-mastering-pad-to-pad-spacing-for-safety-and-reliability)
- [PCB high voltage spacing: What every engineer should know - Electronic Systems Design](https://blogs.sw.siemens.com/electronic-systems-design/2025/04/29/pcb-high-voltage-spacing-what-every-engineer-should-know/)
- [High Voltage PCB Design: The Ultimate Guide](https://www.venture-mfg.com/high-voltage-pcb-design-guide/)
