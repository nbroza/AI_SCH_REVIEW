# Analog & Mixed-Signal Review — Schematic Review Context

## Purpose

This review evaluates **analog and mixed-signal circuit implementations** — ADC/DAC front-ends, voltage references, sensor signal conditioning, analog filtering, and the critical boundary between analog and digital domains. Analog circuits demand precision in component selection, biasing, filtering, and grounding that digital circuits do not, and errors here cause subtle performance degradation that is difficult to diagnose on a fabricated board.

## Prerequisites

- Exported netlist
- Signal specifications (amplitude range, bandwidth, accuracy requirements)
- ADC/DAC datasheets in `../datasheets/`
- Op-amp, instrumentation amp, comparator datasheets in `../datasheets/`
- Sensor datasheets and specifications in `../datasheets/`
- Voltage reference datasheets in `../datasheets/`
- System accuracy/resolution requirements

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`13_analog_mixed_signal/`). These may contain signal chain analysis documents, noise budgets, filter design calculations, calibration procedures, or analog-specific design guidelines.

Reference datasheets in `../datasheets/` for analog component specifications including noise density, offset voltage, CMRR, PSRR, bandwidth, and input bias current.

## When to Ask the User for Clarification

Ask the user when:

- Signal accuracy or resolution requirements are not documented
- The sensor type or signal characteristics are unknown
- Calibration strategy (factory, field, none) is not specified
- Environmental noise characteristics of the deployment environment are unknown
- Grounding strategy (analog/digital separation) is not documented
- You cannot determine whether a specific filter topology is intentional or an error
- The system-level noise budget is not available

**Analog design choices are highly application-specific. Ask about the accuracy requirements and signal characteristics before evaluating design adequacy.**

---

## Review Checklist

### 1. ADC Front-End

#### Input Signal Conditioning
- [ ] Input voltage range matches the ADC's specified input range:
  - Unipolar: 0V to VREF
  - Bipolar: -VREF to +VREF (or other specified range)
  - Differential: verify common-mode range
- [ ] Anti-aliasing filter is present before the ADC input:
  - Filter cutoff frequency ≤ Nyquist frequency (fs/2)
  - Recommended: filter cutoff at the signal bandwidth, with sufficient attenuation at fs/2
  - Filter order provides adequate attenuation of aliased frequencies
- [ ] Input impedance of the signal chain is appropriate:
  - ADC sample-and-hold input capacitance is driven by adequately low source impedance
  - SAR ADCs: source impedance typically < 1kΩ (check ADC datasheet for maximum)
  - Sigma-delta ADCs: typically less restrictive on source impedance
- [ ] Input protection:
  - Overvoltage protection (diodes, clamps) that does not degrade signal quality
  - ESD protection that does not add excessive capacitance or leakage
- [ ] Charge kickback from SAR ADC is managed:
  - RC filter or buffer amplifier before ADC input
  - Buffer amplifier can handle the capacitive load

#### ADC Configuration
- [ ] ADC reference voltage is correct and matches the expected input range
- [ ] ADC resolution is adequate for the required measurement accuracy
- [ ] ADC sampling rate meets the Nyquist criterion for the signal bandwidth
- [ ] ADC digital interface (SPI/I2C/parallel) is correctly connected
- [ ] ADC clock source is clean (low jitter) and at the correct frequency
- [ ] AVDD and DVDD supplies are properly filtered and separated

### 2. DAC Output

- [ ] DAC output voltage range matches the required signal range
- [ ] Output buffer amplifier is present if the load exceeds the DAC's drive capability
- [ ] Output filter (reconstruction filter) is present to remove DAC quantization artifacts:
  - Low-pass filter with cutoff at the signal bandwidth
  - Attenuation of images at multiples of the update rate
- [ ] DAC reference voltage is correct
- [ ] DAC settling time is adequate for the update rate
- [ ] Glitch energy is acceptable for the application (if using a current-steering DAC)

### 3. Voltage Reference

- [ ] Reference voltage accuracy meets the system requirement:
  - Consider initial accuracy, temperature coefficient, and long-term drift
  - Total error budget: initial tolerance + TC × ΔT + aging
- [ ] Reference temperature coefficient (TC) is adequate for the operating temperature range:
  - High precision: < 5 ppm/°C
  - Moderate: 5-25 ppm/°C
  - Low precision: > 25 ppm/°C
- [ ] Reference noise specification is within the system noise budget:
  - Broadband noise: µVRMS over the bandwidth
  - 1/f noise: important for DC and low-frequency measurements
- [ ] Reference load regulation: output voltage change vs. load current is acceptable
- [ ] Reference output capacitor:
  - Required for stability (check datasheet — some references are unstable with capacitive loads)
  - Value and type per datasheet recommendation
- [ ] Reference bypass/filter capacitor is present for noise reduction
- [ ] Reference startup time is acceptable (some precision references take 50-100ms)
- [ ] Reference operates within its specified input voltage range

### 4. Operational Amplifier Circuits

For each op-amp circuit:

#### DC Specifications
- [ ] Input offset voltage (VOS) is acceptable for the application accuracy
- [ ] Input bias current (IB) does not cause significant voltage errors through source impedance
  - Error voltage = IB × RSOURCE
  - For bipolar op-amps: use bias current compensation resistor if needed
  - For CMOS op-amps: IB is typically negligible (but increases with temperature)
- [ ] Input offset current (IOS) error is acceptable
- [ ] Open-loop gain is sufficient for the required closed-loop accuracy
  - Gain error ≈ 1/AOL at closed-loop gain
- [ ] Common-Mode Rejection Ratio (CMRR) is adequate
- [ ] Power Supply Rejection Ratio (PSRR) is adequate for the supply noise level

#### AC Specifications
- [ ] Gain-bandwidth product (GBW) is sufficient:
  - GBW > closed-loop gain × signal bandwidth (with margin)
- [ ] Slew rate is adequate for the signal:
  - Slew rate > 2π × f × V_peak (for undistorted sine wave)
- [ ] Phase margin is adequate for stability (not oscillating):
  - Capacitive loads can degrade phase margin
  - Use isolation resistor before capacitive loads
- [ ] Output can drive the load impedance
- [ ] Output voltage swing reaches required range (rail-to-rail if needed)

#### Circuit Configuration
- [ ] Feedback resistor values are correct for the desired gain:
  - Inverting: Gain = -RF/RIN
  - Non-inverting: Gain = 1 + RF/RIN
  - Difference: verify all four resistor values
- [ ] Resistor matching is adequate for instrumentation and difference amplifiers
- [ ] Compensation capacitor across feedback resistor (if used) provides the correct bandwidth limit
- [ ] Input common-mode range is not exceeded
- [ ] Output loading is within the op-amp's capability

### 5. Sensor Signal Conditioning

- [ ] Sensor excitation (voltage or current) matches the sensor's specification
- [ ] Signal amplification gain is correct:
  - Gain = ADC full-scale / sensor full-scale output
  - Verify the gain produces the correct signal level at the ADC input
- [ ] Bridge circuits (if used) are balanced and correctly configured:
  - Wheatstone bridge excitation voltage is correct
  - Bridge output is properly amplified (instrumentation amplifier recommended)
  - Bridge sense wires are present for remote voltage sensing (if needed)
- [ ] Thermocouple circuits:
  - Cold junction compensation is present
  - Thermocouple type matches the amplifier/ADC configuration
  - Open-circuit detection is implemented
- [ ] RTD circuits:
  - Excitation current is within specification (too high causes self-heating)
  - 2-wire, 3-wire, or 4-wire configuration is appropriate for accuracy
  - Lead resistance compensation (3-wire or 4-wire) is present if needed
- [ ] Current loop (4-20mA) receivers:
  - Burden resistor value produces the correct voltage range
  - Burden resistor power rating is adequate
  - Open-loop and over-range detection is present

### 6. Analog Filtering

For each analog filter in the design:

- [ ] Filter topology is appropriate (Butterworth, Bessel, Chebyshev, etc.)
- [ ] Cutoff frequency is correct — calculate from component values:
  - RC: fc = 1 / (2π × R × C)
  - LC: fc = 1 / (2π × √(L × C))
  - Active filter: verify against design equations for the topology
- [ ] Filter order provides adequate attenuation at the frequency of interest
- [ ] Component values are standard values (not unusual precision requiring custom parts)
- [ ] Component tolerances are adequate for the required cutoff accuracy
- [ ] Op-amp bandwidth is sufficient for the filter (GBW >> filter cutoff for active filters)
- [ ] Filter impedance is compatible with source and load
- [ ] DC bias path exists for AC-coupled filter stages

### 7. Analog/Digital Ground Separation

- [ ] Ground separation strategy is defined and consistent:
  - Split ground plane with single-point connection
  - Unified ground plane with layout discipline (acceptable for many designs)
  - Star ground from a single point
- [ ] AGND and DGND connections on mixed-signal ICs follow the datasheet recommendation
  - Most modern ADC/DAC datasheets recommend connecting AGND and DGND together at the device
  - Do NOT split ground under a mixed-signal IC
- [ ] Analog signals on connectors use analog ground (AGND) return pins, not digital ground

### 8. Analog Power Supply Quality

- [ ] Analog supplies have additional filtering beyond digital supply decoupling:
  - LC filters or ferrite bead + capacitor to isolate from digital noise
  - LDO post-regulation from switching supply for sensitive analog circuits
- [ ] Power supply noise at the analog IC supply pin is within the PSRR budget:
  - At DC: PSRR is typically very high
  - At switching frequency: PSRR degrades — verify supply noise × (1/PSRR) is acceptable
- [ ] Voltage reference is powered from a clean supply (not directly from a switching regulator)
- [ ] Analog supply sequencing does not cause issues (analog power before digital, or simultaneous)

---

## Common Analog & Mixed-Signal Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| Missing anti-aliasing filter | Critical | Aliased signals corrupt ADC readings |
| ADC input exceeds reference voltage | Major | Clipping, potential damage |
| Wrong op-amp gain resistors | Critical | Signal level incorrect, may saturate or underutilize range |
| Op-amp driving capacitive load without isolation | Major | Oscillation, ringing |
| Reference bypassed with wrong cap type | Major | Reference instability |
| Ground split under mixed-signal IC | Major | Return current disruption, increased noise |
| Excessive source impedance for SAR ADC | Major | Acquisition time insufficient, measurement errors |
| Missing cold junction compensation | Critical | Thermocouple readings wrong by 10s of degrees |

## Severity Classification

- **Critical**: Analog error will cause incorrect measurements, damage, or complete signal chain failure.
- **Major**: Error will degrade accuracy, increase noise, or cause intermittent issues.
- **Minor**: Non-optimal but functional with reduced performance.
- **Info**: Optimization for improved analog performance.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, component designator, signal name]
- **Description**: [What was found]
- **Calculation**: [Gain, cutoff frequency, noise, error budget as applicable]
- **Recommendation**: [Component change, circuit modification, etc.]
- **Reference**: [Datasheet page, application note, filter design reference]
```
