# Analog & Mixed-Signal PCB Design Best Practices

## Grounding Approaches for Mixed-Signal Designs

### Single Ground Plane (Recommended for Most Designs)

**Best Practice:**
For mixed-signal systems with a single ADC or DAC with **low digital current**, a **solid single ground plane** is the best approach.

**Rationale:**
Mixed-signal ICs with low digital currents, such as many ADCs and DACs, are generally best treated as analog devices and grounded and decoupled to the analog ground plane.

**When to Use:**
- Single ADC/DAC designs
- Low digital current (< 100mA)
- Moderate precision requirements (12-16 bit ADC/DAC)

### Split Ground Plane Approach

**When to Use:**
- High digital currents (> 100mA)
- Very sensitive analog circuits (> 16 bit ADC, precision references)
- Significant digital noise sources on same board

**Critical Implementation Rule:**
If you split analog and digital ground planes, you **MUST MUST MUST connect the analog and digital grounds together at the ADC/DAC**, not elsewhere on the PCB.

**Implementation:**
- Create separate AGND and DGND planes
- Connect AGND and DGND at **one single point** under the ADC/DAC
- This creates a "star ground" at the mixed-signal device
- Current from digital circuits returns to digital ground plane
- Current from analog circuits returns to analog ground plane

**Important Caveat:**
The best approach in **most mixed-signal systems** and with **most ADCs** is to use a **uniform ground plane, not physically separated grounds**.

### What to Avoid

**Never Overlap Ground Planes:**
Do not overlap analog and digital ground planes. This will cause **capacitive coupling of noise** from one (probably digital ground) into the other.

**Avoid Multiple Ground Connections:**
Do not connect AGND and DGND at multiple points. This creates ground loops and defeats the purpose of separation.

## PCB Layer Stack-Up for Mixed-Signal

### 4-Layer PCB (Minimum Recommended)

**Stack-Up:**
```
Layer 1: Mixed Signal (Top)
Layer 2: Ground Plane (GND)
Layer 3: Power Plane (VCC / Split if AVCC and DVCC)
Layer 4: Mixed Signal (Bottom)
```

**Benefits:**
- At least one layer dedicated to ground plane ensures low impedance path for return signals
- All integrated circuit ground pins should be routed and connected correctly to the low impedance ground plane to minimize series inductance and resistance

### 6-Layer PCB (Better Performance)

**Stack-Up:**
```
Layer 1: Analog Signal
Layer 2: Ground Plane
Layer 3: Analog Power (AVCC)
Layer 4: Digital Power (DVCC)
Layer 5: Ground Plane
Layer 6: Digital Signal
```

**Benefits:**
- Complete separation of analog and digital routing layers
- Two ground planes for better noise isolation
- Stripline routing for critical signals

## Crosstalk Mitigation

### Spacing

To mitigate crosstalk, PCB designers should maintain **adequate spacing between high-speed digital and analog traces**.

**Guidelines:**
- Minimum 3× trace width spacing between analog and digital signals
- Increase spacing for higher-frequency digital signals
- Use 3W rule: spacing ≥ 3× trace width reduces crosstalk to < 10%

### Ground Plane Shielding

**Use ground planes for shielding** between analog and digital sections.

**Implementation:**
- Route sensitive analog signals on inner layers (stripline)
- Use ground plane above and below as shield
- Stitch ground planes with vias to create Faraday cage effect

### Differential Signaling

**Implement differential signaling where possible** for analog signals.

**Benefits:**
- Common-mode noise rejection
- Better immunity to crosstalk
- Lower EMI emissions

**Applications:**
- ADC/DAC differential inputs/outputs
- Analog sensor interfaces
- Audio signals

## ADC Grounding Best Practices

### Low-Current ADC (< 100mA Digital Current)

**Grounding Approach:**
Use single, solid ground plane. Connect ADC AGND and DGND pins to the same ground plane.

**Power Supply:**
- Use single supply with good decoupling, or
- Use separate analog and digital supplies with common ground

### High-Performance ADC (> 16 bit or High Digital Current)

**Grounding Approach:**
Split ground plane, connect AGND and DGND at ADC only.

**Power Supply:**
- Separate analog and digital power supplies
- Separate AVCC and DVCC planes
- Connect planes only at power entry point or at ADC

### Decoupling Strategy

**Analog Supply (AVCC):**
- 10µF bulk capacitor (tantalum or ceramic)
- 0.1µF ceramic close to IC
- 0.01µF or smaller for high-frequency noise

**Digital Supply (DVCC):**
- 10µF bulk capacitor
- 0.1µF ceramic at each power pin
- Additional 0.01µF for high-speed ADCs

**Reference Voltage (VREF):**
- 10µF low-ESR tantalum or ceramic
- 0.1µF ceramic close to VREF pin
- May require additional filtering (RC or LC filter)

## Analog Reference Voltage Design

### External Reference

**When to Use:**
- Precision applications (< 0.1% accuracy)
- Long-term stability requirements
- Temperature-compensated references needed

**Design Guidelines:**
- Place reference IC close to ADC VREF pin
- Use dedicated analog power supply for reference
- Filter reference output (10µF + 0.1µF)
- Use low-noise LDO for reference power supply

### Reference Buffering

**When Needed:**
- ADC input impedance to VREF is low (< 10kΩ)
- Multiple ADCs share same reference
- Reference IC cannot source required current

**Buffer Selection:**
- Low noise (< 10µV RMS)
- Rail-to-rail output
- Unity-gain stable
- Low offset (< 1mV)

**Example Buffers:**
- OPA189 (precision, low noise)
- LTC6078 (low noise, low drift)
- ADA4528 (auto-zero, ultra-low offset)

## Input Signal Conditioning

### Anti-Alias Filtering

**Purpose:**
Prevent aliasing of high-frequency noise into ADC measurement band.

**Filter Design:**
- Set cutoff frequency fc < fs/2 (Nyquist frequency)
- Typical filter: 2nd or 3rd order Sallen-Key or multiple-feedback
- Use low-noise op-amps (< 10nV/√Hz)

### Input Protection

**ESD Protection:**
- TVS diodes on external analog inputs
- Low capacitance (< 10pF) to avoid signal degradation
- Clamping voltage < ADC absolute maximum

**Overvoltage Protection:**
- Series resistor to limit current
- Clamp diodes to supply rails
- Verify ADC input can tolerate clamping current

### Buffering

**When Needed:**
- Source impedance > 1kΩ
- ADC has multiplexed inputs (charge injection)
- Long cable runs

**Buffer Requirements:**
- Low noise
- Low offset
- Sufficient bandwidth for signal
- Drive capability for ADC input capacitance

## Common Mixed-Signal Design Issues

### Ground Loops

**Symptom:** 60Hz/50Hz hum, noise correlated with digital activity
**Cause:** Multiple ground connections creating loop
**Solution:** Single-point grounding, star ground topology

### Digital Noise Coupling

**Symptom:** Digital clock frequency or harmonics visible in analog signal
**Cause:** Inadequate separation, shared ground return paths
**Solution:** Separate routing, guard traces, shielding

### Reference Noise

**Symptom:** ADC readings fluctuate, noise floor higher than expected
**Cause:** Noisy reference voltage, inadequate filtering
**Solution:** Use precision reference, add filtering, isolate reference from digital noise

### Power Supply Rejection

**Symptom:** ADC readings vary with digital activity
**Cause:** Digital current spikes coupling through power supply
**Solution:** Separate power supplies, improve PDN, add filtering

## Sources

- [What Are the Basic Guidelines for Layout Design of Mixed-Signal PCBs? | Analog Devices](https://www.analog.com/en/resources/analog-dialogue/articles/what-are-the-basic-guidelines-for-layout-design-of-mixed-signal-pcbs.html)
- [Staying Well Grounded | Analog Devices](https://www.analog.com/en/resources/analog-dialogue/articles/staying-well-grounded.html)
- [How to Properly Ground ADCs | PCB Layout](https://resources.altium.com/p/how-properly-ground-adcs)
- [Understanding AGND and DGND Grounding Practices](https://www.allpcb.com/allelectrohub/understanding-agnd-and-dgnd-grounding-practices)
- [How to Design a Mixed-Signal PCB | Sierra Circuits](https://www.protoexpress.com/blog/how-to-design-mixed-signal-pcb-with-signal-integrity/)
- [PCB Design for High-Speed ADC: Comprehensive Guide - Arshon Inc. Blog](https://arshon.com/blog/pcb-design-for-high-speed-adc-comprehensive-guide/)
