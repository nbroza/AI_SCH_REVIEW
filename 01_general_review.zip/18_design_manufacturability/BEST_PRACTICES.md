# Design for Manufacturability (DFM) Best Practices

## PCB Design for Manufacturing (DFM) Fundamentals (2024)

### What is DFM?

Design for manufacturing (DFM) is the process for design engineers to review the design of a product to **optimize its dimensions, materials, tolerances, and functionality through the most efficient manufacturing means possible**.

DFM is the critical process of **optimizing your PCB design so it can be produced efficiently and reliably** without delays or defects, **bridging the gap between engineering intent and manufacturing reality**.

### Key Benefits

Implementing DFM principles from the get-go in your PCB design process can:
- **Streamline production**
- **Mitigate errors**
- **Save substantial time and money**
- Reduce the number of modifications necessary to adapt the original design
- Reduce delays
- Allow PCB designers to design boards which can be easily produced even with large production volumes

### Best Practice: Early Integration

**Critical Recommendation:**
Incorporating a **DFM analysis into your design process, instead of waiting until the design is complete**, is today's industry best practice.

**Early DFM Benefits:**
- Identify manufacturability issues during design phase
- Avoid costly redesigns after layout complete
- Reduce time-to-market
- Improve first-pass yield

## DFM Process Areas

### 1. PCB Layout Design Analysis

**Component Placement:**
- Thermal management considerations
- Accessibility for assembly and test
- Proper clearances between components

**Trace Width, Clearance, and Spacing:**
- Meet manufacturer capabilities
- Account for fabrication tolerances
- Avoid unnecessarily tight rules

**Thermal Management:**
- Adequate copper area for heat dissipation
- Thermal vias for heat transfer
- Component spacing for airflow

**Layer Stack-Up:**
- Appropriate layer count for complexity
- Balanced copper distribution
- Impedance control requirements

### 2. Materials Selection

**PCB Substrate:**
- FR-4 for standard applications
- High-Tg FR-4 for elevated temperature
- Polyimide for flex circuits
- Rogers or other high-frequency materials for RF

**Copper Weight:**
- 1 oz (35µm) for standard applications
- 2 oz (70µm) for higher current
- Consider cost vs. requirement tradeoff

**Surface Finish:**
- HASL (cost-effective, adequate for most applications)
- ENIG (flat surface for fine-pitch components, gold for wire bonding)
- Immersion silver or tin (flat, economical)
- Choose based on assembly process and shelf life requirements

### 3. Manufacturing Process Selection

**Assembly Process Alignment:**
- Full SMT (fastest, lowest cost for volume)
- Mixed SMT + through-hole (moderate cost)
- Hand assembly (prototypes, low volume)

**Soldering Process:**
- Reflow soldering for SMT
- Wave soldering for through-hole
- Selective soldering for mixed technology

**Component Package Selection:**
- Standard packages reduce assembly cost
- Avoid obsolete or uncommon packages
- Consider assembly house capabilities (minimum pitch, BGA capability)

### 4. Testing and Regulatory Compliance

**Test Strategy:**
- In-circuit test (ICT) requires test point access
- Functional test requires test connectors
- Boundary scan (JTAG) for BGA and dense assemblies

**Regulatory Requirements:**
- RoHS compliance (lead-free)
- REACH compliance (substance restrictions)
- UL/CE marking requirements
- Industry-specific standards (automotive, medical, aerospace)

## Advanced DFM Techniques (2024)

### HDI (High-Density Interconnect) Design

For complex PCBs, advanced DFM techniques include using **HDI designs with microvias, blind vias, and buried vias** to maximize space and routing efficiency.

**HDI Benefits:**
- Smaller board size
- Better signal integrity
- Higher component density

**DFM Considerations:**
- Increased fabrication cost
- Requires capable manufacturer
- More complex design rules

### High-Speed Signal Design

For high-speed signals, design for **controlled impedance** and use **differential pairs** to maintain signal integrity.

**DFM Guidelines:**
- Specify impedance tolerances (±10% typical)
- Provide impedance test coupons
- Document stackup and trace geometry
- Specify materials with consistent dielectric constant

### Multi-Layer PCB Stack-Up Planning

Multi-layer PCB designs require **careful stack-up planning**.

**Advanced Techniques:**
- **Back-drilling**: Remove via stubs to improve signal integrity on high-speed signals
- **Sequential lamination**: Build up layers in stages for complex HDI boards
- **Cavity PCBs**: Recessed areas for component embedding

**DFM Considerations:**
- Communicate stack-up clearly to manufacturer
- Verify manufacturer capabilities before committing
- Specify controlled depth drilling requirements

## Component Selection for DFM

### Package Standardization

**Best Practice:**
Standardize on one or two resistor/capacitor sizes (e.g., **0402 and 0603**).

**Benefits:**
- Reduces feeder count on pick-and-place machines
- Reduces setup time
- Lowers assembly cost
- Simplifies inventory management

### Avoid Problematic Packages

**Assembly Challenges:**
- 0201 (0402 metric) and smaller: High risk of tombstoning, requires capable CM
- Ultra-fine pitch (< 0.4mm): Requires advanced assembly process
- BGA without marking: Difficult to verify orientation

**DFM Guideline:**
Use smallest package that meets requirements, but **avoid unnecessarily small packages** that increase assembly cost and risk.

### Standard Component Values

Use **E96/E24 series** for resistors and **standard capacitor values** (1pF, 2.2pF, 10pF, 22pF, 100pF, etc.).

**Benefits:**
- Better availability
- Lower cost
- Easier sourcing
- Second-source options

## BOM Optimization for Manufacturing

### Minimize Unique Part Numbers

**Strategy:**
- Consolidate resistor values (e.g., 4.7kΩ and 5.1kΩ pull-ups → one value if both work)
- Use same capacitor value across decoupling where possible
- Standardize on connector families

**Benefits:**
- **Fewer unique parts = fewer feeders = lower setup cost**
- Reduced inventory complexity
- Faster assembly
- Lower minimum order quantities

### Avoid Over-Specification

**Common Over-Specification Errors:**
- 1% resistors where 5% would suffice
- C0G capacitors where X7R would suffice
- Automotive-grade parts in consumer products
- Military-grade connectors in industrial applications

**Cost Impact:**
Tight tolerance and premium grades = **higher cost, potentially longer lead time**.

### Second-Source Documentation

Document **alternate/second-source parts** for critical components.

**Benefits:**
- Avoid production delays if primary part unavailable
- Competitive pricing from multiple sources
- Supply chain risk mitigation

## Assembly Process DFM

### Component Packaging Format

**Production Requirement:**
Component packaging format should be **tape-and-reel** for all components in volume production.

**Alternative Formats:**
- **Tubes**: Acceptable for low volume but slow down high-volume placement
- **Trays**: Used for large ICs, acceptable but slower than tape-and-reel
- **Cut tape**: Manual feed, not suitable for volume

### Tombstoning Prevention

**Tombstone-Prone Components:**
Small passive components (**0402 and smaller**) are tombstone-prone.

**DFM Mitigation:**
- Use 0603 or larger where board space permits
- Ensure balanced pad design
- Specify solder paste stencil aperture design
- Control reflow profile carefully

### Solder Bridging Risk

**High-Risk Packages:**
- Fine-pitch IC packages (< 0.5mm pitch)
- QFN packages with exposed pad
- BGA packages (inspection required)

**DFM Mitigation:**
- Specify solder mask between pads (solder mask defined pads for < 0.5mm pitch)
- Use appropriate stencil aperture ratio
- Specify inspection requirements (AOI, X-ray for BGA)

## Cost Optimization

### Identify Cost Drivers

**Top BOM Cost Contributors (Typical):**
1. **Connectors**: Often the most expensive passive components
2. **ICs**: Processors, FPGAs, specialty analog
3. **Precision components**: Tight-tolerance resistors, precision references

**Analysis:**
- Sort BOM by extended cost (unit cost × quantity)
- Focus optimization efforts on top 20% of cost
- Assess whether lower-cost alternatives exist without compromising function

### Assembly Cost Optimization

**Assembly Cost Drivers:**
- **Through-hole components** requiring hand soldering
- **Multiple assembly stages** (SMD top, SMD bottom, through-hole, mechanical)
- **Special processes** (underfill, conformal coating, selective soldering)
- **Fine-pitch components** (< 0.5mm pitch requires slower placement)
- **Component variety** (more unique parts = more feeders = longer setup)

**Optimization Strategies:**
- Minimize through-hole components
- Keep all components on one side if possible
- Use standard processes (avoid special requirements)
- Minimize unique part count

## Pre-Production DFM Review

### Design Review with Manufacturer

**Recommended Process:**
A design review for manufacturability **pre-production with the manufacturer** can:
- Catch readily apparent sources of defects
- Highlight subtler areas that may prove challenging
- Align design with manufacturer's process capabilities
- Identify opportunities for cost reduction

**When to Conduct:**
- Before releasing Gerbers for production
- After prototype build (capture lessons learned)
- When changing manufacturers

### DFM Report from Manufacturer

**Typical DFM Report Contents:**
- Fabrication capability violations (trace width, spacing, drill size)
- Assembly issues (component clearance, test point access)
- Cost optimization suggestions
- Yield risk assessment

## Sources

- [PCB Design for Manufacturing (DFM): Best Practices and Optimization Strategies for 2024 - Camptech II Circuits Inc.](https://camptechii.com/pcb-design-for-manufacturing-dfm-best-practices-and-optimization-strategies-for-2024/)
- [PCB Design For Manufacturability With Allegro X | Cadence](https://resources.pcb.cadence.com/blog/design-for-manufacturing-or-dfm-analysis-pcb-dfm-process-slp)
- [The importance of Design for Manufacturability in PCB design - Electronic Systems Design](https://blogs.sw.siemens.com/electronic-systems-design/2024/02/07/design-for-manufacturability-in-the-pcb-design-process/)
- [PCB Design For Manufacturing | PCB DFM Guidelines | MPE](https://www.mpe-electronics.co.uk/2024/04/23/pcb-design-for-manufacturing)
- [PCB Design For Manufacturability (DFM) - Bittele Electronics](https://www.7pcb.com/dfm)
- [8 Advanced PCB Design for Manufacturing Guidelines - Zuken US](https://www.zuken.com/us/blog/8-advanced-pcb-design-for-manufacturing-guidelines/)
