# Design for Manufacturability (DFM) Review — Schematic Review Context

## Purpose

This review evaluates the **manufacturability of the design at the schematic level** — identifying choices in component selection, circuit design, and BOM construction that will create problems during PCB fabrication, assembly, test, or production scaling. A design that works perfectly in simulation but cannot be reliably manufactured at volume is a failed design.

This review catches schematic-level DFM issues. PCB layout DFM (copper geometry, via sizes, etc.) is a separate review.

## Prerequisites

- Exported netlist
- BOM with specific part numbers, packages, and quantities
- Target production volume (prototype, low-volume, high-volume)
- Target assembly process (hand assembly, mixed, full SMT, double-sided reflow)
- Assembly house capabilities (if known)

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`18_design_manufacturability/`). These may contain assembly house design guidelines, approved component packages, preferred component values, soldering process specifications, or lessons learned from prior production builds.

## When to Ask the User for Clarification

Ask the user when:

- The target production volume is unknown (affects DFM priorities dramatically)
- The assembly process is not specified (hand solder vs. reflow vs. wave)
- Assembly house capabilities are unknown (minimum package size, BGA capability, etc.)
- The mix of through-hole and SMD components is unclear
- Test coverage requirements are not specified
- The product requires special assembly processes (conformal coating, underfill, etc.)
- Regulatory requirements for manufacturing (IPC class, cleanroom) are unknown

**DFM requirements for 10 prototype boards are very different from 10,000 production boards. Ask about volume.**

---

## Review Checklist

### 1. Component Package Selection

- [ ] Component packages are compatible with the assembly process:
  - Full SMT reflow: all SMD packages acceptable
  - Wave solder: through-hole components must tolerate wave solder temperatures
  - Mixed assembly: minimize the number of through-hole components requiring hand soldering
- [ ] Package sizes are within the assembly house's capability:
  - Can they place 0201 (0402 metric) components?
  - Can they place BGA packages? What minimum pitch?
  - Can they handle QFN packages with exposed pads?
- [ ] Avoid mixing different package sizes unnecessarily:
  - Standardize on one or two resistor/capacitor sizes (e.g., 0402 and 0603)
  - Reduces feeder count and setup time
- [ ] Avoid obsolete or uncommon package types
- [ ] Thermal pad packages (QFN, DFN, exposed pad QFP) identified — flag for layout attention
- [ ] No components that require special handling or tooling not available at the assembly house

### 2. BOM Optimization for Manufacturing

- [ ] Minimize unique part numbers:
  - Use the same resistor value where possible (e.g., consolidate 4.7kΩ and 5.1kΩ pull-ups to one value)
  - Use the same capacitor value and type across decoupling
  - Fewer unique parts = fewer feeders = lower setup cost
- [ ] Standard component values used (E96/E24 series for resistors, standard capacitor values)
- [ ] No unnecessarily tight tolerances:
  - 1% resistors where 5% would suffice
  - C0G capacitors where X7R would suffice
  - Tight tolerance = higher cost, potentially longer lead time
- [ ] All components have valid manufacturer part numbers (no generic descriptions)
- [ ] Alternate/second-source parts documented for critical components

### 3. Assembly Process Considerations

- [ ] **Tombstone-prone components** identified from BOM:
  - Small passive components (0402 and smaller) are tombstone-prone — flag for layout attention
- [ ] **Solder bridging risk** identified from BOM:
  - Fine-pitch IC packages (< 0.5mm pitch) have higher bridging risk
  - QFN packages with exposed pad
- [ ] **Hand-soldering requirements** minimized:
  - Through-hole components on a predominantly SMT board increase cost
  - Identify through-hole vs SMD mix from BOM package data

### 4. Testability Provisions

- [ ] **Test point components** present on key nets in the netlist
- [ ] **Functional test provisions**:
  - Test connectors or headers present for automated functional testing
  - Test mode activation (jumper, test pin) present in netlist
- [ ] **Boundary scan (JTAG)** for BGA and hard-to-probe ICs:
  - JTAG chain includes all boundary-scan-capable devices
  - JTAG connector present in netlist
- [ ] **Programming interface** present:
  - Flash programming header present in netlist
  - In-system programming possible (does not require removing the part)
- [ ] **Status indicator** LED present for power-on verification

### 5. Soldering & Process Compatibility

- [ ] **Wave solder compatibility** for through-hole components:
  - Component body can tolerate wave solder temperature (verify from BOM/datasheets)
- [ ] **Lead-free vs. leaded solder** compatibility:
  - All components must be compatible with the chosen solder process (verify from BOM/datasheets)
  - No mixing of lead-free and leaded components without documentation

### 6. Production Scaling Considerations

- [ ] Component packaging format (tape-and-reel) is standard for all components
  - Tubes and trays are acceptable for low volume but slow down high-volume placement

### 8. Cost Optimization

- [ ] Identify the top cost drivers in the BOM:
  - Connectors (often the most expensive passive components)
  - ICs (processors, FPGAs, specialty analog)
  - Precision components (tight-tolerance resistors, precision references)
- [ ] Assess whether lower-cost alternatives exist without compromising function
- [ ] Verify no over-specified components:
  - Automotive-grade parts in a consumer product
  - Military-grade connectors in an industrial application
  - Higher precision than the circuit requires
- [ ] Assembly cost drivers identified:
  - Through-hole components requiring hand soldering
  - Multiple assembly stages (SMD top, SMD bottom, through-hole, mechanical)
  - Special processes (underfill, conformal coating, selective soldering)

---

## Common DFM Issues at Schematic Level

| Issue | Severity | Description |
|-------|----------|-------------|
| Through-hole components on SMT board | Minor-Major | Increases assembly cost and time |
| No test points for ICT | Major | Cannot verify assembly quality |
| BGA without JTAG boundary scan | Major | Solder joint verification not possible |
| Excessive unique part numbers | Minor | Higher setup cost, more feeders |
| Non-standard component values | Minor | Longer lead time, higher cost |
| Missing programming header | Major | Cannot program firmware in production |
| Tight-tolerance parts unnecessary | Minor | Increased cost without benefit |
| Mixed package sizes on same BOM line | Major | Assembly confusion, potential misplacement |

## Severity Classification

- **Critical**: Design cannot be manufactured as drawn.
- **Major**: Design can be manufactured but with significant cost, yield, or quality impact.
- **Minor**: Non-optimal for manufacturing but acceptable.
- **Info**: Cost or efficiency optimization opportunity.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, component, BOM line]
- **DFM Category**: [Package Selection | BOM | Assembly | Test | Rework | Cost]
- **Description**: [What the manufacturing concern is]
- **Impact**: [Cost, yield, quality, schedule]
- **Recommendation**: [Component change, design note, process specification]
```
