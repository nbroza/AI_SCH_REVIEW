# Power Sequencing Best Practices

## Power Sequencing Fundamentals

### Why Power Sequencing Matters

FPGAs and similar components have multiple voltage rails which require power sequencing in a specific order to prevent damage from:
- **Latch-up**: Parasitic thyristor structures turning on
- **Transients**: Voltage spikes during power-up
- **ESD**: Electrostatic discharge during sequencing
- **Inrush current**: Excessive current during power-up

### Multiple Power Rails

Modern FPGAs and processors can have anywhere from **three to more than ten rails** powering them, with vendors typically specifying power sequencing requirements in datasheets.

**Typical Rail Timing:**
Core logic rails may toggle ON in **millisecond intervals or faster**, requiring precise timing control.

## Key Design Constraints

### Voltage Limits During Power-Up

**Differential Voltage Constraints:**
Voltage limits during power-up are sometimes specified in terms of a **potential difference between rails**. For example:
- VCCAUX - VCCINT must not exceed 2.0V during power-up
- VIO must not exceed VCCINT + 0.5V

**Ramp Rate Requirements:**
Some rails may be required to reach approximately **90% of the target voltage level** before the next rail can power ON.

### Modern FPGA Flexibility

Modern FPGAs (Xilinx UltraScale+, Intel Agilent, etc.) can be more flexible and tolerate **simultaneous power-up of rails**, though some still require specific sequencing orders. **Always consult the specific device datasheet.**

## Sequencing Implementation Methods

### Method 1: Cascading PGOOD Pins

**Description:**
Cascading the PGOOD (Power Good) pin of the first power supply into the ENABLE pin of the next power supply.

**Advantages:**
- Basic and cost-effective method
- No additional ICs required
- Simple to implement

**Disadvantages:**
- Limited flexibility
- No programmable delays
- Difficult to adjust timing after layout

**Example Implementation:**
```
Regulator 1 (VCCINT 1.0V)
  PGOOD → Regulator 2 ENABLE

Regulator 2 (VCCAUX 1.8V)
  PGOOD → Regulator 3 ENABLE

Regulator 3 (VIO 3.3V)
```

### Method 2: Reset ICs with Time Delay

**Description:**
Reset ICs monitor power rails with tight threshold limits. Once a rail is within three percent of its final value, the reset IC enters a wait period before powering up the next rail.

**Advantages:**
- Accurate voltage monitoring
- Programmable delays
- Fault detection capability

**Disadvantages:**
- Additional cost
- More complex than cascading

**Example Devices:**
- TI TPS3840 (voltage supervisor with delay)
- Microchip TC54 (voltage detector with delay)
- ADM1184 (quad voltage monitor with sequencer)

### Method 3: PMICs (Power Management ICs)

**Description:**
Power Management ICs integrate multiple regulators with programmable sequencing.

**Example:**
The **TI TPS650861 PMIC** has:
- Configurable controllers and converters
- Flexible sequencing via software
- Additional GPIOs that can control external converters for sequencing
- Real-time sequencing adjustments

**Advantages:**
- Maximum flexibility
- Software-configurable sequencing
- Integrated solution reduces BOM count
- Can handle complex multi-rail systems

**Disadvantages:**
- Higher cost
- More complex firmware/software configuration
- Single-point-of-failure (all rails depend on PMIC)

### Method 4: Microcontroller-Based Sequencing

**Description:**
Use a microcontroller to control enable pins of regulators via GPIOs.

**Advantages:**
- Ultimate flexibility
- Can implement complex sequencing algorithms
- Can monitor rail voltages via ADC
- Can implement fault recovery

**Disadvantages:**
- Requires firmware development
- MCU must be powered before sequencing begins
- More complex design

## Design Guidelines for Power Sequencing

### Sequencing Order Determination

**Step 1: Review Device Datasheet**
- Check "Power Supply Sequencing" or "Power-Up Requirements" section
- Note any mandatory sequencing order
- Identify maximum voltage differentials between rails

**Step 2: Core First, I/O Last**
General rule (verify with datasheet):
1. Core voltage (VCCINT, VDD_CORE)
2. Auxiliary/PLL voltage (VCCAUX, VDDA)
3. I/O voltage (VCCO, VIO)

**Step 3: Consider Power-Down Sequencing**
Power-down sequencing is often (but not always) the reverse of power-up.

### Timing Requirements

**Ramp Time:**
- Specify maximum ramp time for each rail (typically 0.1ms to 10ms)
- Too fast: inrush current problems
- Too slow: device may latch up during slow rise

**Inter-Rail Delay:**
- Specify minimum delay between rail enable events (typically 0.1ms to 5ms)
- Check datasheet for maximum allowable delay

**Hold Time:**
- Specify how long a rail must remain in regulation before enabling the next

### Monitoring and Fault Handling

**Power-Good Signals:**
- Use PGOOD from each regulator to confirm rail is in regulation
- Don't enable the next rail until PGOOD asserts

**Fault Detection:**
- Monitor for undervoltage, overvoltage, overcurrent
- Implement shutdown sequence if fault detected
- Consider brownout detection

**Reset Sequencing:**
- Hold device reset asserted until all rails are stable
- Release reset only after all PGOOD signals asserted
- Add delay (10-100ms) after last PGOOD before releasing reset

## Power Sequencing for Specific Devices

### Xilinx Zynq UltraScale+ MPSoCs

Reference: TI Application Note SLVAFP9 - "Powering Xilinx Zynq UltraScale+ MPSoCs"

**Key Requirements:**
- VCCINT (0.85V) must power up first or simultaneously with other rails
- VCCAUX (1.8V) can power up simultaneously or after VCCINT
- VCC_PSDDR (1.1V for DDR4, 1.35V for DDR3L) can power up any time
- VCCO (1.2V-3.3V) I/O voltages power up last

### Intel/Altera FPGAs

**General Sequencing:**
- VCCINT first
- VCCIO after VCCINT stabilizes
- Specific requirements vary by family (Cyclone, Stratix, Arria)

## Common Power Sequencing Issues

### Issue 1: Latch-Up During Power-Up
**Cause**: I/O voltage powered before core voltage
**Solution**: Ensure core voltage reaches 90% before enabling I/O voltage

### Issue 2: Inrush Current Trip
**Cause**: Multiple rails enabled simultaneously
**Solution**: Stagger enable times by 1-5ms

### Issue 3: Reset Released Too Early
**Cause**: Reset released before all rails stable
**Solution**: Hold reset until all PGOOD signals asserted + additional delay

### Issue 4: Sequencing Failure in Production
**Cause**: Timing too tight, component tolerances cause intermittent failure
**Solution**: Add margin to delays (use 2× minimum required delay)

## Sources

- [FPGA Power Sequencing Requirements](https://resources.altium.com/p/fpga-power-sequencing-requirements)
- [Power supply sequencing for an FPGA - Embedded Computing Design](https://embeddedcomputing.com/embedded-computing-design/power-supply-sequencing-for-an-fpga)
- [Application Note Powering Xilinx Zynq UltraScale+ MPSoCs With the TPS650861](https://www.ti.com/lit/pdf/slvafp9)
- [Complex Power-Supply Sequencing Made Easy | Analog Devices](https://www.analog.com/en/resources/analog-dialogue/articles/complex-power-supply-sequencing.html)
- [AN-1311: Complex Power Supply Sequencing Made Easy | Analog Devices](https://www.analog.com/en/resources/app-notes/an-1311.html)
- [Power-supply sequencing for FPGAs](https://www.ti.com/lit/slyt598)
