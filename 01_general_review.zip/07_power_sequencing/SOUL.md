# Power Sequencing Review — Schematic Review Context

## Purpose

This review verifies that **power rails come up and shut down in the correct order**, with proper timing, and that all sequencing dependencies specified by component datasheets are satisfied. Incorrect power sequencing can cause latch-up (permanent damage), excessive current draw during startup, failed initialization, or unreliable operation.

Many modern ICs — particularly FPGAs, processors, DDR memory, and multi-rail devices — have strict sequencing requirements. Violating them is a common cause of "works sometimes" failures.

## Prerequisites

- Exported netlist
- Power tree / power architecture diagram (if available)
- Datasheets for all multi-rail ICs (processors, FPGAs, SoCs, DDR, PMICs) in `../datasheets/`
- Power management IC (PMIC) datasheets in `../datasheets/`
- Enable/PGOOD signal chain documentation (if available)

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`07_power_sequencing/`). These may contain power sequencing timing diagrams, FPGA power-up requirements, processor startup specifications, or notes from previous design iterations.

Reference datasheets in `../datasheets/` — particularly the "Power Supply Sequencing" or "Power-Up/Power-Down" sections of multi-rail IC datasheets.

## When to Ask the User for Clarification

Ask the user when:

- You cannot find sequencing requirements in the datasheets provided
- The design uses a PMIC and you cannot determine its programmed sequencing order
- Enable chain connections are unclear or ambiguous
- You need to know the intended power-down behavior (graceful shutdown vs. hard power cut)
- Sleep/standby modes exist that require partial power rail management
- Hot-plug or hot-swap scenarios exist that affect sequencing
- The power supply startup time from the AC/DC or DC/DC frontend is unknown

**Power sequencing errors can cause physical damage. If you cannot determine the required sequence, ask.**

---

## Review Checklist

### 1. Sequencing Requirement Extraction

For every multi-rail IC (FPGA, processor, SoC, DDR, complex analog):

- [ ] Identify all supply rails required by the component
- [ ] Extract the datasheet-specified power-up sequence:
  - Which rail must come up first?
  - What is the maximum time between first rail and last rail?
  - Are there simultaneous rise requirements (rails must ramp together)?
  - What is the maximum voltage differential between rails during ramp?
- [ ] Extract the datasheet-specified power-down sequence (often reverse of power-up)
- [ ] Note any special requirements:
  - "Core supply must be established before I/O supply"
  - "VCCAUX must not exceed VCCINT + 0.3V at any time"
  - "All supply rails must be within specification before releasing reset"

### 2. Enable Chain Verification

- [ ] Map the complete enable chain: which signal enables which regulator
- [ ] Verify the enable chain implements the required sequencing order
- [ ] Check that PGOOD (power-good) outputs are used to trigger the next rail's enable:
  - PGOOD of Rail 1 → Enable of Rail 2 → PGOOD of Rail 2 → Enable of Rail 3 → ...
- [ ] Verify PGOOD thresholds:
  - PGOOD asserts when output is within regulation (typically 90-95% of nominal)
  - PGOOD deasserts when output drops below threshold
- [ ] Check for proper PGOOD pull-up resistors (many PGOOD outputs are open-drain)
- [ ] Verify the final PGOOD in the chain gates the system reset release
- [ ] Check that enable pins are not left floating during initial power-up (before their controlling signal is active)
  - Use pull-down resistors on enable pins that should default to OFF
  - Use pull-up resistors on enable pins that should default to ON

### 3. Timing Analysis

- [ ] Soft-start times for each regulator are documented and appropriate
- [ ] Total power-up time (from input power applied to all rails stable) is acceptable for the application
- [ ] Time between sequential rail activations meets IC datasheet requirements
- [ ] Monotonic rise is ensured (output voltage does not dip during startup):
  - Pre-biased startup capability needed if downstream loads can back-feed a rail
  - No pre-charging of output through body diodes of switching FETs
- [ ] Inrush current at each stage is within the upstream supply's capability
- [ ] Startup surge does not cause upstream regulator current limiting or shutdown

### 4. Power-Down Sequencing

- [ ] Power-down sequence is the reverse of power-up (unless datasheet specifies otherwise)
- [ ] No rail remains powered that depends on an already-removed rail
- [ ] I/O rails are removed before core rails (or as specified)
- [ ] Output drivers are disabled/tristated before their I/O supply is removed (to prevent bus contention)
- [ ] Shutdown is clean — no oscillation between on and off states
- [ ] Capacitor discharge paths exist for rails that need to be actively pulled down
- [ ] Discharge resistors or active discharge circuits are present where specified

### 5. Voltage Relationship Constraints

- [ ] At no point during power-up or power-down does VIO exceed VCORE + datasheet maximum differential
- [ ] Input pins do not see voltage before their supply rail is established (prevents ESD diode latch-up)
- [ ] If signals cross between voltage domains, the receiving domain's supply must be up before signals are driven
- [ ] Back-powering through ESD protection diodes is evaluated and mitigated:
  - Signal pins connected to a powered device while the receiving device's supply is off
  - Current flowing through ESD clamp diodes into an unpowered VCC rail

### 6. Reset Coordination

- [ ] System reset is held active until all power rails are stable and within specification
- [ ] Reset delay timer is long enough to cover worst-case power-up time plus settling
- [ ] Reset supervisor (if used) monitors the correct voltage rail(s)
- [ ] Reset release is clean (no glitches, proper debouncing)
- [ ] Brownout detection properly re-asserts reset if any rail drops below threshold
- [ ] Watchdog timer (if present) does not trigger during normal power-up sequence

### 7. Special Sequencing Scenarios

#### FPGA Power Sequencing
- [ ] Core voltage (VCCINT) powers up first (typically)
- [ ] Auxiliary voltage (VCCAUX) powers up second
- [ ] I/O bank voltages (VCCO) power up last
- [ ] Configuration pins are in correct state before I/O supplies are active
- [ ] Verify against the specific FPGA family's power-up requirements

#### DDR Memory Sequencing
- [ ] VDD and VDDQ sequencing meets JEDEC specification for the DDR generation
- [ ] VTT termination voltage follows VDDQ
- [ ] VREF follows VDD/VDDQ
- [ ] Reset is held during power-up per JEDEC timing requirements

#### Processor / SoC Sequencing
- [ ] Core supply before I/O supply (typically)
- [ ] PLL supply sequencing per datasheet
- [ ] Boot mode pins are stable before reset release
- [ ] External memory supply is stable before processor attempts initialization

### 8. PMIC Configuration (if applicable)

- [ ] PMIC output assignments match the required voltage rails
- [ ] PMIC sequencing configuration (OTP, registers, or resistor-strapped) implements the correct order
- [ ] PMIC fault handling is appropriate:
  - Individual rail fault: shutdown just that rail, or shutdown all?
  - Overtemperature: shutdown behavior
  - UVLO: orderly shutdown or immediate cutoff
- [ ] PMIC startup delay from input power to first output is documented
- [ ] PMIC I2C/SPI configuration (if programmable) happens at the correct time in the boot sequence

---

## Common Power Sequencing Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| I/O supply before core supply | Critical | Can cause FPGA/processor latch-up |
| Signal driven into unpowered IC | Critical | Current through ESD diodes can cause latch-up or damage |
| Enable pin floating at power-up | Major | Undefined regulator state during startup |
| Missing PGOOD chain | Major | No guarantee of sequencing order |
| No reset hold during power-up | Major | Processor attempts boot before supplies stable |
| Non-monotonic regulator startup | Major | IC may interpret dip as power failure |
| Missing discharge on shutdown | Minor | Rail remains powered by charge on large caps |
| PGOOD pull-up missing | Major | Open-drain PGOOD output floats undefined |

## Severity Classification

- **Critical**: Sequencing violation can cause latch-up, permanent component damage, or safety hazard.
- **Major**: Sequencing issue causes unreliable startup or functional failure.
- **Minor**: Non-optimal sequencing but device tolerates it per datasheet.
- **Info**: Sequencing improvement suggestion.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet name/number, regulator/rail, affected IC]
- **Description**: [What sequencing requirement is violated]
- **Required Sequence**: [What the datasheet specifies]
- **Actual Sequence**: [What the schematic implements]
- **Recommendation**: [How to fix the sequencing]
- **Reference**: [Datasheet page/section for the sequencing requirement]
```
