# Net Connectivity & Completeness Best Practices

## Netlist Connectivity Verification

### Fundamental Principles

A netlist check is a crucial step in the PCB design process to ensure that the netlist accurately reflects the intended circuit connectivity. The netlist defines electrical connections by listing all nets between component pins.

### Connectivity Verification Methods

**Automated Checking:**
- Modern PCB design tools (OrCAD X, Altium, etc.) verify that all intended electrical connections are correctly established according to design specifications
- Automated tools identify and highlight errors such as open circuits, short circuits, or missing connections

**Visual Verification:**
- Use PCB layout software's connectivity features to visually inspect traces, pads, and vias
- Verify connectivity between components on the layout matches the connections specified in the netlist

**Manufacturing Verification:**
- CAM software uses netlist output to verify that logical connections match actual connections in fabrication data (Gerbers, ODB++)

## Intentional No-Connect Verification

### Best Practices

Not all unconnected pins are errors. Many ICs have:
- Reserved pins that must be left floating
- Optional feature pins that may be unconnected
- Test pins not used in production

**Verification Process:**
1. Identify all unconnected pins in the netlist
2. Cross-reference each unconnected pin with the component datasheet
3. Verify that leaving the pin unconnected is explicitly allowed or recommended
4. Document intentional no-connects in design notes

## Test Point Management

### Test Point Strategy

Test points are critical for:
- Production testing (ICT, flying probe)
- Debugging and bring-up
- Field diagnostics and repair

**Key Nets Requiring Test Points:**
- All power rails (input and regulated outputs)
- Critical control signals (reset, enable, chip select)
- Communication interfaces (UART, I2C, SPI)
- High-speed clocks
- Analog signals (ADC inputs, voltage references)

**Implementation:**
- Test points should be represented as components in the netlist
- Each test point component connects to exactly one net
- Test points should be labeled clearly in the design

## Common Connectivity Issues

### Open Connections
- Missing trace between components
- Unintentional stub or dangling trace segment
- Pin left unconnected when connection was intended

### Short Circuits
- Adjacent nets incorrectly bridged
- Power and ground shorted
- Signal nets shorted together

### Missing Connections
- Power pins not connected to supply rail
- Ground pins not connected to ground net
- Required bypass capacitors omitted
- Termination resistors missing

## Design Coordination

### Reference Designators

The reference designator is the most immediate and reliable method of aligning the BOM, schematic, and netlist. Any alterations must be present in all three locations to ensure documentation remains in lockstep.

### Cross-Probing

Cross-probing between the schematic and board layout allows designers to quickly verify connectivity and group components according to the reference designators used in schematic pages.

## Sources

- [Understanding PCB Connectivity Management With OrCAD X | Cadence](https://resources.pcb.cadence.com/blog/2024-understanding-pcb-connectivity-management-with-orcad-x)
- [Schematic and Netlist Checks for Error-Free PCBs | Sierra Circuits](https://www.protoexpress.com/blog/schematic-and-netlist-checks-ensure-error-free-designs/)
- [What is a PCB Netlist | Cadence](https://resources.pcb.cadence.com/blog/what-is-a-pcb-netlist-2)
- [What Are Netlists in PCB Design Projects?](https://resources.altium.com/p/what-are-netlists-pcb-design-projects)
- [What is a PCB Netlist and Why do You Need It?](https://blog.epectec.com/what-is-a-pcb-netlist-and-why-do-you-need-it)
