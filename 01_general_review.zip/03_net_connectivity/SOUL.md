# Net Connectivity & Completeness Review — Schematic Review Context

## Purpose

This review verifies that **every net in the schematic is intentionally and correctly connected**. It catches floating inputs, missing connections, dangling nets, incomplete buses, and improperly handled unused pins. These are among the most common schematic errors and are often invisible until the board fails in testing.

## Prerequisites

- Exported netlist
- BOM with component part numbers and pinouts
- Datasheets in `../datasheets/` for pin function and requirements

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`03_net_connectivity/`). These may contain project-specific net naming conventions, known connectivity requirements, or supplemental checklists for common bus topologies used in the design.

Reference datasheets in `../datasheets/` to verify how unused pins should be handled per manufacturer recommendations.

## When to Ask the User for Clarification

Ask the user when:

- A pin appears unconnected but you cannot determine if it is intentionally unused
- A net exists with only one pin connection (orphaned — goes nowhere)
- Bus signals appear to have gaps in numbering (e.g., DATA[0:7] but DATA[3] is missing)
- Multiple ground nets exist and you are unsure if they should be unified or kept separate
- You encounter a "no-connect" marker on a pin that the datasheet says must be connected
- Pull-up/pull-down requirements are ambiguous from the datasheet

**Do not assume an unconnected pin is intentional. Verify.**

---

## Review Checklist

### 1. Floating Input Detection

- [ ] **All CMOS digital inputs** are driven to a defined logic level (VCC or GND through a resistor, or driven by an output)
- [ ] **Unused gate inputs** on multi-gate ICs (e.g., quad NAND, dual op-amp) are properly terminated:
  - Unused logic gate inputs: tied to VCC or GND as appropriate for the gate type
  - Unused op-amp inputs: non-inverting to mid-rail or ground, inverting to output (unity gain)
  - Unused comparator inputs: tied to a defined reference voltage
- [ ] **Configuration/strap pins** (address pins, mode select, boot config) are all driven to a defined level
- [ ] **Interrupt pins** that are active-low have pull-up resistors if no internal pull-up is enabled
- [ ] **Reset pins** are properly terminated with pull-up/pull-down and appropriate RC filtering
- [ ] **Enable/shutdown pins** are driven to the correct active state

### 2. Unconnected Pin Verification

- [ ] Every unconnected IC pin is verified against the datasheet:
  - Datasheet says NC/no-connect → acceptable to leave unconnected
  - Datasheet says "do not connect" (DNC) → must not be connected to anything (different from NC)
  - Datasheet says "reserved, connect to GND" → must be connected to ground
  - Datasheet says "reserved, leave floating" → must be left unconnected
- [ ] No pin that the datasheet requires to be connected is left unconnected

### 3. Open-Drain / Open-Collector Outputs

- [ ] All open-drain outputs have appropriate pull-up resistors
- [ ] Pull-up voltage is compatible with the receiving input's logic levels
- [ ] Pull-up resistor value is appropriate for the bus speed and capacitance:
  - I2C: typically 2.2k-10k depending on bus speed and capacitance
  - Generic open-drain: sized for adequate rise time vs. current consumption
- [ ] Wired-OR / wired-AND connections are intentional and properly documented
- [ ] Open-drain outputs driving long traces or off-board signals have appropriate pull-up placement

### 4. Bus Continuity & Completeness

- [ ] All bus signals are complete — no missing bits in address/data buses
  - Verify DATA[0:N] has every bit connected from source to destination
  - Verify ADDR[0:N] has every bit connected
- [ ] Bus direction is consistent — no cases where two bus masters drive simultaneously without arbitration
- [ ] Directly-connected buses have matching bit widths on both ends
- [ ] Bus transceivers / buffers (if present) have correct direction control
- [ ] Active-low byte enables, write enables, read enables are properly driven
- [ ] Directly verify common bus mistakes:
  - Bit-swapped data lines (DATA0 on source connected to DATA1 on destination)
  - Address line offset errors (ADDR1 connected to A0 of memory)

### 5. Orphaned Nets

- [ ] No nets that connect to only one pin (orphaned — intended connection likely missing)
- [ ] No net names with typographical variations that should be the same net (e.g., `SPI_CLK` vs `SPI_SCLK` vs `SPICLK`)

### 6. Power Pin Connectivity

- [ ] Every IC VCC/VDD pin is connected to the correct power rail
- [ ] Every IC GND/VSS pin is connected to the correct ground net
- [ ] Analog supply pins (AVCC, AVDD) are connected to the appropriate filtered/quiet rail
- [ ] Power pins on ICs with multiple supply domains are each connected to the correct domain
- [ ] Thermal/exposed pads are connected to ground (or as specified by datasheet)
- [ ] Multi-die packages have all die power pins connected (not just the first)

### 7. Pull-Up / Pull-Down Completeness

- [ ] I2C buses have pull-up resistors on SDA and SCL
- [ ] SPI chip-select lines have pull-ups to prevent floating during boot/reset
- [ ] UART RX lines have pull-ups to prevent noise during boot
- [ ] Reset lines have pull-ups (active-low reset) or pull-downs (active-high reset) with decoupling capacitor
- [ ] GPIO pins used as inputs have defined default states
- [ ] Boot/mode select pins have resistors to set default configuration
- [ ] Open-drain status/interrupt outputs have pull-ups to appropriate voltage

### 8. Test Point & Debug Access

- [ ] Test point components exist in the netlist on critical power rails
- [ ] Debug interfaces (JTAG, SWD, UART console) are connected to a debug header/connector
- [ ] Test point components exist on key control signals (resets, enables, chip selects)

---

## Common Connectivity Failures

| Issue | Severity | Description |
|-------|----------|-------------|
| Floating CMOS input | Critical | Causes oscillation, excess current draw, unpredictable behavior |
| Missing I2C pull-ups | Major | Bus will not function |
| Orphaned net label | Major | Signal goes nowhere — intended connection missing |
| Open-drain without pull-up | Major | Output cannot drive high |
| Unused opamp input floating | Major | Output saturates to rail, may cause excessive current |
| Missing NC markers | Minor | Unclear if pin was intentionally left unconnected |
| Bit-swapped bus lines | Critical | Data corruption, device malfunction |
| Reserved pin mishandled | Major | Connected when datasheet says float, or floating when should be grounded |

## Severity Classification

- **Critical**: Unconnected or misconnected net will cause board failure or damage.
- **Major**: Missing connection will prevent a feature or subsystem from working.
- **Minor**: Connection issue is cosmetic or affects non-critical functionality.
- **Info**: Suggestion for improved clarity or robustness.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet name/number, reference designator, pin number/name, net name]
- **Description**: [What was found]
- **Recommendation**: [What should be changed]
- **Reference**: [Datasheet page, standard, or best practice source]
```
