# Datasheet Recommendation Mismatch Review — Schematic Review Context

## Purpose

This review systematically compares **every component's schematic implementation against its datasheet** — specifically the recommended application circuits, absolute maximum ratings, electrical characteristics, and application notes. The goal is to catch deviations from manufacturer recommendations that could cause malfunction, reduced reliability, or outright failure.

This is one of the most critical reviews. Datasheets exist because the manufacturer has characterized their part. Deviating from their recommendations without understanding why is a leading cause of board failures.

## Prerequisites

- Exported netlist
- BOM with specific manufacturer part numbers
- **All datasheets for every active component collected in `../datasheets/`** — this is mandatory
- Application notes referenced by datasheets (if available, also in `../datasheets/`)

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`04_datasheet_mismatch/`). These may contain project-specific design decisions that intentionally deviate from datasheet recommendations (and the justification for those deviations), or supplemental application note summaries.

**You must read and reference the actual datasheets in `../datasheets/` for every component being reviewed.** Do not rely on general knowledge — verify against the specific part number's datasheet.

## When to Ask the User for Clarification

Ask the user when:

- A schematic deviates from the datasheet recommended circuit and you cannot determine if it is intentional
- The datasheet provides multiple application circuit options and you cannot determine which one applies
- Component values differ from datasheet recommendations but might be valid for the specific application
- The datasheet references an application note that is not available in the datasheets folder
- Operating conditions (temperature, input voltage range, load current) are not specified and affect component selection
- A newer revision of a datasheet might exist with different recommendations

**Datasheets are the ground truth. If the schematic disagrees with the datasheet, flag it. Let the designer justify the deviation.**

---

## Review Checklist

### 1. Recommended Application Circuit Comparison

For **every IC and active component** in the design:

- [ ] Compare the schematic circuit against the datasheet's recommended/typical application circuit
- [ ] Verify all recommended external components are present:
  - Input capacitors (value, type, voltage rating)
  - Output capacitors (value, type, ESR requirements)
  - Bootstrap capacitors
  - Compensation network components
  - Snubber components
  - Bias resistors
  - Timing resistors/capacitors
  - Filter components
- [ ] Verify component values match datasheet recommendations:
  - If different, calculate and verify the intent (e.g., different output voltage, different frequency)
  - Flag any values that seem arbitrary or lack justification
- [ ] Check for recommended component types (e.g., "use X7R ceramic" not "use Y5V", "low-ESR tantalum required")

### 2. Pin Configuration Verification

- [ ] Pin-for-pin mapping matches the datasheet for the **specific package variant** being used
  - SOIC-8 and DFN-8 of the same IC may have different pinouts
  - Verify against the correct package drawing
- [ ] Thermal/exposed pad connection matches datasheet recommendation (usually GND, sometimes specific net)
- [ ] NC pins handled exactly as datasheet specifies (see Net Connectivity review)
- [ ] Multi-function pins are configured for the intended function per datasheet instructions
- [ ] Analog and digital ground pins are connected per datasheet star-ground or unified-ground recommendation

### 3. Operating Condition Compliance

- [ ] Input voltage is within the recommended operating range (not just absolute maximum)
- [ ] Output voltage is within the achievable range for the given input conditions
- [ ] Operating temperature range of the selected part variant matches the design's environmental requirements
  - Commercial (0 to +70C), Industrial (-40 to +85C), Automotive (-40 to +125C), Military (-55 to +125C)
- [ ] Load current is within the component's rated continuous output capability
  - Account for derating at elevated temperatures
- [ ] Switching frequency (for regulators) is set within the recommended range
- [ ] Minimum load requirements are met (some regulators require a minimum load for stability)

### 4. Voltage Regulator Specific Checks

- [ ] Feedback resistor divider values produce the correct output voltage per the datasheet formula
  - Recalculate: VOUT = VREF × (1 + R_TOP / R_BOTTOM) — or as specified by the specific part
  - Use the exact VREF value from the datasheet (not a rounded value)
- [ ] Compensation network matches datasheet recommendation for the given operating conditions
  - If custom compensation: verify stability (requires loop gain analysis — flag for review)
- [ ] Soft-start capacitor/resistor value matches intended start-up time per datasheet formula
- [ ] Current limit set resistor (if external) produces the correct threshold
- [ ] UVLO (under-voltage lockout) thresholds are appropriate for the input supply
- [ ] Output capacitor ESR is within the stable range specified by the datasheet
  - Some regulators require minimum ESR (e.g., LDOs needing ESR for stability)
  - Some regulators require maximum ESR (e.g., ceramic-only stable LDOs)
- [ ] Input capacitor meets minimum capacitance after DC bias derating

### 5. Oscillator & Clock Component Checks

- [ ] Crystal load capacitors match the crystal's specified load capacitance:
  - CL = (C1 × C2) / (C1 + C2) + C_stray (typically 2-5pF)
  - Verify C1 and C2 values produce the correct CL
- [ ] Crystal drive level does not exceed the maximum specified by the crystal datasheet
- [ ] Feedback resistor across the crystal (if required) matches the datasheet recommendation
- [ ] External clock input levels match the IC's specified thresholds

### 6. Interface-Specific Datasheet Checks

- [ ] I2C pull-up resistor values are within the range specified by both the IC datasheet and I2C specification for the target bus speed
- [ ] SPI maximum clock frequency is respected
- [ ] UART baud rate is achievable with the given clock source (verify baud rate error)
- [ ] ADC reference voltage is within the specified range and uses recommended filtering
- [ ] DAC output loading is within the specified drive capability

### 7. Absolute Maximum Ratings Audit

For every component, verify that **no operating condition approaches within 80% of the absolute maximum rating** (see Thermal & Derating review for detailed analysis):

- [ ] Maximum supply voltage
- [ ] Maximum input voltage on any pin
- [ ] Maximum output current
- [ ] Maximum junction temperature
- [ ] Maximum power dissipation
- [ ] ESD ratings are appropriate for the pin's exposure level

### 8. Errata & Known Issues

- [ ] Check for published errata documents for the specific silicon revision being used
- [ ] Verify that any errata workarounds are implemented in the schematic
- [ ] Check for datasheet revisions — is the design based on the latest datasheet?
- [ ] Review manufacturer's application notes for additional design guidance

---

## Common Datasheet Mismatches

| Issue | Severity | Description |
|-------|----------|-------------|
| Wrong feedback resistor values | Critical | Output voltage incorrect — can damage downstream components |
| Missing recommended capacitor | Critical | Regulator may oscillate or fail to regulate |
| Wrong capacitor type | Major | ESR mismatch causes instability (e.g., ceramic where tantalum required) |
| Pinout mismatch for package variant | Critical | Pins connected to wrong functions |
| Operating outside recommended range | Major | Part may work on bench but fail in field |
| Missing compensation components | Critical | Control loop instability |
| Wrong crystal load caps | Major | Frequency offset, failure to oscillate, or excess drive |
| Ignored minimum load requirement | Major | Regulator output oscillates or rises above setpoint |

## Severity Classification

- **Critical**: Deviation from datasheet will cause component failure, oscillation, or damage.
- **Major**: Deviation will cause degraded performance or reduced reliability.
- **Minor**: Deviation from best practice but unlikely to cause failure.
- **Info**: Datasheet offers optimization that is not implemented.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet name/number, reference designator, specific pin or component]
- **Description**: [What the schematic shows vs. what the datasheet recommends]
- **Datasheet Reference**: [Part number, datasheet revision, page/section/figure number]
- **Recommendation**: [What should be changed to match the datasheet]
```
