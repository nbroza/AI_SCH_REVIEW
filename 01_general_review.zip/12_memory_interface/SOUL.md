# Memory Interface Review — Schematic Review Context

## Purpose

This review validates **memory interface circuits at the schematic level** — DDR SDRAM, NAND/NOR flash, SRAM, EEPROM, and other memory technologies. Memory interfaces are among the most timing-critical and layout-sensitive circuits in a design. While detailed timing is a layout concern, the schematic must correctly implement termination, topology, power, configuration pins, and initialization requirements.

Getting DDR termination or strap pin configuration wrong at the schematic level cannot be fixed in layout.

## Prerequisites

- Exported netlist
- Memory IC datasheets (JEDEC specs for DDR, flash datasheets) in `../datasheets/`
- Controller/processor datasheets (memory controller section) in `../datasheets/`
- Controller reference design schematics (if available)
- Target memory speed/bandwidth requirements

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`12_memory_interface/`). These may contain memory timing budgets, DDR routing guidelines from the processor vendor, memory vendor layout guides, or signal integrity simulation results.

Reference datasheets in `../datasheets/` for both the memory device and the memory controller.

## When to Ask the User for Clarification

Ask the user when:

- The DDR speed grade or target data rate is not specified
- The processor/controller memory controller specifications are not available
- The number of memory ranks is unclear
- The memory topology (fly-by vs. T vs. clamshell) is not documented
- JEDEC specification version for the DDR generation is needed but not available
- The design uses a memory configuration not shown in the controller's reference design
- Training/calibration capabilities of the memory controller are unknown

**DDR design requires precise specification compliance. If the DDR generation or speed grade is unclear, ask before reviewing.**

---

## Review Checklist

### 1. DDR SDRAM Interface

#### Power Supply
- [ ] VDD (core supply): correct voltage for DDR generation
  - DDR3: 1.5V (1.35V for DDR3L)
  - DDR4: 1.2V
  - DDR5: 1.1V (on-DIMM regulation)
  - LPDDR4/4X: 1.1V/0.6V
  - LPDDR5: 0.5V/1.05V/1.8V
- [ ] VDDQ (I/O supply): matches VDD for most DDR generations
- [ ] VTT (termination supply): VDD/2, supplied by appropriate VTT regulator
  - VTT regulator must sink and source current
  - VTT regulator must have low output impedance
  - Dedicated VTT LDO recommended (not a divider)
- [ ] VREF (reference voltage): VDD/2, with appropriate filtering
  - VREF divider resistors are precision (0.1% recommended)
  - VREF bypass capacitor is present (100nF minimum)
  - VREF source impedance is low enough for all connected inputs
- [ ] VPP (DDR4 activation supply): 2.5V, if required by the specific DDR4 device
- [ ] Decoupling per JEDEC recommendations:
  - 100nF per VDD/VDDQ pin
  - Bulk capacitance per memory device (typically 10µF per device)

#### Address/Command/Control Signals
- [ ] All address bits are connected: A[0:N] — verify bit count for memory density
  - DDR3: up to A[15:0] + BA[2:0]
  - DDR4: up to A[17:0] + BG[1:0] + BA[1:0]
- [ ] Command signals connected: RAS#/CAS#/WE# (DDR3) or combined command (DDR4)
- [ ] Chip select (CS#) connected — one per rank
- [ ] Clock enable (CKE) connected — one per rank
- [ ] ODT (On-Die Termination) connected — one per rank
- [ ] Reset# connected (DDR3/DDR4)
- [ ] Fly-by topology for address/command/control signals (DDR3/DDR4):
  - Signals daisy-chain from controller to first DRAM to last DRAM
  - Terminated at the far end with appropriate termination
  - NOT T-topology (which was used in DDR2)

#### Data Signals
- [ ] Data bits DQ[0:N] are all connected and correctly mapped to byte lanes
- [ ] Data strobe DQS/DQS# pairs are connected — one pair per byte lane (8 bits)
- [ ] Data mask DM (DDR3) or DBI# (DDR4) signals are connected per byte lane
- [ ] Data signals use point-to-point topology (not fly-by) for each rank
- [ ] Byte lane grouping is correct:
  - DQ[0:7] + DQS0/DQS0# + DM0 = Byte Lane 0
  - DQ[8:15] + DQS1/DQS1# + DM1 = Byte Lane 1
  - etc.

#### Clock
- [ ] Differential clock pair CK/CK# connected
- [ ] One clock pair per rank (or per DIMM slot)
- [ ] Clock termination at memory device (usually ODT handles this)
- [ ] Clock-to-data timing relationship is correct for the topology

#### Termination
- [ ] On-die termination (ODT) configuration is appropriate for the topology:
  - Single rank: specific ODT values per JEDEC
  - Dual rank: different ODT values when reading/writing to each rank
- [ ] External termination (if used) matches JEDEC recommendations
- [ ] VTT termination resistors on address/command bus (if not using ODT for these)
- [ ] Unused DQ bits terminated appropriately (if memory width > controller width)

#### Configuration & Initialization
- [ ] Memory density select pins (if present) are correctly strapped
- [ ] ZQ calibration resistor: 240Ω ±1% to GND (DDR3/DDR4)
- [ ] ZQ resistor is exclusive to each memory device (not shared)

### 2. NAND Flash Interface

- [ ] Data bus width matches controller expectations (x8 or x16)
- [ ] All signal connections verified:
  - I/O[0:7] or I/O[0:15] data bus
  - CLE (Command Latch Enable)
  - ALE (Address Latch Enable)
  - CE# (Chip Enable) — one per die/target
  - RE# / RE (Read Enable)
  - WE# (Write Enable)
  - WP# (Write Protect) — driven appropriately, not floating
  - R/B# (Ready/Busy) — open-drain, needs pull-up
- [ ] Multiple NAND devices: CE# lines independently controlled
- [ ] Pull-up resistors on R/B# outputs (open-drain)
- [ ] WP# is actively driven (not floating — floating may enable protection)
- [ ] Data bus I/O voltage matches controller voltage level
- [ ] NAND power supply decoupling per datasheet

### 3. NOR Flash / SPI Flash

#### Parallel NOR
- [ ] Address bus width matches memory density
- [ ] Data bus width matches controller configuration
- [ ] CE#, OE#, WE# signals properly connected
- [ ] BYTE# mode select (if applicable) correctly strapped
- [ ] RESET# properly managed
- [ ] WP#/ACC properly driven

#### SPI NOR Flash
- [ ] SPI signals connected: SCK, MOSI (SI/IO0), MISO (SO/IO1), CS#
- [ ] Quad-SPI signals (if used): IO2 (WP#), IO3 (HOLD#/RESET#) properly connected
  - In single-SPI mode: WP# and HOLD# need pull-ups to VCC
  - In quad mode: all four I/O lines connected to controller
- [ ] HOLD# pin managed (pull-up if not used, driven if used)
- [ ] WP# pin managed (pull-up to disable write protection, or driven by GPIO)
- [ ] SPI clock speed is within the flash device's specification
- [ ] SPI mode (CPOL/CPHA) matches between controller and flash

### 4. SRAM

- [ ] Address and data bus widths match the SRAM density and configuration
- [ ] Control signals: CE#, OE#, WE#, UB#/LB# (byte enables) properly connected
- [ ] Asynchronous SRAM timing is compatible with the controller's bus timing
- [ ] SRAM power supply is always-on if it is used for data retention
- [ ] Battery backup (if used for non-volatile SRAM):
  - Battery switchover circuit is correct
  - CE# is deasserted during power-down
  - Data retention current is within battery's capability

### 5. EEPROM / I2C Memory

- [ ] I2C address pins (A0, A1, A2) are correctly strapped for the intended address
- [ ] No address conflicts with other I2C devices on the same bus
- [ ] WP (Write Protect) pin is properly managed:
  - Tied to VCC for read-only operation
  - Tied to GND or GPIO-controlled for read-write
- [ ] I2C pull-up resistors are present (may be shared with other I2C devices)
- [ ] EEPROM VCC decoupling capacitor is present
- [ ] Page write size is compatible with the controller's I2C driver

---

## Common Memory Interface Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| Missing ZQ calibration resistor | Critical | DDR impedance calibration fails |
| Wrong VTT voltage | Critical | Incorrect termination voltage corrupts data |
| Missing VREF or wrong VREF voltage | Critical | Data sampling at wrong threshold |
| Address bit swapped or missing | Critical | Wrong memory locations accessed |
| DQ-to-DQS byte lane mismatch | Critical | Data corruption on specific bytes |
| Fly-by vs. T-topology error | Major | Timing mismatch, may work marginally |
| SPI flash HOLD# floating | Major | Device randomly holds — intermittent failures |
| NAND WP# floating | Major | Writes may fail unpredictably |
| Missing pull-up on R/B# | Major | Cannot determine NAND ready state |
| I2C EEPROM address conflict | Major | Two devices respond to same address |
| Wrong DDR supply voltage | Critical | Memory damage or failure to operate |

## Severity Classification

- **Critical**: Memory interface will not function or will cause data corruption.
- **Major**: Interface may work marginally but fail under certain conditions.
- **Minor**: Non-optimal but unlikely to cause data errors.
- **Info**: Optimization or best practice suggestion.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, memory device designator, controller, signal/pin]
- **Memory Type**: [DDR3/DDR4/NAND/NOR/SPI Flash/SRAM/EEPROM]
- **Description**: [What was found]
- **Specification Reference**: [JEDEC spec, memory datasheet page, controller datasheet page]
- **Recommendation**: [What should be changed]
```
