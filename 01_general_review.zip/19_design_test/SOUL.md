# Design for Test (DFT) Review — Schematic Review Context

## Purpose

This review evaluates whether the **schematic provides adequate provisions for testing, debugging, and validating the assembled board** — from production test on the assembly line through engineering bring-up, qualification testing, and field diagnostics. A board that cannot be effectively tested is a board where defects escape to the customer.

This review covers testability at the schematic level. Physical test point placement is a layout concern but must be enabled by the schematic.

## Prerequisites

- Exported netlist
- BOM with specific part numbers and packages
- Test strategy document (if available): ICT, functional test, boundary scan, etc.
- Production test requirements (cycle time, coverage targets)
- Debug and bring-up requirements
- Field service / repair requirements
- Datasheets in `../datasheets/` for boundary scan and self-test capable ICs

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`19_design_test/`). These may contain test strategy documents, test point requirements from the test engineering team, production test fixtures specifications, or debug procedures from prior design revisions.

## When to Ask the User for Clarification

Ask the user when:

- The production test strategy is not defined (ICT, flying probe, functional, boundary scan)
- Test coverage requirements are not specified (what percentage of nets must be testable)
- The test engineering team's fixture capabilities are unknown
- Field repair strategy is not defined (board-level replacement vs. component-level repair)
- Regulatory test requirements are not specified (safety testing, EMC testing, environmental testing)
- Burn-in or stress testing requirements exist but are not documented

**Test provisions added late in the design cycle are expensive or impossible. Ask about the test strategy early.**

---

## Review Checklist

### 1. Test Point Coverage

- [ ] **Power rail test points**: every voltage rail has at least one test point
  - Input voltage
  - Each regulated output
  - Critical intermediate voltages
  - Ground reference point
- [ ] **Communication interface test points**:
  - UART TX/RX for debug console access
  - I2C SDA/SCL for bus monitoring
  - SPI signals for debug
  - CAN bus signals
- [ ] **Control signal test points**:
  - Reset signals
  - Enable signals for critical subsystems
  - Chip select signals
  - Clock signals
  - Interrupt signals
- [ ] **Analog signal test points**:
  - Sensor inputs (before and after conditioning)
  - ADC inputs
  - DAC outputs
  - Voltage reference outputs
  - Op-amp outputs
- [ ] **Status signal test points**:
  - Power-good signals
  - Fault indicators
  - Status outputs
  - Busy/ready signals

### 2. Debug Interface Access

- [ ] **JTAG/SWD debug port**:
  - Connected to all target devices in the JTAG chain
  - Debug connector present in netlist
  - Pinout matches the target debug probe
  - All JTAG signals have appropriate pull-ups/pull-downs for safe default state
  - Debug port functional when the board is fully assembled
  - No functional circuitry depends on the debug connector being populated or unpopulated
- [ ] **Serial debug console**:
  - UART TX/RX available on a header or test points
  - Baud rate and configuration documented
  - Level shifting (if needed) to connect to standard USB-UART adapter
  - Console available during early boot (before complex peripherals initialize)
- [ ] **Boot mode selection**:
  - Boot mode pins accessible (headers, jumpers, or DIP switches)
  - Can switch between normal boot, bootloader, and recovery modes
  - Default boot mode is clearly defined and documented
  - Boot mode configuration survives power cycling

### 3. Production Test Provisions

#### In-Circuit Test (ICT)
- [ ] Key nets have dedicated test point components in the netlist
- [ ] Both sides of critical passive components have test point access (test point components present)
- [ ] Power supply rails can be force-sensed through dedicated test points
- [ ] ICs can be boundary-scanned (JTAG chain verified)

#### Functional Test
- [ ] Test connector or edge connector allows automated test equipment connection
- [ ] External power input provisions exist (header or connector for bench supply)
- [ ] Test stimulus inputs are accessible:
  - Clock inputs can be overridden by external source
  - Analog inputs can be driven by test equipment
  - Digital inputs can be stimulated
- [ ] Test observation outputs are accessible:
  - Analog outputs can be measured
  - Digital outputs can be captured
  - Status indicators can be read by automated equipment
- [ ] Loopback testing is possible:
  - UART TX can be looped to UART RX (with jumper or test fixture)
  - Ethernet can be looped (with test fixture or PHY loopback mode)
  - CAN can be looped (with test fixture)
- [ ] Self-test firmware capability:
  - Memory test (RAM read/write verification)
  - Flash integrity check (CRC)
  - Sensor self-test (if sensors support it)
  - Communication loopback
  - LED test (all LEDs on)
  - Analog calibration

### 4. Subsystem Isolation

- [ ] Major subsystems can be **independently enabled/disabled**:
  - Enable pins accessible through jumpers, headers, or test points
  - Power rails can be individually controlled
  - Peripheral subsystems can be shut down to isolate failures
- [ ] **0Ω resistors or jumpers** at subsystem boundaries:
  - Can disconnect a subsystem without desoldering components
  - Located at power or signal boundaries between blocks
  - Documented purpose (isolation points clearly labeled in schematic)
- [ ] **Power supply can be externally supplied**:
  - Bypass internal regulators to power rails directly from bench supply
  - Current measurement points on power rails (series resistor or header)
  - Useful for power consumption measurement and power sequencing debug
- [ ] **Clock bypass capability**:
  - External clock injection point for processor/FPGA
  - Crystal circuit can be bypassed for testing at specific frequencies

### 5. Status Indicators

- [ ] **Power LEDs**:
  - At least one LED indicating main power is present
  - LEDs on other critical rails for quick visual verification
  - LED series resistor values calculated for appropriate brightness without excessive current
- [ ] **Status LEDs**:
  - Processor heartbeat LED (firmware-controlled, indicates processor is running)
  - Communication activity LEDs (Ethernet link/activity, CAN activity)
  - Error/fault indicator LED
- [ ] **Test points for automated reading**:
  - LED signals also available as test points for automated fixture reading
  - Logic-level status signals available without requiring LED interpretation

### 6. Environmental & Qualification Test Support

- [ ] **Temperature sensor** on the board (for thermal monitoring during environmental testing)
- [ ] **Current measurement provisions**:
  - Series resistors in power paths for current measurement via voltage drop
  - Or headers that can be opened for ammeter insertion
  - Kelvin sense connections for precision measurement
- [ ] **Voltage monitoring points** for all critical rails
- [ ] **EMC test provisions**:
  - Ground connection point for EMC test setup
  - Emission measurement access points
  - Immunity injection points

### 7. Field Diagnostics & Service

- [ ] **Diagnostic interface** present in netlist:
  - USB diagnostic port
  - Ethernet management port
  - Serial console port
  - Wireless diagnostic interface (if applicable)
- [ ] **Status reporting**:
  - Firmware can report hardware health status
  - Voltage rail monitoring and reporting
  - Temperature monitoring and reporting
  - Error log storage and retrieval
- [ ] **Firmware update mechanism**:
  - In-field firmware update possible (USB, Ethernet, wireless)
  - Recovery mechanism if firmware update fails (bootloader, failsafe image)
  - Firmware version readable through diagnostic interface
- [ ] **Hardware revision identification**:
  - Board revision readable by firmware (GPIO straps or resistor-coded divider on ADC input)
  - Allows firmware to adapt to hardware revisions
  - Prevents running wrong firmware version on wrong hardware revision
- [ ] **Modular design provisions** (if field-repairable):
  - Modular subsystems use connectors rather than soldered connections where possible
  - Diagnostic LEDs present for key status indication

### 8. Calibration Provisions

- [ ] **Calibration reference points**:
  - Precision reference voltage accessible for ADC calibration verification
  - Temperature sensor accessible for thermal calibration
  - Calibration data storage location defined (EEPROM, flash partition)
- [ ] **Trim/adjustment provisions**:
  - Digital potentiometers instead of manual trimpots (for automated calibration)
  - Or trimpots accessible after assembly for manual calibration
  - Calibration procedure documented or firmware-automated
- [ ] **Production calibration interface**:
  - Calibration equipment connection point (connector or test pad)
  - Calibration can be automated (firmware support for calibration mode)
  - Calibration data is non-volatile and survives firmware updates

---

## Common DFT Issues at Schematic Level

| Issue | Severity | Description |
|-------|----------|-------------|
| No JTAG/SWD debug access | Critical | Cannot debug firmware, cannot boundary-scan BGAs |
| No UART debug console | Major | Cannot observe boot process or debug firmware |
| No test points on power rails | Major | Cannot verify voltage regulation during production test |
| No way to isolate subsystems | Major | Cannot diagnose failures efficiently |
| No power LEDs | Minor | Cannot quickly verify power is present |
| Missing production programming header | Critical | Cannot program firmware during production |
| No hardware revision ID | Minor | Cannot track hardware/firmware compatibility |
| No field update mechanism | Major | Product cannot be updated after deployment |
| BGA without boundary scan chain | Major | Cannot verify BGA solder joints |
| No current measurement provision | Minor | Cannot measure power consumption without board modification |

## Severity Classification

- **Critical**: Board cannot be adequately tested or debugged — unacceptable for production.
- **Major**: Significant testability gap that will increase test time, reduce coverage, or impede debug.
- **Minor**: Test convenience issue — testing is possible but more difficult.
- **Info**: Enhancement for improved testability or diagnostic capability.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, subsystem, signal/component]
- **DFT Category**: [Test Points | Debug Access | Production Test | Isolation | Indicators | Diagnostics | Calibration]
- **Description**: [What testability provision is missing or inadequate]
- **Impact**: [How this affects testing, debug, or production]
- **Recommendation**: [What should be added or changed]
```
