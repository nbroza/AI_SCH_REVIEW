# Design for Test (DFT) Best Practices

## DFT Fundamentals (2024)

### What is Design for Test?

Design for Test (DFT) is a set of **design strategies and techniques used to make printed circuit boards (PCBs) and integrated circuits (ICs) easier to test during manufacturing**, with the primary goal of **identifying manufacturing defects early**.

### Key Objectives

**DFT Enables:**
- Defect detection during production
- Faster board bring-up and debug
- Field diagnostics and repair
- Compliance verification
- Quality assurance

**Economic Impact:**
Well-designed DFT provisions can significantly:
- Reduce test time and cost
- Improve first-pass yield
- Lower warranty returns
- Enable faster root cause analysis

## Boundary Scan and JTAG Technology

### Overview

**Boundary-scan** is a technique for testing interconnects on PCBs **without the need for physical test probes**, utilizing a standard test access port (TAP) and boundary-scan cells to control and monitor the state of each pin on a device.

**JTAG (Joint Test Action Group):**
Boundary scan is now mostly synonymous with **JTAG** (IEEE 1149.1 standard).

### Test Coverage

**Typical Coverage:**
- Typical designs achieve **50-80% boundary scan coverage** without specific optimization
- With careful component selection and DFT practices, **coverage above 90% is achievable** for digital sections of mixed-signal boards

**Critical Applications:**
Boundary scan tests interconnects that ICT (In-Circuit Test) can't reach—**particularly BGA connections and fine-pitch devices where probe access is impossible**.

## DFT Guidelines for PCB Design

### 1. Component Selection

**Best Practice:**
Select **IEEE 1149.1 compliant devices whenever possible**.

**Benefits:**
- Enables boundary scan testing
- Provides access to internal IC state
- Allows programming and debug via JTAG
- Future-proofs design for test

**Boundary-Scan Capable Devices:**
Most modern FPGAs, processors, and complex ICs include JTAG/boundary-scan support.

### 2. Test Access Port (TAP) Design

**TAP Signal Routing:**
Route the TAP signals (TCK, TMS, TDI, TDO, optional nTRST) **away from other active signals** to reduce noise and improve signal integrity.

**Clock Rate:**
The serial JTAG interface typically runs with a **clock rate of 10 MHz to 30 MHz**, so signal integrity is important but not as critical as multi-GHz signals.

**TAP Connection Topology:**
- **TCK, TMS, and (optional) nTRST** signals must be connected in **parallel** to all devices
- **TDI and TDO** signals are connected in a **'daisy chain' format** (TDO of one device connects to TDI of next)

**Example Daisy Chain:**
```
Test Controller → TDI[FPGA1] → TDO[FPGA1] → TDI[FPGA2] → TDO[FPGA2] → Test Controller
                  TCK/TMS (parallel to both)
```

### 3. Signal Integrity for JTAG

**Pull-Ups:**
- TMS should have a **pull-up resistor** — keeps device in Run-Test/Idle if TAP disconnected
- TDI and TDO may need pull-ups depending on daisy chain configuration
- nTRST should have pull-up or pull-down as specified in device datasheet

**Series Resistors (Optional):**
Series resistors (22-33Ω) on debug signals for protection and signal integrity.

**Connector:**
Debug connector should match debugger being used:
- ARM 10-pin Cortex Debug
- ARM 20-pin JTAG
- Tag-Connect (for production with limited board space)
- Custom connector per application

### 4. Test Point Provisioning

**Critical Nets Requiring Test Points:**
- All power rails (input and regulated outputs)
- Critical control signals (reset, enable, chip select)
- Communication interfaces (UART TX/RX, I2C SDA/SCL, SPI signals)
- High-speed clocks
- Analog signals (ADC inputs, voltage references)

**Test Point Component:**
Use dedicated test point components in the netlist, not just exposed vias or pads.

**Test Point Guidelines:**
- Standard test point pitch: 100 mil (2.54mm) or 50 mil (1.27mm) for ICT
- Clearance around test points for probe access
- Test points on top side of board for accessibility

### 5. Diagnostic Provisions

**Power Indicator LEDs:**
- At least one LED indicating main power is present
- LEDs on other critical rails for quick visual verification
- LED series resistor values calculated for appropriate brightness

**Status LEDs:**
- Processor heartbeat LED (firmware-controlled, indicates processor running)
- Communication activity LEDs (Ethernet link/activity, CAN activity)
- Error/fault indicator LED

**Debug Console (UART):**
- UART TX/RX available on header or test points
- Allows firmware debug output
- Console available during early boot (before complex peripherals initialize)

## Boundary Scan vs. In-Circuit Test (ICT)

### ICT (In-Circuit Test)

**Method:**
Physical bed-of-nails fixture contacts test points on PCB.

**Advantages:**
- Tests passive component values
- Measures capacitance, inductance, resistance
- Detects shorts, opens, incorrect values

**Disadvantages:**
- Requires custom test fixture (cost, lead time)
- Requires physical probe access to nets
- Cannot access BGA solder joints
- Fine-pitch components difficult to probe
- Fixture maintenance and wear

### Boundary Scan

**Method:**
Digital test through JTAG interface, no physical probing.

**Advantages:**
- **No custom fixture required** (lower cost)
- **Can test BGA interconnects** (critical capability)
- Can test fine-pitch devices
- Programmable test vectors
- Tests interconnects between ICs

**Disadvantages:**
- Only tests digital interconnects
- Cannot measure analog values
- Cannot test passive components
- Requires IEEE 1149.1 compliant devices

### Cost Comparison

Boundary-scan testing is **more cost-effective than standard PCB testing methods like in-circuit testing (ICT)**.

While both methods involve expenses for equipment and training, ICT also requires **additional costs of developing test fixtures and maintaining equipment**.

**Break-Even:**
For moderate to high production volumes, boundary scan typically has lower total cost.

## Production Test Strategy

### Layered Test Approach

**Recommended Strategy:**
Combine multiple test methods for comprehensive coverage:

1. **Visual Inspection**: Detect obvious assembly errors
2. **Automated Optical Inspection (AOI)**: Detect component presence, orientation, solder quality
3. **Boundary Scan**: Test digital interconnects, BGA solder joints
4. **In-Circuit Test (ICT)**: Test analog circuits, passive components (if fixture exists)
5. **Functional Test**: Verify end-to-end system operation
6. **X-Ray Inspection**: Verify BGA solder joints (sampling or 100%)

**Trade-Offs:**
- Higher test coverage = higher test cost
- Balance coverage vs. acceptable defect escape rate
- Consider field failure cost vs. test cost

### Test Point Allocation

**ICT Test Points:**
- Key nets have dedicated test pads
- Both sides of critical passive components accessible
- Power supply rails can be force-sensed through dedicated test points

**Functional Test Points:**
- Test connector for automated test equipment connection
- Stimulus inputs accessible (clock override, analog input drive)
- Observation outputs accessible (analog outputs, digital outputs, status indicators)

## Field Service and Diagnostics

### Remote Diagnostics

**Diagnostic Interface:**
Provide diagnostic interface in the design:
- USB diagnostic port
- Ethernet management port
- Serial console port (UART)
- Wireless diagnostic interface (if applicable)

**Status Reporting:**
Firmware should provide:
- Hardware health status reporting
- Voltage rail monitoring and reporting
- Temperature monitoring and reporting
- Error log storage and retrieval

### Firmware Update Capability

**In-Field Updates:**
- Firmware update mechanism (USB, Ethernet, wireless)
- Recovery mechanism if firmware update fails (bootloader, failsafe image)
- Firmware version readable through diagnostic interface

**Hardware Revision Identification:**
- Board revision readable by firmware (GPIO straps or resistor-coded divider on ADC input)
- Allows firmware to adapt to hardware revisions
- Prevents running wrong firmware version on wrong hardware

## Common DFT Issues

### Issue 1: No JTAG/SWD Debug Access
**Impact:** Cannot debug firmware, cannot boundary-scan BGAs
**Severity:** Critical
**Solution:** Add debug connector with JTAG/SWD signals

### Issue 2: No Test Points on Power Rails
**Impact:** Cannot verify voltage regulation during production test
**Severity:** Major
**Solution:** Add test point components on all power rails

### Issue 3: BGA Without Boundary Scan Chain
**Impact:** Cannot verify BGA solder joints
**Severity:** Major
**Solution:** Use JTAG-capable devices, add to boundary scan chain

### Issue 4: Missing Production Programming Header
**Impact:** Cannot program firmware during production
**Severity:** Critical
**Solution:** Add programming interface (JTAG, SWD, UART bootloader, SPI)

### Issue 5: No Hardware Revision ID
**Impact:** Cannot track hardware/firmware compatibility
**Severity:** Minor
**Solution:** Add GPIO straps or resistor divider for revision detection

## Sources

- [Design for Test (DFT) Guidelines for improving JTAG testability - XJTAG](https://www.xjtag.com/about-jtag/design-for-test-guidelines/)
- [Enhancing Board Test Coverage with Boundary-Scan | Keysight Blogs](https://www.keysight.com/blogs/en/tech/bench/2024/08/13/enhancingboardtestcoveragewithboundary-scan)
- [Design for Boundary Scan Test - JTAG DFT » Electronics Notes](https://www.electronics-notes.com/articles/test-methods/boundary-scan-jtag-ieee1149/design-for-testing-dft.php)
- [System DFT Guidelines – JTAG](https://www.jtag.com/document/system-dft-guidelines/)
- [Boundary Scan Testing (JTAG) in PCB Design: A Practical DFT Guide - PCBSync](https://pcbsync.com/boundary-scan-testing/)
- [Mastering DFT: A Comprehensive Guide to Design for Test](https://www.allpcb.com/allelectrohub/mastering-dft-a-comprehensive-guide-to-design-for-test)
