# ESD & Transient Protection Best Practices

## TVS Diode Selection Criteria

### Critical Protection Parameters

TVS diodes protect circuits from ESD by rapidly clamping voltage spikes, providing a low-impedance path to ground when a transient exceeds the diode's breakdown voltage. **Correct part selection is critical** for effective protection.

### Key Selection Parameters

#### 1. Reverse Bias Breakdown Voltage (VB)

**Definition:** The reverse bias voltage at which the TVS diode will start conducting and divert the ESD pulse away from the protected component.

**Selection Rule:**
VB must be **higher than the maximum normal operating voltage** of the signal being protected (including tolerances).

#### 2. Clamping Voltage (VC)

**Definition:** The maximum voltage across the TVS diode at a specified test current (typically 1A for ESD testing).

**Critical Requirement:**
**VC must be LESS than the input voltage limit (absolute maximum rating) of the protected component.**

**Example:**
- IC absolute maximum input voltage: 4.0V
- Required: VC < 4.0V at 1A test current
- If TVS VC = 6V, the TVS **does not actually protect** the IC

A lower VC value will provide more protection to a component.

#### 3. Rated Standoff Voltage (VWM or VRWM)

**Definition:** This indicates the reverse bias voltage limit below which the TVS diode will remain insulating, with high impedance and only a small amount of leakage current.

**Selection Rule:**
VWM must be **≥ maximum normal signal voltage** (including any positive/negative swing and tolerances).

#### 4. Leakage Current

**Definition:** Current through the TVS when voltage is below VWM.

**Importance:**
Must be acceptable for the signal. Especially important for:
- High-impedance analog inputs
- Precision measurement circuits
- Low-power circuits

**Typical Values:**
- Standard TVS: 1-10µA
- Low-leakage TVS: < 1µA

#### 5. Parasitic Capacitance

**Critical for High-Speed Signals:**
The parasitic capacitance of TVS diodes can affect high-speed signal integrity.

**Selection Guidelines:**
- **USB 3.0, HDMI 2.0, PCIe**: < 1pF per line (specialized low-capacitance TVS)
- **USB 2.0, Ethernet**: < 5pF
- **Low-speed signals** (I2C, UART, GPIO): Capacitance less critical (< 100pF acceptable)

**High-Speed Interface Recommendations:**
For high-speed interfaces such as USB 3.0, HDMI 2.0, PCIe, etc., specialized **low-capacitance TVS diodes (typically < 1pF)** should be selected to avoid degrading signal integrity.

### Diode Type Selection

#### Unidirectional TVS Diodes

**Use For:**
- Unipolar signal lines (always positive or always negative)
- DC power lines
- Signals referenced to ground

**Advantages:**
- Lower clamping voltage in one direction
- Better protection for known polarity signals

#### Bidirectional TVS Diodes

**Use For:**
- AC-coupled signals
- Differential pairs
- Signals that can swing both positive and negative

**Why Bidirectional:**
Bidirectional TVS diodes are preferred for comprehensive fault protection and ESD protection because **the ground region can receive ESD pulses, just like the signal lines you want to protect**.

**Rationale:**
ESD events can cause both positive and negative voltage transients. Bidirectional protection clamps both polarities.

## PCB Layout Guidelines for TVS Diodes

### Placement

**Critical Rule:**
The TVS diode should be located **as close to the connector as possible** to minimize the length of the trace between the connector and the TVS (L1 trace).

**Rationale:**
- Intercepts ESD before it reaches sensitive circuitry
- Minimizes inductance in ESD current path
- Reduces voltage overshoot during ESD event

### Trace Routing

**Minimize L2 and L3 Traces:**
Reduce the length of traces from the TVS to the protected IC (L2) and from the TVS to ground (L3).

**Do NOT use vias** in the L2 and L3 traces where possible. Vias add parasitic inductance.

**If vias are required:**
- Use multiple vias in parallel to reduce inductance
- Keep vias as close to TVS as possible
- Use short, wide traces

### Ground Connection

**Avoid Split Ground Planes:**
A split ground plane can force ESD current to find longer return paths and **raise the clamp voltage seen by the IC**, defeating the purpose of the TVS.

**Best Practice:**
- Provide low-impedance ground connection directly to TVS
- Use solid ground plane under TVS
- Connect TVS ground pin with multiple vias to ground plane

## Application-Specific TVS Selection

### USB Interfaces

**USB 2.0 (D+/D-):**
- Low capacitance: **< 2pF per line** (High-Speed)
- Clamping voltage: **< 3.6V** at 1A (for 3.3V I/O)
- Bidirectional protection
- TVS array packages available for both D+ and D-

**USB 3.x SuperSpeed (TX+/TX-, RX+/RX-):**
- Very low capacitance: **< 0.5pF per line**
- Maintains differential impedance (85-90Ω)
- Dedicated low-capacitance SuperSpeed TVS arrays

**VBUS (USB Power):**
- Unidirectional TVS rated for 5V
- Clamping voltage appropriate for downstream circuitry
- Higher power rating (> 100W for Type-C PD)

### Ethernet

**Primary Protection (Optional for Outdoor/Long Cables):**
- Gas discharge tube (GDT) or high-power TVS on transformer primary
- Handles high-energy lightning-induced surges

**Secondary Protection:**
- TVS array on PHY-side of magnetics
- Protects PHY from residual transients
- Typical clamping voltage: 6-8V for 3.3V PHY

**Inherent Protection:**
Magnetics (transformer) provides galvanic isolation and some inherent protection.

### CAN Bus

**CAN_H and CAN_L:**
- Bidirectional TVS on each line
- VRWM ≥ 5V (to accommodate CAN dominant/recessive states)
- Clamping voltage ≤ ±60V (verify against CAN transceiver absolute max)
- Common-mode protection on both lines

### RS-232 / RS-485 / Industrial I/O

**Higher Surge Capability:**
Field wiring requires protection against **IEC 61000-4-5 surge, not just ESD**.

**TVS Selection:**
- Rated for signal voltage range (±12V for RS-232, ±12V for RS-485 bus)
- Higher power rating for surge energy
- Consider MOV + TVS combination for high-energy environments

**Series Current-Limiting Resistors:**
For long-cable interfaces, add series resistors (10-100Ω) on signal lines to limit surge current into TVS.

### Analog Inputs (Sensors)

**Protection Methods:**
- TVS diodes on analog sensor inputs
- Back-to-back Schottky diodes (clamp to supply rails)

**Critical Considerations:**
- **Leakage current** of protection devices must not affect measurement accuracy
- **Clamping voltage** within ADC/amplifier absolute maximum
- **Capacitance** must not add excessive load or affect analog bandwidth

## ESD Testing Standards

### IEC 61000-4-2 (ESD Immunity)

**Test Levels:**
- Level 1: ±2kV contact, ±2kV air
- Level 2: ±4kV contact, ±4kV air
- Level 3: ±6kV contact, ±8kV air
- Level 4: ±8kV contact, ±15kV air (typical requirement for consumer/industrial products)

**Verification:**
TVS diodes must be rated to withstand the required test level.

### IEC 61000-4-5 (Surge Immunity)

**Test Waveforms:**
- 1.2/50µs voltage waveform (open-circuit)
- 8/20µs current waveform (short-circuit)

**Typical Test Levels:**
- Level 1: ±0.5kV line-to-line, ±1kV line-to-ground
- Level 2: ±1kV line-to-line, ±2kV line-to-ground
- Level 3: ±2kV line-to-line, ±4kV line-to-ground
- Level 4: ±4kV line-to-line, ±8kV line-to-ground

**For Surge Protection:**
Use high-power TVS, MOV, or GDT rated for surge energy.

## Multi-Stage Protection

For interfaces exposed to high-energy transients (outdoor cabling, field wiring, power lines):

### Stage 1: Primary Protection
- **MOV (Metal Oxide Varistor)** or **GDT (Gas Discharge Tube)**
- High energy handling capability
- Higher clamping voltage
- Slower response time

### Stage 2: Secondary Protection
- **TVS diode**
- Fast response time (< 1ns)
- Lower clamping voltage
- Protects sensitive electronics

### Decoupling Between Stages
- **Resistor** or **inductor** between stages
- Allows primary protector to clamp first
- Limits current into secondary protector

**Example:**
```
External Connector → GDT → 10Ω Resistor → TVS → Protected IC
```

## Common TVS Design Errors

### Error 1: VC > IC Absolute Maximum
**Symptom:** IC damaged despite TVS presence
**Cause:** TVS clamping voltage exceeds IC rating
**Solution:** Select TVS with lower VC

### Error 2: VWM < Signal Voltage
**Symptom:** TVS conducts during normal operation, signal distortion
**Cause:** Standoff voltage too low
**Solution:** Select TVS with higher VWM

### Error 3: Excessive Capacitance on High-Speed Signal
**Symptom:** Signal integrity degradation, eye diagram closure
**Cause:** Standard TVS has too much capacitance
**Solution:** Use low-capacitance TVS (< 1pF)

### Error 4: Wrong Polarity (Unidirectional on Bipolar Signal)
**Symptom:** Signal clipped, TVS conducts in normal operation
**Cause:** Unidirectional TVS used on AC-coupled or bipolar signal
**Solution:** Use bidirectional TVS

## Sources

- [PCB Design Guidelines for Using TVS Diode for Transient Protection | PCB Design Blog | Altium](https://resources.altium.com/p/pcb-design-guidelines-using-tvs-diode-transient-protection)
- [ESD Protection Basics with TVS Diodes | Phil's Lab | Altium](https://resources.altium.com/p/esd-protection-basics-tvs-diodes)
- [TVS diode selection and PCB design considerations - Semiware](https://en.semiware.com/blog/tvs-diode-selection-pcb-design.html)
- [ESD PROTECTION DESIGN GUIDE: TVS DIODE ARRAYS - Littelfuse](https://www.littelfuse.com/assetdocs/littelfuse-esd-and-port-protection-design-guide?assetguid=669a5b3c-80d9-4061-b269-aaae9b429959)
- [How do I choose an ESD protection diode? | Toshiba Electronic Devices & Storage Corporation](https://toshiba.semicon-storage.com/us/semiconductor/knowledge/faq/diode_tvs-diodes/how-do-i-choose-an-esd-protection-diode.html)
