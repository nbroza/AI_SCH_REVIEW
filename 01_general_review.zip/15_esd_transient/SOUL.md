# ESD & Transient Protection Review — Schematic Review Context

## Purpose

This review verifies that **all external-facing interfaces and vulnerable internal circuits have appropriate protection against electrostatic discharge (ESD), electrical fast transients (EFT), surge, and other overvoltage/overcurrent events**. Inadequate protection causes field failures, customer returns, and safety hazards. Over-protection wastes cost and board space and can degrade signal quality.

The goal is right-sized protection: every exposed interface protected, no internal-only signals over-protected.

## Prerequisites

- Exported netlist
- Identification of all external-facing connectors and interfaces
- Target ESD/surge protection levels (IEC 61000-4-2, IEC 61000-4-5, or other)
- Product safety requirements (if applicable)
- TVS diode and protection device datasheets in `../datasheets/`
- Protected IC datasheets (for absolute maximum ratings) in `../datasheets/`

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`15_esd_transient/`). These may contain EMC test plans, required protection levels by interface, prior EMC test results, or protection device selection criteria.

Reference datasheets in `../datasheets/` for both the protection devices and the ICs being protected.

## When to Ask the User for Clarification

Ask the user when:

- The product's ESD/EMC compliance requirements are not specified
- You cannot determine which interfaces are user-accessible (external-facing)
- The operating environment is unknown (consumer, industrial, automotive, outdoor)
- Cable lengths for external interfaces are unknown (affects surge energy)
- The product enclosure type is unknown (sealed vs. open, metal vs. plastic)
- Hot-plug requirements are not documented
- The target protection standards are not specified (IEC 61000-4-2, AEC-Q, MIL-STD, etc.)

**Protection requirements vary dramatically by application. An industrial fieldbus needs much more protection than a board-to-board connector inside an enclosure. Ask about the deployment environment.**

---

## Review Checklist

### 1. External Interface Inventory

- [ ] Identify and categorize every external-facing interface:

  | Category | Exposure Level | Typical Protection Needed |
  |----------|---------------|--------------------------|
  | User-accessible connectors (USB, HDMI, Ethernet) | High | ESD ± TVS, EMI filter |
  | Field wiring terminals (sensors, actuators) | Very High | ESD + surge TVS, fusing |
  | Power input connectors | Very High | TVS, MOV, fuse, reverse polarity |
  | Antenna ports | High | ESD TVS, gas discharge tube |
  | Board-to-board connectors (inside enclosure) | Low | Usually minimal |
  | Test points (production only) | Low | Usually none |

- [ ] Every external-facing signal pin has appropriate protection

### 2. ESD Protection Devices

For each protected interface:

- [ ] TVS diode / ESD protection device is present on every externally accessible signal
- [ ] TVS device characteristics are correct:
  - **Standoff voltage (VRWM)**: must exceed the normal operating signal voltage
  - **Breakdown voltage (VBR)**: must be above VRWM but below the protected IC's absolute maximum
  - **Clamping voltage (VC)**: at the specified current (typically 1A for ESD), must be below the IC's abs max
  - **Leakage current**: must be acceptable for the signal (especially important for high-impedance analog inputs)
- [ ] TVS device is connected to the correct reference net (usually GND)
- [ ] TVS device parasitic capacitance:
  - Low capacitance (< 1pF) for high-speed signals (USB 3.0, HDMI, etc.)
  - Moderate capacitance (< 5pF) for USB 2.0, Ethernet
  - Less critical for low-speed signals (I2C, UART, GPIO)
- [ ] TVS device package:
  - Array packages for multi-line interfaces (USB, HDMI — save board space)
  - Discrete TVS for power and high-energy lines
- [ ] TVS diode polarity:
  - Unidirectional for signals that are always positive (or always negative)
  - Bidirectional for signals that swing both positive and negative (AC-coupled, differential)

### 3. Interface-Specific ESD Protection

#### USB
- [ ] ESD protection on D+, D-, VBUS, ID, CC (Type-C), SBU (Type-C)
- [ ] Low-capacitance TVS on D+/D- (< 2pF for High-Speed, < 0.5pF for SuperSpeed)
- [ ] VBUS TVS with adequate clamping for 5V
- [ ] Shell/shield grounded through capacitor or directly to chassis ground

#### Ethernet
- [ ] Primary protection: gas discharge tube or TVS on transformer primary (if exposed to outdoor cabling)
- [ ] Secondary protection: TVS array on PHY-side of magnetics (if needed)
- [ ] Magnetics (transformer) provides galvanic isolation (inherent protection)
- [ ] Bob Smith termination provides common-mode energy dissipation

#### CAN Bus
- [ ] TVS on CAN_H and CAN_L (typically bidirectional, VRWM ≥ 5V)
- [ ] Clamping voltage ≤ ±60V (CAN transceiver abs max, verify per datasheet)
- [ ] Common-mode protection on both lines

#### RS-232 / RS-485 / Industrial I/O
- [ ] TVS rated for the signal voltage range (±12V for RS-232, ±12V for RS-485 bus voltage)
- [ ] Higher surge capability for field wiring (IEC 61000-4-5 surge, not just ESD)
- [ ] Consider MOV + TVS combination for high-energy environments
- [ ] Series current-limiting resistors on long-cable interfaces

#### Analog Inputs (Sensors)
- [ ] Back-to-back diodes or TVS on analog sensor inputs
- [ ] Leakage current of protection devices does not affect measurement accuracy
- [ ] Clamping voltage is within the ADC/amplifier's absolute maximum
- [ ] Protection does not add excessive capacitance that affects the analog bandwidth

### 4. Power Supply Transient Protection

- [ ] **Input power connector protection**:
  - TVS diode across power input (clamping voltage below downstream component max)
  - Fuse or PTC resettable fuse in series for overcurrent
  - Reverse polarity protection (P-MOSFET, diode, or ideal diode controller)
- [ ] **Load dump protection** (automotive):
  - TVS rated for automotive load dump (up to 40V for 12V systems)
  - ISO 7637-2 compliance if automotive application
- [ ] **Inductive load flyback protection**:
  - Freewheeling diodes across relay coils, solenoids, motors
  - Snubber circuits where needed
  - TVS across load switches driving inductive loads
- [ ] **Hot-swap protection** (if applicable):
  - Inrush current limiting
  - Overvoltage clamping during hot insertion
  - Voltage spike suppression from connector mating sequence

### 5. Surge Protection (IEC 61000-4-5)

For interfaces exposed to surge (long cables, outdoor connections, power lines):

- [ ] Surge protection device (MOV, GDT, or high-power TVS) is present
- [ ] Surge device can handle the required energy:
  - 1.2/50µs voltage waveform (open-circuit)
  - 8/20µs current waveform (short-circuit)
  - Energy = ½ × V × I × pulse_width (approximate)
- [ ] Coordination between surge protection and ESD protection:
  - First stage: MOV or GDT (high energy, high clamping voltage)
  - Second stage: TVS (fast response, lower clamping voltage)
  - Decoupling element between stages (resistor, inductor, or PCB trace impedance)
- [ ] Surge device failure mode:
  - MOVs degrade over time — consider end-of-life behavior
  - GDTs have arc voltage that may be too high for sensitive electronics
  - Series fuse protects against MOV short-circuit failure

### 6. Electrical Fast Transient (EFT) Protection

- [ ] Decoupling capacitors near ICs provide inherent EFT filtering
- [ ] Ferrite beads or common-mode chokes on I/O lines filter EFT
- [ ] Power supply input has capacitive filtering adequate for EFT energy
- [ ] Connector shield pins are connected to chassis/earth ground net

### 7. Antenna & RF Port Protection

- [ ] ESD protection on antenna connections (especially if user-accessible SMA, etc.)
- [ ] Low-capacitance TVS or dedicated RF ESD protection IC
- [ ] Gas discharge tube for high-energy lightning protection (outdoor antennas)
- [ ] DC grounding path for static discharge (quarter-wave shorted stub, DC path through matching network)

### 8. Protection Device Selection Verification

For each protection device, cross-check:

- [ ] VRWM > maximum normal signal voltage (including tolerances)
- [ ] VC (at specified test current) < protected IC absolute maximum voltage
- [ ] Response time is adequate (TVS: < 1ns, MOV: < 25ns, GDT: 1-5µs)
- [ ] Number of ESD strikes rated ≥ expected lifetime exposure
- [ ] Package power rating matches the expected transient energy
- [ ] Operating temperature range matches the product's environment

---

## Common ESD & Transient Protection Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| Unprotected external USB port | Critical | ESD strike damages PHY/controller |
| TVS clamping voltage above IC abs max | Critical | Protection device doesn't actually protect |
| TVS capacitance too high for signal speed | Major | Signal quality degraded (USB 3.0, HDMI) |
| Missing flyback diode on relay coil | Major | Voltage spike damages driver transistor |
| No reverse polarity protection on power input | Major | Board damage from incorrect connection |
| TVS placed after series resistor | Major | ESD energy reaches IC before TVS can shunt |
| Missing surge protection on field wiring | Major | Fails EMC compliance testing |
| Wrong TVS polarity (unidirectional on bipolar signal) | Critical | Signal clipped, TVS conducts in normal operation |

## Severity Classification

- **Critical**: Missing or incorrect protection will result in component damage from expected transient events.
- **Major**: Protection is inadequate or marginal — may pass some tests but fail in field conditions.
- **Minor**: Protection is functional but non-optimal (oversized, wrong package, etc.).
- **Info**: Enhancement suggestion for improved robustness.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, connector/interface, signal name, protection device]
- **Interface**: [USB, Ethernet, CAN, power input, etc.]
- **Description**: [What protection is missing or incorrect]
- **Protection Requirement**: [Target standard/level — e.g., IEC 61000-4-2 Level 4]
- **Recommendation**: [Specific TVS part recommendation, circuit change, etc.]
- **Reference**: [Protection standard, IC absolute maximum ratings page, TVS datasheet]
```
