# EMC/EMI Best Practices

## Fundamental EMC/EMI PCB Design Principles (2024)

### Core Design Guidelines

PCB design guidelines for EMI and EMC start with:
- **Solid reference planes**
- **Minimal loop areas**
- **Effective filtering near noise sources**

**Key Principles:**
- Never route signals over split reference planes
- Always consider the return current path
- Use low-inductance capacitors and planes for decoupling

### High-Speed Signal Management

**Best Practices:**
- **Keep signal traces short**
- **Use differential signaling** for high-speed data connections to reduce common-mode EMI

Differential signaling provides:
- Common-mode noise rejection
- Lower EMI emissions
- Better signal integrity

## Regulatory Standards

### Common EMC Standards

**FCC Part 15**: Unintentional radiators (USA)
**CISPR 11**: Industrial, scientific, and medical equipment
**CISPR 32**: Multimedia equipment (replaces CISPR 22)
**MIL-STD-461**: Military equipment EMC requirements

### Testing Categories

**Radiated Emissions Testing:**
- Measures electromagnetic waves emitted by the PCB
- Frequency range: **30 MHz – 6 GHz**
- Standards: CISPR 32, FCC Part 15

**Conducted Emissions Testing:**
- Evaluates noise conducted through power lines
- Frequency range: **150 kHz – 30 MHz**
- Standards: CISPR 11, FCC Part 15

## Grounding and Bonding

### Critical Grounding Practices

**Proper grounding and bonding** of components and subsystems are essential for EMC.

**Implementation:**
- Use **low-impedance connections**
- **Minimize ground loops**
- Maintain a **clean, low-resistance ground plane**

### Ground Plane Design

**Multi-Layer PCB Requirement:**
In multi-layer PCB designs with closely spaced GND and power planes (**< 0.25 mm, < 10 mils**), the decoupling capacitor location is not as critical because the closely spaced planes act as an efficient decoupling capacitor for high-frequencies (> 1 MHz).

**High-Speed Signal Layers:**
Place critical high-speed signal layers **adjacent to the ground plane** to facilitate a good return path.

## Decoupling and Filtering

### Bypass Capacitor Placement

**Closely Spaced Planes (< 10 mils):**
Capacitor placement less critical; planes provide distributed capacitance.

**Standard Spacing:**
Place bypass capacitors as close as possible to IC power pins to minimize loop inductance.

### Input EMI Filtering

**Power Input Filtering:**
- Common-mode choke on power input
- Differential-mode filtering (X capacitors)
- Common-mode filtering (Y capacitors to ground)
- Pi filter topology (C-L-C) for switching power supply inputs

### Signal Line Filtering

**External Interfaces:**
- Common-mode chokes on differential signal pairs (USB, Ethernet, CAN, HDMI)
- Ferrite beads on single-ended signal lines
- Feed-through capacitors on power lines entering/exiting enclosure

## Clock Management for EMC

### Spread-Spectrum Clocking (SSC)

**Purpose:**
Spread-spectrum clocking **reduces EMI** by dithering the clock frequency over a small range, spreading narrowband energy across a wider spectrum.

**Typical Modulation:**
±0.5% to ±1% frequency deviation

**Supported Interfaces:**
- **USB**: SSC supported (±0.5%)
- **PCIe**: SSC supported (-0.5% down-spreading)
- **SATA**: SSC supported
- **Processor clocks**: SSC reduces EMI but check compatibility with peripherals

**Compatibility Note:**
Verify that downstream devices tolerate SSC, as some high-precision ADCs or timing-critical peripherals may not.

### Clock Frequency Selection

**Avoid Harmonics in Sensitive Bands:**
- AM broadcast band (540kHz-1.6MHz)
- FM broadcast band (88-108MHz)
- GPS L1 band (1575.42MHz)
- Cellular bands
- Wi-Fi bands (2.4GHz, 5GHz)

### Unused Clock Outputs

**Best Practice:**
**Disable or terminate unused clock outputs** on clock generators/buffers. Unused outputs radiate EMI unnecessarily.

### Clock Drive Strength

Set clock buffer drive strength to **minimum acceptable level** to reduce edge rates and harmonic content.

## Cable and Connector EMI Management

### Common-Mode Chokes

**Requirement:**
Common-mode chokes **must be present** on differential signal pairs that leave the enclosure:
- USB (D+/D-)
- Ethernet (TX+/TX-, RX+/RX-)
- CAN (CAN_H/CAN_L)
- HDMI (TMDS pairs)

**Specifications:**
- Impedance at frequency of interest documented
- Rated for DC current of interface
- Does not attenuate signal of interest

### Connector Shell Grounding

**Critical Connection:**
Connector shield pins and metal shells must be connected to **chassis ground net**, not signal ground.

**Purpose:**
- Provides low-impedance return path for common-mode currents
- Shields cable from external EMI
- Prevents cable from acting as radiating antenna

**Implementation:**
- Sufficient ground pins on connectors to serve as return current paths
- Short, wide traces or direct connection to chassis ground

## I/O Design for EMC

### Slew Rate Control

**Best Practice:**
I/O pins with configurable slew rate should be set to **slowest acceptable setting**.

**Benefits:**
- Reduces high-frequency harmonic content
- Lower EMI emissions
- Especially important on external-facing interfaces

### Drive Strength

Set output drive strength to **minimum that meets timing requirements**.

**Rationale:**
- Lower drive strength = slower edge rates
- Slower edges = reduced harmonic content and EMI

### Series Damping Resistors

**Application:**
Series resistors (22Ω-100Ω) on outputs driving connectors or long traces.

**Benefits:**
- Reduces ringing and overshoot
- Lowers high-frequency harmonic energy
- Improves signal integrity and reduces EMI

### Input Filtering

**External Signal Inputs:**
- Filter capacitors to shunt high-frequency noise to ground
- Selected to not attenuate the signal of interest
- Ferrite beads + capacitor for broadband filtering

**Slow-Transitioning Signals:**
Use **Schmitt trigger inputs** on slow-transitioning external signals to prevent oscillation and reduce noise susceptibility.

## Switching Regulator EMI Mitigation

### Frequency Selection

**Avoid Sensitive Bands:**
- AM radio: 540kHz-1.6MHz
- FM radio: 88-108MHz

**Frequency Dithering:**
Enable spread-spectrum mode if available to reduce narrowband emissions.

### Input/Output Filtering

**Input Capacitors:**
Use low-ESR, low-ESL capacitors close to switcher input.

**Snubber Circuits:**
Add RC snubber on switching node if ringing observed.

**Shielded Inductors:**
Use shielded inductors to reduce magnetic field radiation.

## EMC Testing and Compliance

### Pre-Compliance Testing

**In-House Testing:**
Regularly conduct EMC compliance testing to ensure your PCB design meets industry standards.

**Pre-Compliance Benefits:**
- Identify problems before formal testing
- Reduce risk of failure
- Example: Using a spectrum analyzer to measure emissions from a prototype can identify frequencies (e.g., 120 MHz harmonics) that exceed limits

### Formal Compliance Testing

**Test Sequence:**
1. Conducted emissions (150kHz-30MHz)
2. Radiated emissions (30MHz-6GHz)
3. ESD immunity (IEC 61000-4-2)
4. Radiated immunity (IEC 61000-4-3)
5. EFT/Burst immunity (IEC 61000-4-4)
6. Surge immunity (IEC 61000-4-5)

**Test Margin:**
Design for **6 dB margin** below limits to account for unit-to-unit variation.

## Common EMC Issues and Solutions

### Issue 1: Narrowband Emission at Clock Frequency
**Cause:** Clock signal radiating directly or via cable
**Solution:** Enable spread-spectrum clocking, add series resistor to slow edge rate, filter clock output

### Issue 2: Conducted Emissions on Power Input
**Cause:** Switching regulator noise coupling to input power
**Solution:** Add input EMI filter (common-mode choke + X and Y capacitors)

### Issue 3: Cable Radiation
**Cause:** Common-mode current on external cable
**Solution:** Add common-mode choke on cable signals, connect connector shell to chassis ground

### Issue 4: ESD Failures
**Cause:** Inadequate ESD protection on external interfaces
**Solution:** Add TVS diodes close to connectors, improve grounding

### Issue 5: Radiated Emissions from PCB
**Cause:** High-speed signals on outer layers, poor return paths
**Solution:** Route high-speed signals on inner layers adjacent to ground plane, maintain solid reference planes

## Sources

- [7 PCB Design Guidelines for EMI and EMC | Sierra Circuits](https://www.protoexpress.com/blog/7-pcb-design-tips-solve-emi-emc-issues/)
- [EMC Design Guidelines | Academy of EMC](https://www.academyofemc.com/emc-design-guidelines)
- [PCB Layout Design for EMI/EMC Compliance: Best Practices](https://www.allpcb.com/allelectrohub/pcb-layout-design-for-emiemc-compliance-best-practices)
- [PCB Design Guidelines for EMI Reduction and EMC Optimization | Cadence](https://resources.pcb.cadence.com/blog/2024-pcb-design-guidelines-for-emi)
- [EMI/EMC Testing: Ensuring Compliance in PCB Designs](https://www.allpcb.com/blog/pcb-design/emi-or-emc-testing.html)
- [EMI and EMC Compliance 101 for PCB Designers | Altium](https://resources.altium.com/p/emi-and-emc-compliance-101-pcb-designers)
