# EMC Review — Schematic Review Context

## Purpose

This review evaluates the **electromagnetic compatibility (EMC) provisions at the schematic level** — identifying potential sources of radiated and conducted emissions, evaluating susceptibility to external interference, and verifying that the schematic includes the necessary filtering, shielding, and grounding provisions to pass EMC compliance testing.

While EMC performance is heavily layout-dependent, the schematic must provide the components and topology that enable good EMC performance. Missing filter components or incorrect grounding at the schematic level cannot be compensated for in layout.

## Prerequisites

- Exported netlist
- Target EMC standards (FCC Part 15, CISPR 32, EN 55032, automotive EMC, etc.)
- Clock and switching frequencies used in the design
- List of all external cables and connectors
- PCB stackup information (if available)
- Enclosure type (metal, plastic, none)

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`16_emc/`). These may contain EMC test plans, prior EMC test results, known emission sources, corporate EMC design guidelines, or EMC filter selection criteria.

Reference datasheets in `../datasheets/` for filter components, common-mode chokes, ferrite beads, and shielded connectors.

## When to Ask the User for Clarification

Ask the user when:

- Target EMC standards and class (Class A vs Class B) are not specified
- The enclosure type and material are unknown (critical for shielding)
- Cable types and lengths for external connections are unknown
- Switching frequencies of power supplies are not specified
- The product operates near sensitive equipment (medical, avionics) with stricter limits
- Spread-spectrum clocking capability is available but usage is undetermined
- The board will be tested as a standalone unit or as part of a larger system

**EMC requirements and strategies differ dramatically between a desktop computer (FCC Class B) and an automotive ECU (CISPR 25). Ask about the target standard.**

---

## Review Checklist

### 1. Emission Source Identification

Identify and evaluate all potential emission sources:

- [ ] **Switching power supplies**:
  - Switching frequency and harmonics documented
  - High di/dt loops identified (input loop, output loop, bootstrap)
  - Snubber circuits present where needed to reduce ringing
  - Input EMI filter present (or identified as needed)

- [ ] **High-speed clocks**:
  - All clock frequencies listed
  - Harmonic content identified (square wave harmonics extend to ~10× fundamental)
  - Spread-spectrum clocking (SSC) used where possible
  - Unnecessary clock outputs disabled or terminated

- [ ] **High-speed data interfaces**:
  - USB, Ethernet, HDMI, PCIe — all generate broadband emissions
  - Common-mode chokes present on external-facing differential pairs
  - Cable shield connections defined

- [ ] **Processor/FPGA**:
  - High core clock frequency is a major emission source
  - Adequate decoupling (see Power Integrity review)
  - I/O drive strength set to minimum acceptable level (reduces edge rate and emissions)

- [ ] **Display interfaces**:
  - LCD ribbon cables, LVDS, parallel RGB — significant emission antennas
  - EMI filtering on display connectors
  - Ground returns adequate for display data signals

- [ ] **Motors, relays, and electromechanical devices**:
  - Suppression across contacts (RC snubber, varistor)
  - Flyback diodes on coils
  - Filtered power supply to motor drivers

### 2. Power Supply EMI Filtering

#### Input EMI Filter (AC/DC or DC/DC input)
- [ ] Common-mode choke present on power input
- [ ] Differential-mode filtering (X capacitors) present
- [ ] Common-mode filtering (Y capacitors) present
- [ ] Filter topology is appropriate for the noise spectrum:
  - Pi filter (C-L-C) for switching power supply inputs
  - LC filter for DC input with switching downstream
- [ ] Filter component ratings:
  - Current rating of common-mode choke ≥ maximum input current
  - Voltage rating of X and Y capacitors ≥ maximum input voltage
  - Y capacitor value ≤ safety leakage current limit (if AC/DC)
  - X and Y capacitors are safety-rated (X2/Y2 or X1/Y1 class)
- [ ] Filter location is at the power entry point (before any branching)

#### Switching Regulator EMI Provisions
- [ ] Input capacitors are low-ESR, low-ESL types
- [ ] Boot capacitor is present and correctly valued
- [ ] Snubber on switching node (if ringing observed or expected)
- [ ] Switching frequency is outside sensitive bands (AM radio: 540kHz-1.6MHz, FM: 88-108MHz)
- [ ] Frequency dithering or spread-spectrum mode enabled (if available)
- [ ] Shield or shielded inductor used for switching regulator

### 3. Cable & Connector Filtering

For every cable that leaves the enclosure:

- [ ] **Common-mode choke** present on differential signal pairs (USB, Ethernet, CAN, HDMI)
  - Impedance at the frequency of interest documented
  - Rated for the DC current of the interface
  - Does not attenuate the signal of interest
- [ ] **Ferrite beads** on single-ended signal lines (if needed)
  - Impedance at 100MHz specified and appropriate
  - Rated for the DC current
  - Does not cause excessive signal attenuation
- [ ] **Feed-through capacitors or filters** on power lines entering/exiting enclosure
- [ ] **Shield termination**:
  - Connector shield pins are connected to chassis ground net
- [ ] **Connector shell grounding**:
  - Connector shell/ground pins are connected to chassis ground net
  - Sufficient ground pins on connectors to serve as return current paths

### 4. Ground and Return Path Management

- [ ] Chassis ground net exists and is connected to appropriate connector pins
- [ ] Connectors have sufficient ground pins adjacent to high-speed signal pins
- [ ] Cable shield ground is separate from signal ground where needed

### 5. Clock Management for EMC

- [ ] **Spread-spectrum clocking (SSC)** enabled on all interfaces that support it:
  - USB: SSC supported by specification (±0.5%)
  - PCIe: SSC supported (-0.5% down-spreading)
  - SATA: SSC supported
  - Processor clock: SSC reduces EMI but check compatibility with sensitive peripherals
- [ ] **Clock frequency selection** avoids harmonics in sensitive bands:
  - AM broadcast band (540kHz-1.6MHz)
  - FM broadcast band (88-108MHz)
  - GPS L1 band (1575.42MHz)
  - Cellular bands
  - Wi-Fi bands (2.4GHz, 5GHz)
- [ ] **Unused clock outputs** on clock generators/buffers are disabled or terminated
- [ ] **Clock buffer drive strength** is set to minimum acceptable level

### 6. I/O Design for EMC

- [ ] **Slew rate control**: I/O pins with configurable slew rate set to slowest acceptable setting
  - Reduces high-frequency harmonic content
  - Especially important on external-facing interfaces
- [ ] **Drive strength**: set to minimum that meets timing requirements
- [ ] **Series damping resistors**: present on outputs driving connectors or long traces
  - Reduces ringing and overshoot
  - Typical values: 22Ω-100Ω
- [ ] **Filter capacitors**: present on inputs from external sources
  - Shunts high-frequency noise to ground
  - Selected to not attenuate the signal of interest
- [ ] **Schmitt trigger inputs** used on slow-transitioning external signals to prevent oscillation

### 7. Susceptibility (Immunity) Provisions

- [ ] **Decoupling** is adequate to maintain IC operation during conducted disturbances
- [ ] **Reset circuits** are immune to transients:
  - RC filter on reset input prevents noise-induced resets
  - Supervisor IC provides clean reset threshold with hysteresis
- [ ] **Watchdog timer** provides recovery from transient-induced firmware crashes
- [ ] **Input filtering** on all external signal inputs prevents RF rectification:
  - Low-pass filter on analog inputs (ferrite + cap)
  - Bypass capacitor on digital inputs
- [ ] **Power supply hold-up** capacitance provides ride-through during brief power transients
- [ ] **Firmware provisions** noted:
  - CRC on stored data
  - Error detection on communication interfaces
  - State machine recovery mechanisms
  - (These are firmware items but should be noted as schematic/design requirements)

### 8. Regulatory-Specific Checks

#### FCC Part 15 / CISPR 32 (IT Equipment)
- [ ] Class A vs Class B identified (Class B is stricter — consumer products)
- [ ] Unintentional radiator provisions adequate
- [ ] Intentional radiator (wireless) compliance noted separately

#### Automotive (CISPR 25 / ISO 11452)
- [ ] Input power line filtering meets automotive conducted emission limits
- [ ] Bulk Line Impedance Stabilization Network (LISN) compatible filter design
- [ ] Component-level emission limits from antenna to receivers considered

#### Medical (IEC 60601-1-2)
- [ ] Enhanced immunity requirements met (3V/m minimum, often 10V/m for life-support)
- [ ] Conducted emissions limits (stricter than CISPR 32)
- [ ] Special considerations for patient-connected circuits

---

## Common EMC Issues at Schematic Level

| Issue | Severity | Description |
|-------|----------|-------------|
| No common-mode choke on USB cable | Major | Fails conducted/radiated emissions at USB harmonics |
| Missing input EMI filter on SMPS | Critical | Conducted emissions exceed limits |
| No spread-spectrum on main clock | Major | Narrowband emission peaks at harmonics |
| Cable shield not connected to chassis | Major | Cable acts as antenna |
| Unfiltered I/O on external connector | Major | Susceptibility failures, emission path |
| No ferrite/filter on power input | Major | Conducted emissions from switching regulators |
| Motor/relay without suppression | Major | Broadband transient emissions |
| Maximum drive strength on all I/Os | Minor | Unnecessarily fast edges increase emissions |

## Severity Classification

- **Critical**: Missing EMC provision will almost certainly cause compliance failure.
- **Major**: Provision is inadequate — likely to cause marginal or failing EMC performance.
- **Minor**: Non-optimal but may still pass with good layout practices.
- **Info**: Optimization that would improve EMC margin.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, interface/component, signal/connector]
- **EMC Category**: [Conducted Emissions | Radiated Emissions | ESD Immunity | Surge Immunity | EFT Immunity | Radiated Immunity | Conducted Immunity]
- **Description**: [What the EMC concern is]
- **Frequency/Band**: [Affected frequency range if known]
- **Recommendation**: [Filter, choke, layout guidance, etc.]
- **Reference**: [EMC standard section, application note, prior test data]
```
