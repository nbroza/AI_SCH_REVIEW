# Connector & Interface Protocol Compliance Review — Schematic Review Context

## Purpose

This review verifies that **every external and internal interface in the design is implemented in compliance with its governing specification** — USB, Ethernet, HDMI, CAN, I2C, SPI, UART, RS-232, RS-485, and other standard protocols. Each protocol has specific requirements for termination, bias resistors, ESD protection, impedance, and passive components that must be correct for reliable operation and interoperability.

Non-compliant interfaces may work on the bench but fail in the field with different cable lengths, connectors, or third-party devices.

## Prerequisites

- Exported netlist
- List of all external and internal interfaces with protocol and speed specifications
- Protocol specifications (USB, Ethernet, CAN, etc.) — or rely on common knowledge of specifications
- PHY/transceiver datasheets in `../datasheets/`
- Connector datasheets in `../datasheets/`
- Cable specifications (if applicable)

## Context Ingestion

**IMPORTANT:** Before beginning this review, ingest all other files present in this folder (`14_connector_interface/`). These may contain interface-specific compliance checklists, connector pinout drawings, cable assembly specifications, or protocol-specific design guidelines used by the organization.

Reference datasheets in `../datasheets/` for PHY, transceiver, and connector specifications.

## When to Ask the User for Clarification

Ask the user when:

- The protocol version or speed class for an interface is not specified (USB 2.0 vs 3.0, etc.)
- Cable length requirements are unknown (affects termination and signal integrity)
- Interoperability requirements are not specified (must work with specific third-party equipment)
- Certification or compliance testing is planned (USB-IF, HDMI LLC, etc.)
- The connector manufacturer/part number is not specified
- Hot-plug requirements are not documented
- The intended use of a multi-purpose connector is ambiguous

**Protocol compliance requirements differ by version and speed. Ask about the specific version.**

---

## Review Checklist

### 1. USB (Universal Serial Bus)

#### USB 2.0 (Full-Speed / High-Speed)
- [ ] D+ and D- signals are connected correctly (not swapped)
- [ ] Series resistors on D+/D- (if required by the PHY — typically 22Ω-33Ω)
- [ ] Pull-up resistor on D+ (Full-Speed device) or D- (Low-Speed device):
  - 1.5kΩ to 3.3V (or PHY-controlled internal pull-up)
- [ ] VBUS power:
  - Host/Hub: provides 5V, with current limiting (500mA for USB 2.0, 900mA for USB 3.0)
  - Device: VBUS monitoring for attach detection
  - OTG: VBUS switch for dual-role operation
- [ ] ESD protection on D+, D-, VBUS, ID (if USB OTG):
  - Low capacitance: < 2pF per line (High-Speed)
  - TVS diodes rated for USB signal levels
- [ ] USB connector shield/shell connected to chassis ground (not signal ground directly)
- [ ] Decoupling capacitor on VBUS near connector

#### USB 3.x (SuperSpeed)
- [ ] TX+/TX- and RX+/RX- SuperSpeed pairs connected correctly
- [ ] AC coupling capacitors on SuperSpeed TX pairs (typically 100nF)
- [ ] USB 2.0 D+/D- still present and correctly connected (backwards compatibility)
- [ ] USB 3.0 connector pinout verified (Type-A, Type-B, Type-C)

#### USB Type-C
- [ ] CC1 and CC2 pins properly managed:
  - DFP (host): Rp pull-ups (56kΩ for default, 22kΩ for 1.5A, 10kΩ for 3.0A) to VBUS or controlled current source
  - UFP (device): Rd pull-downs (5.1kΩ to GND) on CC1 and CC2
  - DRP: appropriate control circuit for role detection
- [ ] VBUS management for Type-C current levels
- [ ] USB Power Delivery (if used): PD controller present with correct connections
- [ ] Orientation detection handled (CC pin determines orientation)
- [ ] SuperSpeed muxing handled for reversible connector (lane swapping)
- [ ] SBU1/SBU2 (Sideband Use) pins handled correctly

### 2. Ethernet

#### 10/100BASE-TX
- [ ] TX+/TX- and RX+/RX- differential pairs connected correctly
- [ ] Magnetic (transformer) module present:
  - Correct turns ratio (typically 1:1)
  - Center tap connections per PHY datasheet
  - Bob Smith termination (75Ω to chassis ground via capacitor) or as PHY recommends
- [ ] Termination resistors per PHY datasheet recommendation
- [ ] ESD protection rated for Ethernet (typically higher energy than data interfaces)
- [ ] RJ45 connector pinout matches T568A or T568B standard (document which)
- [ ] LED indicators (LINK, ACTIVITY) connected per PHY datasheet
- [ ] 25MHz or 50MHz crystal/oscillator for PHY (verify frequency and accuracy ±50ppm)
- [ ] PHY configuration straps (address, speed, mode) properly set

#### Gigabit Ethernet (1000BASE-T)
- [ ] All four differential pairs connected (bidirectional on all pairs)
- [ ] Magnetics rated for 1000BASE-T (higher bandwidth than 10/100)
- [ ] PHY supports auto-negotiation and MDI/MDI-X (auto crossover)

#### PoE (Power over Ethernet) — if applicable
- [ ] PD (Powered Device) controller present with correct signatures
- [ ] Isolation requirements met between PoE power and signal ground
- [ ] Current limiting and classification implemented

### 3. CAN (Controller Area Network)

- [ ] CAN_H and CAN_L connected correctly to CAN transceiver
- [ ] 120Ω termination resistor:
  - Present if this node is at the end of the bus
  - Omitted if this is a mid-bus node
  - Consider making termination switchable (jumper/DNP resistor)
- [ ] CAN transceiver selected for the correct speed:
  - Classical CAN: up to 1 Mbps
  - CAN FD: up to 5-8 Mbps
  - CAN XL: if applicable
- [ ] Transceiver supply voltage matches the bus voltage standard (typically 5V)
- [ ] Split termination (60Ω + 60Ω with 4.7nF to GND) for improved EMC (if used)
- [ ] Common-mode filter/choke on CAN_H/CAN_L (recommended for EMC)
- [ ] ESD protection on CAN_H and CAN_L (TVS diodes rated for CAN bus voltage)
- [ ] Standby/silent mode pin properly managed
- [ ] CAN transceiver TXD/RXD connected to correct controller pins

### 4. I2C (Inter-Integrated Circuit)

- [ ] SDA and SCL have pull-up resistors:
  - Standard-mode (100kHz): 1kΩ to 10kΩ
  - Fast-mode (400kHz): typically 2.2kΩ to 4.7kΩ
  - Fast-mode Plus (1MHz): typically 1kΩ to 2kΩ
  - Value depends on bus capacitance: RP ≤ tr / (0.8473 × CB)
- [ ] Pull-up voltage matches all devices on the bus
- [ ] Total bus capacitance ≤ 400pF (standard/fast mode):
  - Count all device pin capacitances + trace capacitance
- [ ] No address conflicts between devices on the same bus
- [ ] For level-shifted I2C: bidirectional level shifter suitable for open-drain protocol
- [ ] For long I2C runs or off-board I2C: consider bus extender/buffer IC

### 5. SPI (Serial Peripheral Interface)

- [ ] MOSI, MISO, SCK, and CS# signals correctly connected
- [ ] Individual CS# line for each slave device (active-low, directly driven)
- [ ] CS# lines have pull-up resistors to prevent glitches during controller boot
- [ ] SPI clock polarity (CPOL) and phase (CPHA) match between master and all slaves
- [ ] SPI clock frequency is within all slave devices' specifications
- [ ] For long SPI traces or off-board: series termination on SCK and MOSI
- [ ] Unused MISO outputs are tri-stated (multi-slave designs)

### 6. UART / RS-232 / RS-485

#### UART (TTL/CMOS level)
- [ ] TX of one device connected to RX of the other (crossover)
- [ ] Voltage levels are compatible between devices
- [ ] RX pull-up to prevent noise during boot/reset (especially if TX can tri-state)
- [ ] Hardware flow control (RTS/CTS) properly connected if used

#### RS-232
- [ ] RS-232 transceiver (MAX232, similar) present for voltage level conversion
- [ ] Charge pump capacitors on transceiver per datasheet values
- [ ] Connector pinout matches DTE or DCE convention (document which)
- [ ] TX/RX crossover is correct for the cable type (straight-through vs null modem)
- [ ] Handshaking lines connected or properly terminated

#### RS-485
- [ ] RS-485 transceiver selected for the data rate
- [ ] A/B (or D+/D-) polarity is correct (verify standard — TIA-485 vs manufacturer convention)
- [ ] Termination resistor (120Ω) at each end of the bus
- [ ] Bias resistors for defined idle state:
  - Pull-up on A (typically 390Ω-560Ω to VCC)
  - Pull-down on B (typically 390Ω-560Ω to GND)
  - Only needed at one point on the bus
- [ ] Direction control (DE/RE#) properly managed:
  - Auto-direction if supported by transceiver
  - GPIO-controlled with proper timing if manual
- [ ] Fail-safe receiver (input defined when bus is open/shorted)
- [ ] ESD protection on A and B lines for external connections

### 7. HDMI / DisplayPort

- [ ] TMDS differential pairs (HDMI) or Main Link lanes (DP) correctly connected
- [ ] AC coupling capacitors on TMDS lines (if required by the source device)
- [ ] DDC (I2C) channel for EDID: SDA/SCL with appropriate pull-ups
- [ ] HPD (Hot Plug Detect) signal properly connected with pull-up/pull-down
- [ ] 5V power on HDMI connector (source provides 5V, ≥55mA)
- [ ] CEC (Consumer Electronics Control) — if implemented, proper bias
- [ ] ESD protection on all pins, especially hot-plug-capable pins
- [ ] Connector pinout verified against HDMI/DP specification

### 8. JTAG / SWD (Debug)

- [ ] JTAG: TCK, TDI, TDO, TMS, TRST# properly connected
- [ ] SWD: SWDIO, SWCLK properly connected
- [ ] SWO (Serial Wire Output) connected if trace output is desired
- [ ] Pull-up on TMS (JTAG) — keeps device in Run-Test/Idle if disconnected
- [ ] Pull-up or pull-down on TRST# as appropriate for the device
- [ ] Debug connector pinout matches the debugger being used (ARM 10-pin, 20-pin, Tag-Connect, etc.)
- [ ] Series resistors on debug signals (optional, for protection)
- [ ] Debug connector does not interfere with normal operation when debugger is disconnected

---

## Common Interface Compliance Issues

| Issue | Severity | Description |
|-------|----------|-------------|
| USB D+/D- swapped | Critical | USB device not recognized |
| Missing USB pull-up resistor | Critical | Device not detected on bus |
| Missing CAN termination | Major | Bus reflections, communication errors |
| I2C address conflict | Major | Two devices respond simultaneously |
| RS-485 A/B polarity swapped | Critical | Data inverted, no communication |
| Missing Ethernet magnetics | Critical | No galvanic isolation, won't pass compliance |
| SPI CS# floating during boot | Major | Slave device may corrupt bus |
| Wrong USB Type-C CC resistors | Critical | Wrong current limit advertised, potential damage |
| UART TX-to-TX connection | Critical | Both devices driving, no communication |
| Missing I2C pull-ups | Critical | Bus cannot pull high |

## Severity Classification

- **Critical**: Interface will not function or violates the protocol specification in a way that prevents communication.
- **Major**: Interface may function but will not pass compliance testing or will fail with some counterparts.
- **Minor**: Minor non-compliance that is unlikely to cause interoperability issues.
- **Info**: Optimization or best practice suggestion.

## Output Format

```
### Finding [number]
- **Severity**: [Critical | Major | Minor | Info]
- **Location**: [Sheet, connector/transceiver designator, interface name]
- **Protocol**: [USB 2.0, Ethernet 100BASE-TX, CAN, I2C, SPI, etc.]
- **Description**: [What the compliance issue is]
- **Specification Requirement**: [What the protocol spec or datasheet requires]
- **Recommendation**: [What should be changed]
- **Reference**: [Protocol specification section, datasheet page]
```
